# Git Rebase Strategy Guide

## Purpose

This document explains how the team should synchronize feature branches with the latest `main` branch changes using **Git Rebase** instead of merge commits.

Using rebase helps maintain:

* Cleaner Git history
* Linear commit flow
* Easier troubleshooting
* Better pull request readability

---

# Why Rebase Instead of Merge?

## Merge Strategy

```text
main ----A----B----C
          \        \
feature    D----E---M
```

Creates extra merge commits (`M`).

---

## Rebase Strategy

```text
main ----A----B----C
                    \
feature              D'---E'
```

Feature commits are replayed on top of latest `main`.

Result:

* Cleaner history
* No unnecessary merge commits

---

# Team Rebase Workflow

## Scenario

* You created a feature branch from `main`
* You developed your feature
* Meanwhile other developers merged changes into `main`
* You now need latest `main` changes without losing your work

---

# Recommended Workflow

---

## Step 1 — Commit Your Changes

Before rebasing, ensure all your work is committed.

```bash
git status
```

If there are changes:

```bash
git add .
git commit -m "WIP: current feature progress"
```

---

## Step 2 — Switch to Main Branch

```bash
git checkout main
```

---

## Step 3 — Pull Latest Main Branch

```bash
git pull origin main
```

Now your local `main` is up to date.

---

## Step 4 — Switch Back to Feature Branch

```bash
git checkout feature-branch
```

Example:

```bash
git checkout feature/user-login
```

---

## Step 5 — Rebase Feature Branch onto Main

```bash
git rebase main
```

Git will now:

* Take your feature commits
* Temporarily remove them
* Move branch to latest `main`
* Replay your commits on top

---

# What Happens During Rebase?

Before:

```text
main:    A---B---C
feature:      \---D---E
```

After rebasing:

```text
main:    A---B---C
                     \
feature:              D'---E'
```

---

# Handling Conflicts During Rebase

Sometimes conflicts occur if:

* Same file was modified in `main`
* Same lines were changed

Git will stop and show conflict message.

---

## Step 6 — Resolve Conflicts

Open conflicted files.

Git marks conflicts like:

```text
<<<<<<< HEAD
Code from main
=======
Code from feature branch
>>>>>>> feature-branch
```

Edit file and keep correct code.

---

## Step 7 — Mark Conflict as Resolved

```bash
git add .
```

---

## Step 8 — Continue Rebase

```bash
git rebase --continue
```

Git continues replaying remaining commits.

---

# Repeat if More Conflicts Appear

Continue:

1. Resolve conflicts
2. `git add .`
3. `git rebase --continue`

Until rebase completes.

---

# If You Want to Cancel Rebase

```bash
git rebase --abort
```

This restores branch to original state.

---

# After Successful Rebase

Your local history changed.

You must push using force-with-lease.

---

## Step 9 — Push Rebasing Changes

```bash
git push origin feature-branch --force-with-lease
```

---

# Why Use `--force-with-lease`?

Safer than `--force`.

It prevents overwriting others' work accidentally.

---

# Important Team Rules

## Always Rebase Before Creating PR

Before raising PR:

```bash
git checkout main
git pull origin main

git checkout feature-branch
git rebase main
```

---

## Never Rebase Shared Public Branches

Safe to rebase:

* Personal feature branches

Avoid rebasing:

* Shared collaboration branches
* `main`
* `release`
* `develop`

---

# Recommended Git Configurations

## Enable Auto Stash During Rebase

```bash
git config --global rebase.autoStash true
```

This automatically stashes uncommitted changes.

---

## Make Pull Use Rebase by Default

```bash
git config --global pull.rebase true
```

Now:

```bash
git pull
```

will automatically use rebase.

---

# Recommended Daily Workflow

```bash
git checkout main
git pull origin main

git checkout feature-branch
git rebase main

# Resolve conflicts if needed

git push origin feature-branch --force-with-lease
```

---

# Common Commands Cheat Sheet

| Purpose             | Command                       |
| ------------------- | ----------------------------- |
| Update main         | `git pull origin main`        |
| Rebase branch       | `git rebase main`             |
| Continue rebase     | `git rebase --continue`       |
| Abort rebase        | `git rebase --abort`          |
| Push rebased branch | `git push --force-with-lease` |

---

# Best Practices

* Rebase frequently
* Keep feature branches short-lived
* Resolve conflicts immediately
* Use meaningful commits
* Avoid huge PRs

---

# Example Full Flow

```bash
# Save work
git add .
git commit -m "Added login validation"

# Update main
git checkout main
git pull origin main

# Rebase feature
git checkout feature/login
git rebase main

# Resolve conflicts if any
git add .
git rebase --continue

# Push updated branch
git push origin feature/login --force-with-lease
```

---

# Final Notes

Using rebase consistently helps:

* Maintain clean repository history
* Simplify code reviews
* Reduce unnecessary merge commits
* Improve debugging and rollback capability

Team members should regularly sync feature branches with latest `main` using rebase before raising pull requests.
