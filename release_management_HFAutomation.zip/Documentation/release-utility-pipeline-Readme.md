# Release Utility Pipeline

## Overview

`release-utility-pipeline.yml` is an enterprise-style Azure DevOps Release Management pipeline designed to automate standardized release activities across multiple repositories.

The pipeline supports:

* Hotfix branch creation
* Pull Request creation
* Reverse merge Pull Requests
* Release tagging
* Multi-repository orchestration

The solution is built using:

* Azure DevOps YAML Pipelines
* Reusable YAML Templates
* PowerShell Modules
* Azure DevOps REST APIs

---

# Solution Architecture

```text
release-utility-pipeline.yml
            │
            ▼
templates/release-stage-template.yml
            │
            ▼
scripts/Repository-Utility.psm1
            │
            ▼
Azure DevOps REST APIs
```

---

# Repository Structure

```text
.
├── release-utility-pipeline.yml
│
├── templates
│   └── release-stage-template.yml
│
├── scripts
│   └── Repository-Utility.psm1
│
└── README.md
```

---

# Pipeline Components

---

# 1. Release Utility Pipeline (`release-utility-pipeline.yml`)

The main pipeline acts as the orchestration layer.

Responsibilities:

* Accept runtime parameters
* Decide which repositories to execute
* Decide which activities to run
* Call reusable stage templates
* Trigger release tagging

---

# Supported Repository Types

| Repository Type | Description               |
| --------------- | ------------------------- |
| UI              | Frontend/UI applications  |
| API             | Backend/API applications  |
| Databricks      | Databricks notebooks/jobs |

---

# Supported Activities

Each repository can independently execute one of the following activities.

| Activity               | Description                              |
| ---------------------- | ---------------------------------------- |
| `Create-Hotfix-Branch` | Creates a new hotfix branch from Release |
| `PR-HF-Release`        | Creates PR from Hotfix → Release         |
| `PR-Reverse-Merge`     | Creates PR from Release → Main           |

---

# Runtime Parameters

---

## UI Parameters

```yaml
- name: DeployUI
  type: boolean

- name: UIActivity
  type: string
```

Controls:

* Whether UI stage executes
* Which activity UI repository performs

---

## API Parameters

```yaml
- name: DeployAPI
  type: boolean

- name: APIActivity
  type: string
```

Controls:

* Whether API stage executes
* Which activity API repository performs

---

## Databricks Parameters

```yaml
- name: DeployDatabricks
  type: boolean

- name: DatabricksActivity
  type: string
```

Controls:

* Whether Databricks stage executes
* Which activity Databricks repository performs

---

## Tag Release Parameter

```yaml
- name: TagRelease
  type: boolean
```

Controls whether release tags should be created.

---

# Variable Group

The pipeline uses an Azure DevOps Variable Group.

```yaml
variables:
- group: Release-Management
```

---

# Required Variables

| Variable       | Description                   |
| -------------- | ----------------------------- |
| `ADO_URL`      | Azure DevOps Organization URL |
| `ADO_PROJECT`  | Azure DevOps Project Name     |
| `ADO_PAT`      | Personal Access Token         |
| `ADO_UI_REPO`  | UI Repository Name            |
| `ADO_API_REPO` | API Repository Name           |
| `ADO_DB_REPO`  | Databricks Repository Name    |
| `RELEASE_ID`   | Current Release Identifier    |
| `RELEASE_DATE` | Current Release Date          |

---

# Stage Execution Flow

```text
Release Utility Pipeline
        │
        ├── UI Stage
        │
        ├── API Stage
        │
        ├── Databricks Stage
        │
        └── Tag Release Stage
```

---

# 2. Stage Template (`release-stage-template.yml`)

The template acts as the reusable execution engine.

Instead of duplicating pipeline logic for each repository, the main pipeline calls this template multiple times.

---

# Template Parameters

| Parameter            | Description                   |
| -------------------- | ----------------------------- |
| `stageName`          | Name of stage                 |
| `displayName`        | Display name in pipeline      |
| `enabled`            | Determines whether stage runs |
| `activity`           | Activity to execute           |
| `repositoryName`     | Repository target             |
| `releaseId`          | Release identifier            |
| `releaseDate`        | Release date                  |
| `adoOrganizationUrl` | Azure DevOps organization URL |
| `adoProject`         | Azure DevOps project          |
| `adoPat`             | PAT token                     |

---

# Template Workflow

```text
Utility Stage
      │
      ├── Create Hotfix Branch
      │
      ├── Create PR Hotfix → Release
      │
      └── Create Reverse Merge PR
```

---

# Utility Stage

The utility stage displays execution details for operational visibility.

Example:

```powershell
Write-Host "Executing UI Stage"
Write-Host "Selected Activity : Create-Hotfix-Branch"
Write-Host "Release ID        : V1.2"
```

This helps:

* debugging
* auditing
* release tracking

---

# Activity-Based Routing

Each task executes conditionally based on the selected activity.

Example:

```yaml
condition: eq('${{ parameters.activity }}', 'Create-Hotfix-Branch')
```

This enables:

* centralized execution logic
* reusable templates
* simplified maintenance

---

# 3. PowerShell Module (`Repository-Utility.psm1`)

The PowerShell module contains reusable Azure DevOps automation functions.

This module acts as the business logic layer of the release framework.

---

# Exported Functions

| Function                         | Description                 |
| -------------------------------- | --------------------------- |
| `New-AdoHotfixBranch`            | Creates hotfix branches     |
| `Remove-AdoHotfixBranch`         | Deletes hotfix branches     |
| `New-AdoPullRequest`             | Creates Pull Requests       |
| `Set-AdoPullRequestAutoComplete` | Configures PR auto-complete |
| `New-AdoReleaseTag`              | Creates release tags        |

---

# Authentication Model

All functions authenticate using Azure DevOps PAT authentication.

Example:

```powershell
$base64AuthInfo = [Convert]::ToBase64String(
    [Text.Encoding]::ASCII.GetBytes(":$PatToken")
)
```

---

# Hotfix Branch Creation

Function:

```powershell
New-AdoHotfixBranch
```

Workflow:

1. Fetch latest commit from Release branch
2. Create new Git reference
3. Create hotfix branch

Generated branch format:

```text
Hotfix/Hotfix-<ReleaseId>
```

Example:

```text
Hotfix/Hotfix-V1.2
```

---

# Pull Request Creation

Function:

```powershell
New-AdoPullRequest
```

Supports:

* Hotfix → Release PR
* Release → Main Reverse Merge PR

---

# Reverse Merge Strategy

The reverse merge process ensures all production release changes are merged back into Main.

Flow:

```text
Release → Main
```

Benefits:

* prevents branch divergence
* preserves production fixes
* keeps Main synchronized

---

# PR Auto Complete

Function:

```powershell
Set-AdoPullRequestAutoComplete
```

Capabilities:

* Enable auto complete
* Delete source branch after merge
* Configure merge strategy

---

# Release Tagging

Function:

```powershell
New-AdoReleaseTag
```

Creates immutable Git release tags.

Tag format:

```text
Release-<ReleaseId>
```

Example:

```text
Release-V1.2
```

---

# Complete Release Lifecycle

```text
Release Branch
    │
    ├── Create Hotfix Branch
    │
    ├── Hotfix Development
    │
    ├── Create PR Hotfix → Release
    │
    ├── Validate Release
    │
    ├── Create Reverse Merge PR
    │
    ├── Merge Release → Main
    │
    └── Create Release Tag
```

---

# Example Pipeline Executions

---

# Example 1 — Create Hotfix Branch

Runtime Parameters:

```yaml
DeployUI: true
UIActivity: Create-Hotfix-Branch
```

Result:

* Creates:

```text
Hotfix/Hotfix-V1.2
```

---

# Example 2 — Create Hotfix PR

Runtime Parameters:

```yaml
DeployAPI: true
APIActivity: PR-HF-Release
```

Result:

* Creates PR:

```text
Hotfix/Hotfix-V1.2 → Release
```

---

# Example 3 — Reverse Merge PR

Runtime Parameters:

```yaml
DeployDatabricks: true
DatabricksActivity: PR-Reverse-Merge
```

Result:

* Creates PR:

```text
Release → Main
```

---

# Example 4 — Tag Release

Runtime Parameters:

```yaml
TagRelease: true
```

Result:

* Creates Git tags:

```text
Release-V1.2
```

---

# Security Recommendations

---

# PAT Permissions

Recommended PAT permissions:

| Permission    | Access       |
| ------------- | ------------ |
| Code          | Read & Write |
| Pull Requests | Read & Write |

Avoid granting unnecessary permissions.

---

# Secret Management

Always store:

* PAT tokens
* credentials
* sensitive values

inside:

* Azure DevOps Variable Groups
* Azure Key Vault

Never hardcode secrets.

---

# Recommended Branching Strategy

```text
Main
Release
Hotfix/*
```

---

# Recommended Release Naming

```text
V1.0
V1.1
2026.05.1
```

---

# Best Practices

* Keep REST API logic inside PowerShell modules
* Avoid embedding REST calls directly inside YAML
* Use reusable templates for scalability
* Use standardized release IDs
* Use reverse merges after production releases
* Use immutable release tags

---

# Troubleshooting

---

# Branch Already Exists

Error:

```text
Branch already exists
```

Cause:

* Hotfix branch already created

Resolution:

* Delete existing branch
* Use new release ID

---

# Source Branch Not Found

Error:

```text
Source branch 'Release' not found
```

Cause:

* Release branch missing

Resolution:

* Verify branch exists
* Verify branch naming

---

# Unauthorized Errors

Error:

```text
401 Unauthorized
```

Cause:

* Invalid PAT
* Missing permissions

Resolution:

* Validate PAT token
* Verify PAT access

---

# Summary

This framework provides:

* Centralized release orchestration
* Reusable YAML templates
* Reusable PowerShell automation
* Automated branch management
* Automated Pull Request creation
* Automated reverse merge handling
* Automated release tagging
* Multi-repository release operations

The architecture is designed to be:

* scalable
* reusable
* maintainable
* enterprise-ready
