


// const REDIRECT_URI = "https://azr-vabtp-webapp-01-r2-dgbvhab2hpfyg7a7.eastus-01.azurewebsites.net/"
// const REDIRECT_URI = "https://azr-vabtp-webapp-01-r2-dgbvhab2hpfyg7a7.eastus-01.azurewebsites.net/"
const REDIRECT_URI = process.env.NEXT_PUBLIC_REDIRECT_URI



const CLIENT_ID = process.env.NEXT_PUBLIC_CLIENT_ID;

const TENANT_ID = process.env.NEXT_PUBLIC_TENANT_ID;

export const msalConfig = {
  auth: {
    clientId: CLIENT_ID,
    authority: `https://login.microsoftonline.com/${TENANT_ID}`,
    redirectUri: REDIRECT_URI,
    postLogoutRedirectUri: REDIRECT_URI,
    navigateToLoginRequestUrl: false,
  },
  cache: {
    cacheLocation: "localStorage",
    storeAuthStateInCookie: true,
  },
};

export const loginRequest = {
  scopes: ["openid", "profile", "email", "User.Read"],
};
