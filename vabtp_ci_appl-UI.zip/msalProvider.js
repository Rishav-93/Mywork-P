"use client";

import { useEffect, useState } from "react";
import { MsalProvider } from "@azure/msal-react";
import { initializeMsal, msalInstance } from "./msalInstance";

export default function MsalAuthProvider({ children }) {
  const [isReady, setIsReady] = useState(false);

  useEffect(() => {
    let isMounted = true;

    const init = async () => {
      try {
        await initializeMsal();

        // ✅ Handle redirect FIRST
        const response = await msalInstance.handleRedirectPromise();

        if (response?.account) {
          msalInstance.setActiveAccount(response.account);
          console.log("Redirect success:", response);
        } else {
          const accounts = msalInstance.getAllAccounts();
          if (accounts.length > 0) {
            msalInstance.setActiveAccount(accounts[0]);
          }
        }
      } catch (error) {
        console.error("MSAL init error:", error);
      } finally {
        if (isMounted) setIsReady(true);
      }
    };

    init();

    return () => {
      isMounted = false;
    };
  }, []);

  if (!isReady) return null;

  return <MsalProvider instance={msalInstance}>{children}</MsalProvider>;
}