"use client";

import React from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";

/* =======================
   TABLE DATA OBJECT
======================= */
const processHistoryData = [
  {
    id: 1,
    dateTime: "21 Jan 2026, 2:30 PM",
    plant: "Plant code #",
    status: "Failed",
  },
  {
    id: 2,
    dateTime: "21 Dec 2025, 1:30 PM",
    plant: "Plant code #",
    status: "Pass",
  },
  {
    id: 3,
    dateTime: "12 Nov 2025, 4:30 PM",
    plant: "Plant code #",
    status: "Pass",
  },
  {
    id: 4,
    dateTime: "21 July 2025, 2:30 PM",
    plant: "Plant code #",
    status: "Failed",
  },
  {
    id: 5,
    dateTime: "02 Aug 2025, 2:30 PM",
    plant: "Plant code #",
    status: "Pass",
  },
];

/* =======================
   MAIN COMPONENT
======================= */
export default function TriggerLog() {
  const filterData = (type) => {
    if (type === "completed")
      return processHistoryData.filter((item) => item.status === "Pass");
    if (type === "incompleted")
      return processHistoryData.filter((item) => item.status === "Failed");
    return processHistoryData;
  };

  const StatusBadge = ({ status }) => (
    <div className="flex items-center gap-2">
      <span
        className={`h-2 w-2 rounded-full ${
          status === "Pass" ? "bg-green-500" : "bg-red-500"
        }`}
      />
      <span
        className={`text-sm font-medium ${
          status === "Pass" ? "text-green-600" : "text-red-600"
        }`}
      >
        {status}
      </span>
    </div>
  );

  const RenderTable = ({ data }) => (
    <Table>
      <TableHeader>
        <TableRow>
          <TableHead>Date & Time</TableHead>
          <TableHead>Plant Name (Code)</TableHead>
          <TableHead>Status</TableHead>
          <TableHead>Remarks</TableHead>
          <TableHead className="text-right">Action</TableHead>
        </TableRow>
      </TableHeader>

      <TableBody>
        {data.map((row) => (
          <TableRow key={row.id}>
            <TableCell>{row.dateTime}</TableCell>
            <TableCell>{row.plant}</TableCell>

            <TableCell>
              <StatusBadge status={row.status} />
            </TableCell>

            <TableCell>
              {row.status === "Failed" && (
                <Input
                  placeholder="Remark"
                  className="max-w-[220px] bg-blue-50"
                />
              )}
            </TableCell>

            <TableCell className="text-right">
              {row.status === "Failed" && (
                <Button variant="destructive" size="sm">
                  Re-Run
                </Button>
              )}
            </TableCell>
          </TableRow>
        ))}
      </TableBody>
    </Table>
  );

  return (
    <div className="rounded-lg bg-white p-6 shadow-sm">
      <h2 className="mb-4 text-sm font-semibold text-red-500">
        PROCESS HISTORY
      </h2>

      <Tabs defaultValue="all">
        <TabsList className="mb-4">
          <TabsTrigger value="all">ALL</TabsTrigger>
          <TabsTrigger value="completed">COMPLETED</TabsTrigger>
          <TabsTrigger value="incompleted">INCOMPLETED</TabsTrigger>
        </TabsList>

        <TabsContent value="all">
          <RenderTable data={filterData("all")} />
        </TabsContent>

        <TabsContent value="completed">
          <RenderTable data={filterData("completed")} />
        </TabsContent>

        <TabsContent value="incompleted">
          <RenderTable data={filterData("incompleted")} />
        </TabsContent>
      </Tabs>
    </div>
  );
}
