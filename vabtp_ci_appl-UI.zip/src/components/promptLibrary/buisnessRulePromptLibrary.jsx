"use client";
import React, { useEffect, useState } from "react";
import { useRuleStore } from "@/store/useRuleStore";
import PromptSection from "./promptSection";
import { Search, Eye } from "lucide-react";
import { Button } from "@base-ui/react";

export default function BusinessRulePromptLibrary() {
    const { rules, fetchRules, loading } = useRuleStore();

    const [selectedPrompt, setSelectedPrompt] = useState(null);
    const [searchText, setSearchText] = useState("");
    const [filteredRules, setFilteredRules] = useState([]);

    // ✅ NEW STATE
    const [isSearchApplied, setIsSearchApplied] = useState(false);

    useEffect(() => {
        fetchRules();
    }, []);

    // ✅ HANDLE SEARCH
    const handleSearch = () => {

        const filtered = rules.filter((item) =>
            `${item.rule_name} ${item.rule_id}`
                .toLowerCase()
                .includes(searchText.toLowerCase())
        );

        setFilteredRules(filtered);

        // ✅ SEARCH APPLIED
        setIsSearchApplied(true);
    };

    // ✅ DISPLAY DATA
    const displayData = isSearchApplied
        ? filteredRules
        : rules;

    // ✅ VIEW SCREEN
    if (selectedPrompt) {
        return (
            <PromptSection
                selectedPrompt={selectedPrompt}
                onBack={() => setSelectedPrompt(null)}
            />
        );
    }

    return (
        <div>

            {/* 🔍 SEARCH */}
            <div className="flex items-center gap-3 mb-4">

                <div className="flex items-center border rounded-lg px-3 py-2 w-80 bg-white shadow-sm">

                    <span className="text-primary mr-2">
                        <Search />
                    </span>

                    <input
                        type="text"
                        placeholder="Prompt"
                        value={searchText}
                        onChange={(e) => {

                            const value = e.target.value;

                            setSearchText(value);

                            // ✅ RESET TABLE WHEN INPUT CLEARED
                            if (value.trim() === "") {

                                setFilteredRules([]);

                                setIsSearchApplied(false);
                            }
                        }}
                        className="outline-none w-full text-sm"
                    />
                </div>

                <button
                    onClick={handleSearch}
                    className="bg-primary hover:opacity-90 text-white px-6 py-2 rounded-lg font-semibold"
                >
                    APPLY
                </button>
            </div>

            {/* 📦 TABLE CONTAINER */}
            <div className="border rounded-lg p-5">

                <h2 className="text-red-500 font-semibold text-lg mb-4">
                    PROMPT LIBRARY
                </h2>

                <div className="border rounded-lg overflow-hidden">

                    <table className="w-full text-sm table-fixed">

                        <thead className="bg-gray-100 text-gray-700">
                            <tr>

                                <th className="text-left px-4 py-3 w-[20%]">
                                    Rule Name
                                </th>

                                <th className="text-left px-4 py-3 w-[40%]">
                                    Rule Description
                                </th>

                                <th className="text-left px-4 py-3 w-[10%]">
                                    Version
                                </th>

                                <th className="text-left px-4 py-3 w-[10%]">
                                    Created By
                                </th>

                                <th className="text-left px-4 py-3 w-[10%]">
                                    Last Updated
                                </th>

                                <th className="text-left px-4 py-3 w-[10%]">
                                    Action
                                </th>

                            </tr>
                        </thead>

                        <tbody>

                            {loading ? (

                                <tr>
                                    <td
                                        colSpan="6"
                                        className="text-center py-4"
                                    >
                                        Loading...
                                    </td>
                                </tr>

                            ) : displayData.length === 0 ? (

                                <tr>
                                    <td
                                        colSpan="6"
                                        className="text-center py-4 text-gray-500"
                                    >
                                        No records found
                                    </td>
                                </tr>

                            ) : (

                                displayData.map((item, index) => (

                                    <tr
                                        key={index}
                                        className="border-t hover:bg-gray-50 text-xs transition"
                                    >

                                        {/* Rule Name */}
                                        <td className="px-4 py-3">
                                            <p
                                                className="w-[270px] truncate"
                                                title={item.rule_name}
                                            >
                                                {item.rule_name}
                                            </p>
                                        </td>

                                        {/* Rule Description */}
                                        <td className="px-4 py-3 whitespace-normal break-words">
                                            <p
                                                className="overflow-hidden text-ellipsis line-clamp-2"
                                                title={item.nlp_description}
                                            >
                                                {item.nlp_description}
                                            </p>
                                        </td>

                                        {/* Version */}
                                        <td className="px-4 py-3 text-green-600 font-semibold">
                                            {item.rule_version}
                                        </td>

                                        {/* Created By */}
                                        <td className="px-4 py-3">
                                            {item.created_by || "System"}
                                        </td>

                                        {/* Date */}
                                        <td className="px-4 py-3 text-gray-600">
                                            {item.date}
                                        </td>

                                        {/* Action */}
                                        <td className="px-4 py-3">

                                            <Button
                                                onClick={() => {

                                                    console.log(
                                                        "FULL RULE 👉",
                                                        item.fullData
                                                    );

                                                    setSelectedPrompt(item);
                                                }}
                                                className="px-2 py-1"
                                            >
                                                <Eye className="w-4 h-4 text-primary" />
                                            </Button>

                                        </td>

                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
}