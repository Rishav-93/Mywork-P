"use client";
import React from "react";
import RunPrompt from "./runPrompt";


export default function RunPromptNlp({ data, modifyPromptData, onClose, dropdownData }) {
    const runPromptData = modifyPromptData || data;

    return (
        <div className="border rounded-lg p-4 bg-white mb-4">
            <RunPrompt
                onClose={onClose}

                modifyPromptData={runPromptData}
                dropdownData={dropdownData}
            />
        </div>
    );
}
