import React from "react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import BusinessRule from "./buisnessRule";
import BusinessRulePromptLibrary from "./buisnessRulePromptLibrary";

export default function PromptLibrary() {
  return (
    <div>
      <Tabs defaultValue="business">
        {/* Tab Header */}
        <TabsList variant="line">
          <TabsTrigger value="business">Business Rules</TabsTrigger>

          {/* <TabsTrigger value="sanitization">Sanitization Rules</TabsTrigger> */}
        </TabsList>

        {/* Tab Content */}
        <TabsContent value="business">
          {/* <BusinessRule /> */}

          <BusinessRulePromptLibrary />
        </TabsContent>

        <TabsContent value="sanitization">
          {/* <SanatizationRule /> */}
          {/* Your Sanitization UI Here */}
        </TabsContent>
      </Tabs>
    </div>
  );
}
