"use client";
import React, { useState } from "react";
import EditPromptSection from "./editPromptSection";
import RunPrompt from "./runPrompt";
import { Button } from "../ui/button";
import NlpDescription from "./nlpDescription";
import { useConvertToNlpStore } from "@/store/useConvertToNlpStore";
import axios from "axios";
import { toast } from "sonner";
import RunPromptNlp from "./runPromptNlp";

export default function PromptSection({ selectedPrompt, onBack }) {
  const [isEdit, setIsEdit] = useState(false);
  const [showRunPrompt, setShowRunPrompt] = useState(false);
  const [nlpResult, setNlpResult] = useState(null);
  const [modifyPromptData, setModifyPromptData] = useState("");
  const formData = useConvertToNlpStore((s) => s.formData);
  const [loading, setLoading] = useState(false);
  const [modifySAPsource, setModifySAPsource] = useState(null);

  const data = selectedPrompt?.fullData || {};

  const SOURCE_SCHEMA_PATH = process.env.NEXT_PUBLIC_SOURCE_SCHEMA_PATH;
  const INDEX_MOT_PATH = process.env.NEXT_PUBLIC_INDEX_MOT_PATH;

  /* ================= MODIFY ================= */
  const handleModifyPrompt = async () => {
    try {
      setLoading(true);

      const res = await fetch(
        `${process.env.NEXT_PUBLIC_RECON_API_URL}/recon/rules/modifyprompt?source_schema_path=${SOURCE_SCHEMA_PATH}&index_mot_path=${INDEX_MOT_PATH}`
      );

      const result = await res.json();

      setModifySAPsource(result);

      // OPTIONAL: open edit
      setIsEdit(true);

    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  /* ================= CONVERT NLP ================= */
  const handleConvertToNLP = async () => {
    let toastId;

    // 🔥 1. SWITCH UI IMMEDIATELY

    try {
      toastId = toast.loading("Generating NLP...");

      const payload = {
        request_type: "Rules Update NLP",
        portal: formData.portal || "TRAC66 & T4 (P66)",
        rule_level: formData.rule_level,
        data_source: formData.data_source,

        // ✅ FIXED HERE
        rule_id: parseInt(String(formData.rule_id).replace(/\D/g, ""), 10) || 0,

        rules_priority: Number(formData.rules_priority || 0),
        rules_order: Number(formData.rules_order || 0),

        rules_severity: formData.rules_severity,
        fields: formData.fields,
        classify: formData.classify,
      };
      console.log("Payload for NLP:", payload);

      // ✅ 2. KEEP API CALL
      const convertRes = await axios.post(
        `${process.env.NEXT_PUBLIC_RECON_API_URL}/recon/converttonlp`,
        payload
      );

      const runId = convertRes.data?.run_id;

      if (!runId) {
        toast.error("run_id not found", { id: toastId });
        return;
      }

      // 🔥 3. RESULT CHECK FUNCTION
      const checkResult = async () => {
        try {
          const res = await axios.get(
            `${process.env.NEXT_PUBLIC_RECON_API_URL}/recon/converttonlp/result`,
            { params: { run_id: runId } }
          );

          const result = res.data;
          setModifyPromptData(result);

          const lifeCycle = result?.job_state?.life_cycle_state;
          const resultState =
            result?.job_state?.result_state || result?.status;

          if (lifeCycle === "RUNNING") return false;

          if (lifeCycle === "TERMINATED") {
            if (resultState === "SUCCESS" || resultState === "success") {
              toast.success("NLP Generated Successfully 🎉", {
                id: toastId,
              });

              setIsEdit("runPrompt");

              let parsed = result;
              try {
                parsed = result?.nlp_output
                  ? JSON.parse(result.nlp_output)
                  : result;
              } catch { }

              // ✅ THIS IS THE KEY FIX

            } else {
              toast.error("NLP failed ❌", { id: toastId });
            }

            return true;
          }

          return false;
        } catch {
          toast.error("Polling error", { id: toastId });
          return true;
        }
      };

      // ✅ 4. FIRST HIT INSTANTLY
      const done = await checkResult();
      if (done) return;

      // ✅ 5. POLLING EVERY 40 SEC
      const intervalId = setInterval(async () => {
        const finished = await checkResult();
        if (finished) clearInterval(intervalId);
      }, 40000);

    } catch (err) {
      console.error(err);

      toast.error("Something went wrong", { id: toastId });
    }
  };
  return (
    <div>
      {/* SYSTEM */}
      <div className="border rounded-lg p-4 space-y-2 mb-3">
        <h3 className="text-primary font-semibold">System</h3>
        <p className="text-sm text-gray-600">
          You are a Highly Skilled Reconciliation Engine Designed to Match
          Records.
        </p>
      </div>

      {/* 🔥 UI SWITCH */}
      {isEdit === "runPrompt" ? (
        <RunPromptNlp
          data={data}
          modifyPromptData={modifyPromptData}
          dropdownData={data}
          onClose={() => setIsEdit(true)}
        />
      ) : showRunPrompt ? (
        <RunPrompt
          data={data}
          modifyPromptData={modifyPromptData}   // 🔥 PASS THE NEW NLP DATA
          formData={formData}   // 🔥 IMPORTANT
          onClose={() => setShowRunPrompt(false)}
        />
      ) : isEdit === true ? (
        <EditPromptSection
          dropdownData={data}
          SAPSourceData={modifySAPsource}
        />
      ) : (
        <NlpDescription data={data} />
      )}

      {/* BUTTONS */}
      <div className="flex gap-3 mt-5">
        {!isEdit ? (
          <Button
            className="bg-primary text-white"
            onClick={handleModifyPrompt}
          >
            {loading ? "Loading..." : "Modify Prompt"}
          </Button>
        ) : isEdit === true ? (
          <>
            <Button className="text-white">Save Prompt</Button>

            <Button
              onClick={handleConvertToNLP}
              className="text-white"
            >
              Convert to NLP
            </Button>
          </>
        ) : null}

        <Button
          onClick={onBack}
          className="ml-auto text-white underline"
        >
          Back
        </Button>
      </div>
    </div>
  );
}
