"use client";
import React, { useEffect, useMemo, useState, useRef } from "react";
import { Button } from "../ui/button";
import { Popover } from "@headlessui/react";
import { ChevronDownIcon } from "@heroicons/react/20/solid";
import { CheckCircle } from "lucide-react";
import axios from "axios";
import { toast } from "sonner";
import { useConvertToNlpStore } from "@/store/useConvertToNlpStore";
import { useMsal } from "@azure/msal-react";

export default function RunPrompt({ onClose, nlpResult, modifyPromptData, dropdownData }) {
    const formData = useConvertToNlpStore((s) => s.formData);
    const { accounts } = useMsal();
    console.log("DROPDOWN DATA IN RUN PROMPT 👉", dropdownData);
    // ✅ ADD THIS STATE NEAR OTHER STATES

    const [email, setEmail] = useState("");
    const [selectedPlant, setSelectedPlant] = useState("");

    // ✅ ADD THIS
    const [plantOptions, setPlantOptions] = useState([]);

    const [showSuccess, setShowSuccess] = useState(false);
    const [approveLoading, setApproveLoading] = useState(false);
    const intervalRef = useRef(null);

    // ✅ TABLE STATE
    const [tableData, setTableData] = useState([]);
    const [columns, setColumns] = useState([]);
    const [currentPage, setCurrentPage] = useState(1);
    const rowsPerPage = 10;

    // ✅ Dialog
    const [showApproveDialog, setShowApproveDialog] = useState(false);

    const [checks, setChecks] = useState({
        c1: false,
        c2: false,
    });

    const normalizeApprovalStatus = (value) =>
        String(value || "")
            .toLowerCase()
            .replace(/[\s_-]/g, "");

    const normalizeRuleId = (value) =>
        String(value || "").replace(/\D/g, "");

    // const plantOptions = ["03AG", "A3E5"];

    /* ================= NLP LOGIC (UNCHANGED) ================= */

    const parsedNlpOutput = useMemo(() => {
        const raw = modifyPromptData?.nlp_output;

        if (typeof raw !== "string") return null;

        try {
            return JSON.parse(raw);
        } catch {
            return null;
        }
    }, [modifyPromptData]);

    const systemInputText = useMemo(() => {
        const stripBusinessExplanation = (text) => {
            if (typeof text !== "string") return "";

            const lower = text.toLowerCase();

            const idx =
                lower.indexOf("business explanation") !== -1
                    ? lower.indexOf("business explanation")
                    : lower.indexOf("business_explanation");

            if (idx === -1) return text;

            return text.slice(0, idx).trim();
        };

        if (!modifyPromptData) return "";

        const fromParsed =
            parsedNlpOutput?.system_input ||
            parsedNlpOutput?.systemInput ||
            parsedNlpOutput?.system_prompt ||
            parsedNlpOutput?.systemPrompt ||
            parsedNlpOutput?.system_input_text ||
            parsedNlpOutput?.system ||
            parsedNlpOutput?.prompt;

        if (typeof fromParsed === "string")
            return stripBusinessExplanation(fromParsed);

        if (typeof modifyPromptData === "string")
            return stripBusinessExplanation(modifyPromptData);

        if (typeof modifyPromptData?.nlp_output === "string") {
            if (parsedNlpOutput && typeof parsedNlpOutput === "object") {
                const {
                    business_explanation,
                    nlp_decription,
                    nlp_description,
                    ...rest
                } = parsedNlpOutput;

                return stripBusinessExplanation(
                    JSON.stringify(rest, null, 2)
                );
            }

            return stripBusinessExplanation(modifyPromptData.nlp_output);
        }

        try {
            return stripBusinessExplanation(
                JSON.stringify(modifyPromptData, null, 2)
            );
        } catch {
            return stripBusinessExplanation(String(modifyPromptData));
        }
    }, [modifyPromptData, parsedNlpOutput]);

    const businessExplanationText =
        parsedNlpOutput?.nlp_decription ||
        parsedNlpOutput?.nlp_description ||
        parsedNlpOutput?.business_explanation ||
        modifyPromptData?.nlp_decription ||
        modifyPromptData?.nlp_description ||
        modifyPromptData?.business_explanation ||
        "";

    /* ================= USER EMAIL ================= */

    useEffect(() => {
        if (accounts.length === 0) return;

        const user = accounts[0];

        const userEmail =
            user.username ||
            user.idTokenClaims?.preferred_username ||
            user.idTokenClaims?.email;

        setEmail(userEmail);
    }, [accounts]);

    /* ================= CLEANUP ================= */

    useEffect(() => {
        return () => {
            if (intervalRef.current) {
                clearInterval(intervalRef.current);
            }
        };
    }, []);

    /* ================= TABLE API ================= */
    const ruleUpdatePlantTable = process.env.NEXT_PUBLIC_RULE_PROMPT_PLANT_TABLE
    const fetchApprovalTable = async () => {
        try {
            const res = await axios.get(
                `${process.env.NEXT_PUBLIC_RECON_API_URL}/rules/update/rule_approvals?table_path=${ruleUpdatePlantTable}`
            );
            const data = res?.data;

            setColumns(data?.columns || []);

            const allRecords = Array.isArray(data?.records)
                ? data.records
                : [];

            const targetRuleId = normalizeRuleId(formData?.rule_id);

            const recordsToShow = allRecords.filter(
                (item) =>
                    normalizeRuleId(item?.rule_id) === targetRuleId
            );

            setTableData(recordsToShow);

            console.log("TABLE DATA 👉", recordsToShow);

            setCurrentPage(1);
        } catch (err) {
            toast.error("Failed to load table ❌");
        }
    };

    /* ================= PAGINATION ================= */

    const totalPages = Math.ceil(tableData.length / rowsPerPage);

    const paginatedData = useMemo(() => {
        const start = (currentPage - 1) * rowsPerPage;

        return tableData.slice(start, start + rowsPerPage);
    }, [tableData, currentPage]);

    /* ================= POLLING ================= */

    const pollResult = (runId, toastId) => {
        intervalRef.current = setInterval(async () => {
            try {
                const res = await axios.get(
                    `${process.env.NEXT_PUBLIC_RECON_API_URL}/recon/rules/update/result?run_id=${runId}`
                );

                const status = res?.data?.status;

                if (status === "RUNNING" || status === "PENDING") return;

                if (
                    status === "SUCCESS" ||
                    status === "success" ||
                    status === "TERMINATED"
                ) {
                    clearInterval(intervalRef.current);

                    toast.success("Run completed successfully 🎉", {
                        id: toastId,
                    });

                    setShowSuccess(true);

                    // ✅ CALL TABLE API
                    fetchApprovalTable();

                    return;
                }

                if (status === "FAILED") {
                    clearInterval(intervalRef.current);

                    toast.error("Run failed ❌", {
                        id: toastId,
                    });
                }
            } catch (err) {
                clearInterval(intervalRef.current);

                toast.error("Polling error ❌", {
                    id: toastId,
                });
            }
        }, 60000);
    };

    /* ================= RUN API ================= */

    const handleRunClick = async () => {
        let toastId;

        if (!selectedPlant) {
            toast.error("Please select plant");
            return;
        }

        try {
            toastId = toast.loading("Running prompt...");

            const payload = {
                request_type: "Rules Update",
                portal: formData?.portal || "TRAC66 & T4 (P66)",
                rule_level: String(formData?.rule_level ?? ""),
                rule_id:
                    parseInt(
                        String(formData?.rule_id).replace(/\D/g, ""),
                        10
                    ) || 0,
                data_source: formData?.data_source,
                rules_priority: Number(formData?.rules_priority || 0),
                rules_severity: formData?.rules_severity,
                rules_order: Number(formData?.rules_order || 0),
                fields: formData?.fields,
                classify: formData?.classify,
                plant_id: selectedPlant,
                requested_by: email,
            };

            console.log("FINAL PAYLOAD 👉", payload);

            const updateRes = await axios.post(
                `${process.env.NEXT_PUBLIC_RECON_API_URL}/recon/rules/update`,
                payload
            );

            console.log("UPDATE API RESPONSE 👉", updateRes?.data);

            const taskRunId = updateRes?.data?.task_run_id;

            if (!taskRunId) {
                throw new Error("No task_run_id received");
            }

            pollResult(taskRunId, toastId);
        } catch (err) {
            console.error(
                "UPDATE ERROR 👉",
                err?.response?.data || err.message
            );

            toast.error("Run failed ❌", {
                id: toastId,
            });
        }
    };

    /* ================= APPROVE API ================= */
    const handleApprove = async () => {

        let toastId;

        try {
            setApproveLoading(true);

            toastId = toast.loading(
                "Approval in progress..."
            );


            const matchedRow = tableData.find(
                (row) =>
                    normalizeRuleId(row?.rule_id) ===
                    normalizeRuleId(formData?.rule_id)
            );

            const payload = {
                request_type: "rule_update_status",

                rule_id: String(
                    formData?.rule_id || ""
                ),

                rule_version: String(
                    dropdownData?.rule_version || "1"
                ),

                // ✅ STATUS FROM DROPDOWN
                approval_status:
                    matchedRow?.approval_status,

                // ✅ EMAIL FROM INPUT
                approved_by:
                    matchedRow?.approved_by,

                trigger_id: String(
                    dropdownData?.trigger_id ||
                    "123245"
                ),
            };
            console.log("APPROVE PAYLOAD 👉", payload);

            // ✅ STEP 1: CALL APPROVE API
            const approveRes = await axios.post(
                `${process.env.NEXT_PUBLIC_RECON_API_URL}/recon/rules/update/approve`,
                payload
            );

            console.log("APPROVE RESPONSE 👉", approveRes?.data);

            // ✅ STEP 2: EXTRACT RUN ID
            const runId =
                approveRes?.data?.task_run_id;

            console.log("RUN ID 👉", runId);

            if (!runId) {
                throw new Error("run_id not found");
            }

            // ✅ STEP 3: WAIT 3 SEC BEFORE POLLING
            setTimeout(() => {
                pollApproveResult(runId, toastId);
            }, 3000);

        } catch (err) {

            console.error(
                "APPROVE ERROR 👉",
                err?.response?.data || err.message
            );

            toast.error("Approval failed ❌", {
                id: toastId,
            });
        }
    };

    const pollApproveResult = (runId, toastId) => {

        console.log("START POLLING 👉", runId);

        const checkStatus = async () => {

            try {

                const res = await axios.get(
                    `${process.env.NEXT_PUBLIC_RECON_API_URL}/recon/rules/update/approve/result?run_id=${runId}`
                );

                console.log("RESULT API RESPONSE 👉", res?.data);

                const metadata = res?.data?.metadata;

                if (!metadata) {
                    console.log("Metadata not ready");
                    return;
                }

                const lifeCycleState =
                    metadata?.state?.life_cycle_state;

                const resultState =
                    metadata?.state?.result_state;

                console.log("LIFECYCLE 👉", lifeCycleState);
                console.log("RESULT 👉", resultState);

                // ✅ KEEP POLLING
                if (
                    lifeCycleState === "QUEUED" ||
                    lifeCycleState === "PENDING" ||
                    lifeCycleState === "RUNNING"
                ) {
                    return;
                }

                // ✅ SUCCESS
                if (
                    lifeCycleState === "TERMINATED" &&
                    resultState === "SUCCESS"
                ) {

                    clearInterval(approveInterval);

                    toast.success(
                        "Approval completed successfully ✅",
                        {
                            id: toastId,
                        }
                    );

                    setShowApproveDialog(false);

                    return;
                }

                // ✅ FAILED
                if (
                    lifeCycleState === "TERMINATED" &&
                    resultState === "SUCCESS"
                ) {

                    clearInterval(approveInterval);

                    setApproveLoading(false);

                    toast.success(
                        "Approval completed successfully ✅",
                        {
                            id: toastId,
                        }
                    );

                    setShowApproveDialog(false);

                    return;
                }

            } catch (err) {

                console.error(
                    "POLLING ERROR 👉",
                    err?.response?.data || err.message
                );
            }
        };

        // ✅ FIRST CALL
        checkStatus();

        // ✅ POLL EVERY 1 MIN
        const approveInterval = setInterval(() => {

            checkStatus();

        }, 60000);

        // ✅ HARD STOP AFTER 1 HOUR
        setTimeout(() => {

            clearInterval(approveInterval);

            console.log("Polling stopped after timeout");

        }, 3600000);
    };
    /* ================= CANCEL ================= */

    const handleCancel = () => {
        if (intervalRef.current) {
            clearInterval(intervalRef.current);
        }

        setShowSuccess(false);
        setTableData([]);
        setColumns([]);
        setCurrentPage(1);
        setSelectedPlant("");
        setShowApproveDialog(false);

        onClose?.();
    };
    // ✅ ADD THIS FUNCTION BELOW handleCancel
    const plantListRuleUpdate = process.env.NEXT_PUBLIC_RULE_PROMPT_PLANT_LIST
    const fetchPlantList = async () => {

        try {

            const res = await axios.get(
                `${process.env.NEXT_PUBLIC_RECON_API_URL}/recon/rules/listofplants/blackline?source_schema_path=${plantListRuleUpdate}`
            );

            console.log(
                "PLANT LIST RESPONSE 👉",
                res?.data
            );

            setPlantOptions(
                Array.isArray(res?.data)
                    ? res.data
                    : []
            );

        } catch (err) {

            console.error(
                "PLANT API ERROR 👉",
                err?.response?.data ||
                err.message
            );

            toast.error(
                "Failed to load plants ❌"
            );
        }
    };
    useEffect(() => {

        fetchPlantList();

    }, []);
    /* ================= SUCCESS UI ================= */

    if (showSuccess) {
        return (
            <>
                {/* ✅ TABLE ABOVE */}
                {columns.length > 0 && (
                    <div className="w-full mb-6 overflow-x-auto">
                        <table className="min-w-full border text-sm border-gray-200 rounded-lg">
                            <thead className="bg-gray-100">
                                <tr>
                                    {columns.map((col) => (
                                        <th
                                            key={col}
                                            className="px-4 py-2 text-left text-xs font-semibold text-gray-600 uppercase border"
                                        >
                                            {col}
                                        </th>
                                    ))}
                                </tr>
                            </thead>

                            <tbody>
                                {paginatedData.map((row, idx) => {

                                    // ✅ MATCH RULE ID
                                    const isMatchedRule =
                                        normalizeRuleId(row?.rule_id) ===
                                        normalizeRuleId(formData?.rule_id);

                                    return (
                                        <tr
                                            key={idx}
                                            className="hover:bg-gray-50"
                                        >

                                            {columns.map((col) => {

                                                // ✅ APPROVED BY INPUT ONLY FOR MATCHED RULE
                                                if (
                                                    col.toLowerCase() === "approved_by"
                                                ) {

                                                    return (
                                                        <td
                                                            key={col}
                                                            className="px-4 py-2 text-xs border"
                                                        >

                                                            {isMatchedRule ? (

                                                                <input
                                                                    type="email"
                                                                    value={
                                                                        row.approved_by ||
                                                                        email
                                                                    }
                                                                    onChange={(e) => {

                                                                        const updated =
                                                                            [...tableData];

                                                                        updated[
                                                                            (
                                                                                currentPage - 1
                                                                            ) *
                                                                            rowsPerPage +
                                                                            idx
                                                                        ] = {
                                                                            ...row,
                                                                            approved_by:
                                                                                e.target.value,
                                                                        };

                                                                        setTableData(
                                                                            updated
                                                                        );
                                                                    }}
                                                                    className="border rounded px-2 py-1 w-full"
                                                                />

                                                            ) : (

                                                                row[col] || "-"

                                                            )}

                                                        </td>
                                                    );
                                                }

                                                // ✅ APPROVAL STATUS DROPDOWN ONLY FOR MATCHED RULE
                                                if (
                                                    col.toLowerCase() === "approval_status"
                                                ) {

                                                    return (
                                                        <td
                                                            key={col}
                                                            className="px-4 py-2 text-xs border"
                                                        >

                                                            {isMatchedRule ? (

                                                                <select
                                                                    value={
                                                                        normalizeApprovalStatus(row.approval_status) === "inprogress"
                                                                            ? ""
                                                                            : row.approval_status?.toLowerCase() || ""
                                                                    }
                                                                    onChange={(e) => {

                                                                        const value = e.target.value;

                                                                        setTableData((prev) =>
                                                                            prev.map((item) => {

                                                                                const isSameRule =
                                                                                    normalizeRuleId(item?.rule_id) ===
                                                                                    normalizeRuleId(row?.rule_id);

                                                                                if (isSameRule) {
                                                                                    return {
                                                                                        ...item,
                                                                                        approval_status: value,
                                                                                    };
                                                                                }

                                                                                return item;
                                                                            })
                                                                        );
                                                                    }}
                                                                    className="border rounded px-2 py-1 w-full"
                                                                >

                                                                    <option value="" disabled>
                                                                        Select Status
                                                                    </option>

                                                                    <option value="approved">
                                                                        Approved
                                                                    </option>

                                                                    <option value="rejected">
                                                                        Rejected
                                                                    </option>

                                                                </select>

                                                            ) : (

                                                                row[col]

                                                            )}

                                                        </td>
                                                    );
                                                }

                                                // ✅ NORMAL CELL
                                                return (
                                                    <td
                                                        key={col}
                                                        className="px-4 py-2 text-xs border"
                                                    >
                                                        {row[col] ?? "-"}
                                                    </td>
                                                );
                                            })}
                                        </tr>
                                    );
                                })}
                                {paginatedData.length === 0 && (
                                    <tr>
                                        <td
                                            colSpan={Math.max(columns.length, 1)}
                                            className="px-4 py-4 text-xs text-gray-500 border text-center"
                                        >
                                            No approval rows found for selected rule
                                        </td>
                                    </tr>
                                )}
                            </tbody>
                        </table>

                        {/* Pagination */}
                        <div className="flex justify-between items-center mt-4">
                            <button
                                className="px-3 py-1 border rounded disabled:opacity-50"
                                disabled={currentPage === 1}
                                onClick={() =>
                                    setCurrentPage((p) => p - 1)
                                }
                            >
                                Prev
                            </button>

                            <span className="text-sm">
                                Page {currentPage} of {totalPages}
                            </span>

                            <button
                                className="px-3 py-1 border rounded disabled:opacity-50"
                                disabled={
                                    currentPage === totalPages ||
                                    totalPages === 0
                                }
                                onClick={() =>
                                    setCurrentPage((p) => p + 1)
                                }
                            >
                                Next
                            </button>
                        </div>
                    </div>
                )}

                {/* SUCCESS UI */}
                <div className="flex flex-col items-center justify-center rounded-lg p-6">
                    <div className="bg-green-100 rounded-full p-3 mb-3">
                        <CheckCircle className="text-green-600 w-6 h-6" />
                    </div>

                    <h2 className="text-lg font-semibold mb-1">
                        Run Completed Successfully
                    </h2>
                    <div className="flex justify-center">

                        <Button
                            className="bg-green-600 text-white"
                            onClick={() => setShowApproveDialog(true)}
                        >
                            Approve
                        </Button>

                        <Button
                            variant="outline"
                            className="ml-3"
                            onClick={handleCancel}
                        >
                            Cancel
                        </Button>
                    </div>

                </div>

                {/* APPROVAL DIALOG */}
                {showApproveDialog && (
                    <div className="fixed inset-0 z-50 text-sm flex items-center justify-center bg-black/40">
                        <div className="bg-white rounded-xl shadow-lg w-[400px] p-6">
                            <h2 className="mb-4">
                                I certify that, As the approver, my
                                sign-off indicates that the following
                                is been completed
                            </h2>

                            <div className="space-y-3 mb-5 text-sm">
                                <label className="flex items-center gap-2">
                                    <input
                                        type="checkbox"
                                        checked={checks.c1}
                                        onChange={() =>
                                            setChecks({
                                                ...checks,
                                                c1: !checks.c1,
                                            })
                                        }
                                    />
                                    The Transaction matching rule has
                                    been updated and successfully
                                    validated.
                                </label>

                                <label className="flex items-center gap-2">
                                    <input
                                        type="checkbox"
                                        checked={checks.c2}
                                        onChange={() =>
                                            setChecks({
                                                ...checks,
                                                c2: !checks.c2,
                                            })
                                        }
                                    />
                                    The Transaction matching rule has
                                    been updated and successfully
                                    validated.
                                </label>
                            </div>

                            <div className="flex justify-end gap-3">
                                <Button
                                    variant="outline"
                                    onClick={() =>
                                        setShowApproveDialog(false)
                                    }
                                >
                                    Close
                                </Button>

                                <Button
                                    disabled={
                                        !(checks.c1 && checks.c2)
                                    }
                                    className="bg-green-600 text-white"
                                    onClick={() => handleApprove()}
                                >
                                    Acknowledge
                                </Button>
                            </div>
                        </div>
                    </div>
                )}
            </>
        );
    }

    /* ================= MAIN UI ================= */

    return (
        <>
            {/* NLP RESPONSE */}
            <div className="w-full mb-4">
                <div className="border rounded-lg p-4 bg-white mb-4">
                    <h4 className="text-primary font-semibold mb-2">
                        Prompt Name
                    </h4>

                    <h4 className="text-primary font-semibold mb-2">
                        System Input
                    </h4>

                    <p className="text-sm text-gray-700 break-words leading-7 text-justify">
                        {String(systemInputText)
                            .replace(/\n/g, " ")
                            .replace(/\s+/g, " ")
                            .trim()}
                    </p>

                    <h4 className="mt-5 text-primary font-semibold mb-2">
                        Business Explanation
                    </h4>

                    <p className="text-sm text-gray-700 break-words whitespace-pre-wrap">
                        {businessExplanationText}
                    </p>
                </div>
            </div>

            {/* MAIN UI */}
            <div className="flex flex-col items-center justify-center min-h-[350px] bg-gray-100 rounded-lg p-6">
                <h2 className="text-red-500 font-semibold text-lg mb-2">
                    RUN PROMPT
                </h2>


                <div className="w-[250px] mb-6">
                    <label className="text-xs font-medium text-gray-600 mb-1 block">
                        Plant
                    </label>

                    <Popover className="relative">
                        {({ close }) => (
                            <>
                                <Popover.Button className="w-full flex justify-between px-3 py-2 text-sm rounded-full bg-[#dceff2]">
                                    {selectedPlant || "Select Plant"}

                                    <ChevronDownIcon className="w-4 h-4" />
                                </Popover.Button>

                                <Popover.Panel className="absolute z-50 mt-1 w-full bg-white rounded-md shadow border h-[150px] overflow-auto">

                                    {plantOptions.length > 0 ? (

                                        plantOptions.map((plant) => (

                                            <div
                                                key={plant}
                                                className="px-3 py-2 text-sm hover:bg-blue-50 cursor-pointer"
                                                onClick={() => {

                                                    setSelectedPlant(
                                                        plant
                                                    );

                                                    close();
                                                }}
                                            >
                                                {plant}
                                            </div>

                                        ))

                                    ) : (

                                        <div className="px-3 py-2 text-sm text-gray-500">
                                            No plants found
                                        </div>

                                    )}

                                </Popover.Panel>
                            </>
                        )}
                    </Popover>
                </div>

                <div className="flex gap-4">
                    <Button
                        variant="outline"
                        onClick={handleCancel}
                    >
                        Cancel
                    </Button>

                    <Button
                        onClick={handleRunClick}
                        className="bg-blue-600 text-white"
                    >
                        Run Prompt
                    </Button>
                </div>
            </div>
        </>
    );
}
