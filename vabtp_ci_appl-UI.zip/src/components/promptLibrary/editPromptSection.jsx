"use client";
import RuleDropdowns from "./ruleDropdowns";

export default function EditPromptSection({
    dropdownData,
    SAPSourceData,
}) {
    return (
        <RuleDropdowns
            dropdownData={dropdownData}
            SAPSourceData={SAPSourceData}
        />
    );
}