"use client";
import { Popover } from "@headlessui/react";
import { ChevronDownIcon } from "@heroicons/react/20/solid";
import React, { useState, useEffect } from "react";
import { useConvertToNlpStore } from "@/store/useConvertToNlpStore";

export default function RuleDropdowns({
  dropdownData,
  SAPSourceData,
  disabled = false,
}) {
  const setFormData = useConvertToNlpStore((s) => s.setFormData);
  console.log("Dropdown Data:", dropdownData);
  // ✅ CLEAN OPTIONS (logic only)
  const severityOptions =
    dropdownData?.severity?.toString().split(",").map(v => v.trim()).filter(Boolean) || [];
  const ruleLevelOptions =
    dropdownData?.rule_level?.toString().split(",").map(v => v.trim()).filter(Boolean) || [];

  const priorityOptions =
    dropdownData?.rule_priority?.toString().split(",").map(v => v.trim()).filter(Boolean) || [];

  const dataSourceOptions =
    dropdownData?.data_set?.toString().split(",").map(v => v.trim()).filter(Boolean) || [];

  const ruleAppliedOptions =
    dropdownData?.rule_applied?.toString().split(",").map(v => v.trim()).filter(Boolean) || [];

  const ruleOrderOptions =
    dropdownData?.rule_priority?.toString().split(",").map(v => v.trim()).filter(Boolean) || [];

  const portalOptions =
    dropdownData?.portal?.toString().split(",").map(v => v.trim()).filter(Boolean) || [];

  const motOptions = SAPSourceData?.mot_list || [];
  const columnOptions = SAPSourceData?.columns || [];

  const updateTop = (key, value) => {
    setFormData((prev) => ({
      ...prev,
      [key]: value,
    }));
  };

  const updateField = (field, key, value) => {
    setFormData((prev) => ({
      ...prev,
      fields: {
        ...prev.fields,
        [field]: {
          ...prev.fields?.[field],
          [key]: value,
        },
      },
    }));
  };

  return (
    <>
      {/* 🔥 TOP SECTION */}
      <div className="grid grid-cols-8 gap-4 mb-3">
        {/* ✅ FIXED portal mapping */}
        <Dropdown
          label="Portal"
          options={dataSourceOptions}
          onSelect={(v) => updateTop("portal", v)}
        />

        <Dropdown
          label="Rule Level"
          options={ruleLevelOptions}
          onSelect={(v) => updateTop("rule_level", v)}
        />

        <Dropdown
          label="Data Source"
          options={dataSourceOptions}
          onSelect={(v) => updateTop("data_source", v)}
        />
      </div>

      <div className="grid grid-cols-8 gap-4 mb-3">
        {/* ✅ FIXED rule_id (STRING) */}
        <Dropdown
          label="Rule Applied (Rule ID)"
          options={ruleAppliedOptions}
          onSelect={(v) => updateTop("rule_id", v)}
        />

        <Dropdown
          label="Rule Priority"
          options={priorityOptions}
          onSelect={(v) => updateTop("rules_priority", Number(v) || 0)}
        />

        <Dropdown
          label="Rule Severity"
          options={severityOptions}
          onSelect={(v) => updateTop("rules_severity", v)}
        />

        <Dropdown
          label="Rule Order"
          options={ruleOrderOptions}
          onSelect={(v) => updateTop("rules_order", Number(v) || 0)}
        />
      </div>

      {/* 🔥 MATCH SECTION */}
      <div className="mt-6 space-y-3">
        <h3 className="text-sm font-semibold text-blue-900">
          IF the following fields match between SAP and TRAC/T4:
        </h3>

        {["MOT", "Product", "BOL", "Date", "Volume"].map((item, index) => (
          <MatchRow
            key={index}
            label={item}
            motOptions={motOptions}
            columnOptions={columnOptions}
            updateField={updateField}
          />
        ))}

        {/* CLASSIFICATION */}
        <div className="mt-6">
          <h3 className="text-sm font-semibold text-blue-900 mb-2">
            THEN classify the transaction as:
          </h3>

          <div className="w-[300px]">
            <Dropdown
              label="Classification"
              options={["Matched", "Variance", "Correction"]}
              onSelect={(v) =>
                setFormData((prev) => ({
                  ...prev,
                  classify: v,
                }))
              }
            />
          </div>
        </div>
      </div>
    </>
  );
}

/* 🔥 MATCH ROW (UNCHANGED CSS) */
function MatchRow({ label, motOptions = [], columnOptions = [], updateField }) {
  const fieldKey = label.toLowerCase();
  const defaultToggle = label !== "BOL" && label !== "Date";

  const [enabled, setEnabled] = useState(defaultToggle);

  useEffect(() => {
    updateField(fieldKey, "toggle", enabled);

    const defaultValue =
      label === "MOT"
        ? motOptions[0]
        : columnOptions[0] || label;

    updateField(fieldKey, "source", defaultValue);
    updateField(fieldKey, "sap", defaultValue);

    if (label === "Date") updateField(fieldKey, "threshold_limit", 3);
    if (label === "Volume") updateField(fieldKey, "threshold_limit", 0.45);
  }, []);

  const handleToggle = (value) => {
    setEnabled(value);
    updateField(fieldKey, "toggle", value);
  };

  return (
    <div className="grid grid-cols-12 gap-3 items-end">
      <div className="col-span-2">
        <Dropdown
          label="Source"
          options={label === "MOT" ? motOptions : columnOptions}
          onSelect={(v) => updateField(fieldKey, "source", v)}
        />
      </div>

      <div className="col-span-2">
        <Dropdown
          label="SAP"
          options={label === "MOT" ? motOptions : columnOptions}
          onSelect={(v) => updateField(fieldKey, "sap", v)}
        />
      </div>

      <div className="col-span-8 flex items-center gap-3">
        <ExactToggle value={enabled} onChange={handleToggle} />

        {(label === "Date" || label === "Volume") && (
          <input
            placeholder="Threshold"
            className="px-3 py-1 text-xs border rounded w-[120px]"
            disabled={!enabled}
            onChange={(e) => {
              const value = e.target.value;
              updateField(
                fieldKey,
                "threshold_limit",
                value === "" ? undefined : Number(value)
              );
            }}
          />
        )}
      </div>
    </div>
  );
}

function ExactToggle({ value, onChange }) {
  return (
    <button
      onClick={() => onChange(!value)}
      className={`w-12 h-6 flex items-center rounded-full p-1 ${value ? "bg-[#0b5cab]" : "bg-[#cfe3ea]"
        }`}
    >
      <div
        className={`w-4 h-4 rounded-full bg-white ${value ? "translate-x-6" : "translate-x-0"
          }`}
      />
    </button>
  );
}

/* 🔥 DROPDOWN (ONLY LOGIC FIX) */
function Dropdown({ label, options = [], disabled, onSelect }) {
  const [selected, setSelected] = useState("");
  const [initialized, setInitialized] = useState(false);

  useEffect(() => {
    if (!initialized && options.length > 0) {
      const defaultValue = options[0];

      setSelected(defaultValue);

      if (defaultValue !== "") {
        onSelect?.(defaultValue);
      }

      setInitialized(true);
    }
  }, [options, initialized]);

  return (
    <div className="flex flex-col gap-1 w-full">
      <label className="text-xs font-medium text-gray-600">{label}</label>

      <Popover className="relative">
        {({ close }) => (
          <>
            <Popover.Button
              disabled={disabled}
              className={`inline-flex w-full items-center justify-between px-2 py-1 text-xs rounded-full
                ${disabled
                  ? "bg-gray-100 text-gray-400"
                  : "bg-[#dceff2] text-gray-700 hover:bg-[#d0f0f5]"
                }`}
            >
              <span className="truncate">
                {selected || `Select`}
              </span>

              {!disabled && (
                <ChevronDownIcon className="ml-1 h-4 w-4 text-gray-400" />
              )}
            </Popover.Button>

            <Popover.Panel className="absolute z-50 mt-1 w-full rounded-md bg-white shadow-lg border border-gray-200 max-h-40 overflow-auto">
              <div className="py-1">
                {options.map((option) => (
                  <div
                    key={option}
                    className="px-3 py-1 text-xs text-gray-700 hover:bg-blue-50 cursor-pointer"
                    onClick={() => {
                      setSelected(option);
                      onSelect?.(option);
                      close();
                    }}
                  >
                    {option}
                  </div>
                ))}
              </div>
            </Popover.Panel>
          </>
        )}
      </Popover>
    </div>
  );
}