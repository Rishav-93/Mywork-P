"use client";

import React, { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Pencil } from "lucide-react";
import { Badge } from "@/components/ui/badge";

import { Popover } from "@headlessui/react";
import { ChevronDownIcon } from "@heroicons/react/24/solid";

export default function BusinessRule() {

  /* ================= DROPDOWN STATES ================= */

  const [portal, setPortal] = useState("");
  const [transport, setTransport] = useState("");
  const [rules, setRules] = useState("");
  const [priority, setPriority] = useState("");
  const [severity, setSeverity] = useState("");

  /* ================= SINGLE SELECT DROPDOWN ================= */

  const SingleSelectDropdown = ({
    options = [],
    selected,
    setSelected,
    placeholder,
    width = "w-[180px]",
  }) => (
    <Popover className={`relative ${width}`}>
      <Popover.Button className="inline-flex w-full items-center justify-between rounded-md px-3 py-2 text-sm border bg-white text-gray-700 border-gray-300 hover:bg-gray-50">
        {selected || placeholder}

        <ChevronDownIcon className="ml-2 h-5 w-5 text-gray-400" />
      </Popover.Button>

      <Popover.Panel className="absolute z-50 mt-1 w-full rounded-md bg-white shadow-lg border border-gray-200">
        <div className="max-h-60 overflow-y-auto py-2">

          {options.map((option) => (
            <div
              key={option}
              onClick={() => setSelected(option)}
              className="px-4 py-2 hover:bg-blue-50 cursor-pointer text-sm text-gray-700"
            >
              {option}
            </div>
          ))}

        </div>
      </Popover.Panel>
    </Popover>
  );

  return (
    <div className="w-full p-6 space-y-6 bg-white rounded-xl border">

      {/* ================= PROMPT HEADER ================= */}

      <div className="border rounded-lg p-4 space-y-3">

        <div className="flex justify-between items-center">

          <h2 className="text-red-500 font-semibold text-lg">
            PROMPT
          </h2>

          <Badge
            variant="outline"
            className="text-red-500 border-red-400"
          >
            Drafted
          </Badge>

        </div>

        <span className="font-semibold text-sm">
          PROMPT VERSION 1.3
        </span>

        <div className="flex items-center gap-3">

          <Button className="text-white bg-primary">
            Save
          </Button>

          <Button
            size="icon"
            variant="outline"
            className="bg-transparent border-none"
          >
            <Plus className="h-4 w-4" />
          </Button>

          <Button
            size="icon"
            variant="outline"
            className="bg-transparent border-none"
          >
            <Pencil className="h-4 w-4" />
          </Button>

        </div>

      </div>

      {/* ================= SYSTEM BOX ================= */}

      <div className="border rounded-lg p-4 space-y-2">

        <h3 className="text-primary font-semibold">
          System
        </h3>

        <p className="text-sm text-gray-600">
          You are a Highly Skilled Reconciliation Engine Designed to Match
          Records. Operate with Precision, Accuracy, Critical Analysis.
        </p>

      </div>

      {/* ================= DROPDOWNS ================= */}

      <div className="flex flex-wrap gap-3">

        <SingleSelectDropdown
          options={["Trac66", "T4"]}
          selected={portal}
          setSelected={setPortal}
          placeholder="Portal"
        />

        <SingleSelectDropdown
          options={["Air", "Sea", "Road"]}
          selected={transport}
          setSelected={setTransport}
          placeholder="Mode Of Transport"
          width="w-[200px]"
        />

        <SingleSelectDropdown
          options={["Rule 1", "Rule 2"]}
          selected={rules}
          setSelected={setRules}
          placeholder="Rules Applied (Rule ID)"
          width="w-[220px]"
        />

        <SingleSelectDropdown
          options={["High", "Medium", "Low"]}
          selected={priority}
          setSelected={setPriority}
          placeholder="Rules Priority"
        />

        <SingleSelectDropdown
          options={["Critical", "Major", "Minor"]}
          selected={severity}
          setSelected={setSeverity}
          placeholder="Rules Severity"
        />

      </div>

      {/* ================= MATCHING FIELDS ================= */}

      <div className="space-y-3">

        <h4 className="text-primary font-semibold text-sm">
          IF the following fields match between SAP and TRAC/T4:
        </h4>

        <div className="flex items-center gap-3">

          <SingleSelectDropdown
            options={[
              "BOL",
              "Batch",
              "NomKey",
              "Truck no.",
              "Product",
              "Volume",
            ]}
            selected=""
            setSelected={() => { }}
            placeholder="Field 1"
          />

          <SingleSelectDropdown
            options={[
              "BOL",
              "Batch",
              "NomKey",
              "Truck no.",
              "Product",
              "Volume",
            ]}
            selected=""
            setSelected={() => { }}
            placeholder="Field 2"
          />

          <SingleSelectDropdown
            options={[
              "BOL",
              "Batch",
              "NomKey",
              "Truck no.",
              "Product",
              "Volume",
            ]}
            selected=""
            setSelected={() => { }}
            placeholder="Field 3"
          />

        </div>

      </div>

      {/* ================= CLASSIFICATION ================= */}

      <div className="space-y-3">

        <h4 className="text-primary font-semibold text-sm">
          Classification
        </h4>

        <Input placeholder="Classification" />

      </div>

      {/* ================= ACTION BUTTONS ================= */}

      <div className="flex gap-3 pt-4">

        <Button
          variant="outline"
          className="text-primary bg-[#F2F2F2]"
        >
          Save
        </Button>

        <Button
          variant="outline"
          className="bg-[#F2F2F2] text-primary"
        >
          Run Prompt
        </Button>

        <Button className="bg-primary text-white">
          Send For Approval
        </Button>

      </div>

    </div>
  );
}