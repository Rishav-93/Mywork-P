"use client";
import React, { useState } from "react";
import RunPrompt from "./runPrompt";


export default function NlpDescription({ data }) {
    const formattedText = `Notebook exited: ${JSON.stringify(data)}`;
    // Show RunPrompt if data.nlpresult or data.data is present
    const isNlpPresent = !!data?.nlpresult;

    return (
        <div className="border rounded-lg p-4 bg-white mb-4">
            <h4 className="text-primary font-semibold mb-2">
                Prompt Name
            </h4>

            <h4 className="text-primary font-semibold mb-2">
                System  Input
            </h4>

            <p className="text-sm text-gray-700 break-words">
                {formattedText}
            </p>
            <h4 className="mt-5 text-primary font-semibold mb-2">
                Business Explanation
            </h4>
            <p className="text-sm text-gray-700 break-words">
                {data?.nlp_decription}
            </p>

        </div>
    );
}