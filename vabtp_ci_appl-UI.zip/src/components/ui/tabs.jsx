"use client";

import * as React from "react";
import * as TabsPrimitive from "@radix-ui/react-tabs";
import { cn } from "@/lib/utils";

const Tabs = TabsPrimitive.Root;

const TabsList = React.forwardRef(
  ({ className, variant = "default", ...props }, ref) => (
    <TabsPrimitive.List
      ref={ref}
      className={cn(
        variant === "line"
          ? "flex border-b border-border-muted"
          : "inline-flex h-10 items-center justify-center rounded-md  p-1 text-muted-foreground",
        className,
      )}
      {...props}
    />
  ),
);
TabsList.displayName = TabsPrimitive.List.displayName;

const TabsTrigger = React.forwardRef(
  ({ className, variant = "default", ...props }, ref) => (
    <TabsPrimitive.Trigger
      ref={ref}
      className={cn(
        variant === "line"
          ? `
            relative px-4 py-2 text-sm font-semibold text-[#000]
            border-b-2 border-transparent
            data-[state=active]:text-[#EF1C26] data-[state=active]:border-black
            after:absolute after:left-0 after:-bottom-[1px]
            after:h-[2px] after:w-full after:bg-transparent
            data-[state=active]:after:bg-black
          `
          : `
            inline-flex items-center justify-center whitespace-nowrap
            px-3 py-1.5 text-sm font-medium
            transition-all text-[#000]
            border-b-2 border-transparent
            data-[state=active]:bg-background
            data-[state=active]:text-foreground
            data-[state=active]:shadow-sm
            data-[state=active]:border-black
          `,
        className,
      )}
      {...props}
    />
  ),
);

TabsTrigger.displayName = TabsPrimitive.Trigger.displayName;

const TabsContent = React.forwardRef(({ className, ...props }, ref) => (
  <TabsPrimitive.Content
    ref={ref}
    className={cn("mt-4", className)}
    {...props}
  />
));
TabsContent.displayName = TabsPrimitive.Content.displayName;

export { Tabs, TabsList, TabsTrigger, TabsContent };
