import React from "react";
import { Check } from "lucide-react";
import { useReconStore } from "@/store/reconStore";

/* ---------- AGGREGATE STATUS ---------- */
// const getAggregatedStatus = (records, key) => {
//   if (!records.length) return "pending";

//   const statuses = records.map((r) => r[key]?.toLowerCase());

//   if (statuses.some((s) => s?.includes("fail"))) return "failed";
//   if (statuses.some((s) => s?.includes("run"))) return "running";
//   if (statuses.every((s) => s === "success")) return "completed";

//   return "pending";
// };
const getAggregatedStatus = (records, key) => {
  if (!records.length) return "pending";

  // ✅ ONLY use All Plants row
  const allPlant = records.find(r => r.plant_id === "All Plants");

  if (!allPlant) return "pending";

  const status = allPlant[key]?.toLowerCase();

  if (status?.includes("fail")) return "failed";
  if (status?.includes("run")) return "running";
  if (status === "success") return "completed";

  return "pending";
};

/* ---------- PROGRESS (ONLY FIRST 3) ---------- */
const getProgress = (steps) => {
  let progress = 0;

  steps.forEach((step) => {
    if (step.status === "completed") progress += 1;
    if (step.status === "running") progress += 0.5;
  });

  return (progress / steps.length) * 100;
};

export default function ReconProgressBar() {
  const { response } = useReconStore();
  const records = response?.records || [];

  const steps = [
    {
      label: "Data Extraction",
      status: getAggregatedStatus(records, "ingest_status"),
    },
    {
      label: "Data Preparation",
      status: getAggregatedStatus(records, "prep_status"),
    },
    {
      label: "Transaction Matching",
      status: getAggregatedStatus(records, "recon_status"),
    },
    {
      label: "Open Item Analysis",
      status: "pending",
    },
    {
      label: "Upload To Blackline",
      status: "pending",
    },
  ];

  const first3Steps = steps.slice(0, 3);
  const progressPercent = getProgress(first3Steps);

  /* 🔥 LIMIT WIDTH TO FIRST 3 STEPS ONLY */
  const progressWidth = (progressPercent / 100) * (3 / steps.length) * 100;

  return (
    <div className="w-full rounded-xl">
      <div className="px-8 py-6">
        <h2 className="mb-8 text-center text-2xl font-bold text-[#0f172a]">
          Volumetric Reconciliation
        </h2>

        <div className="relative flex justify-between items-start">

          {/* FULL GREY TRACK */}
          <div className="absolute left-6 right-6 top-5 h-1 rounded bg-[#e9e1db]" />

          {/* 🔥 LIMITED BLUE TRACK (ONLY FIRST 3 STEPS AREA) */}
          <div
            className="absolute left-6 top-5 h-1 rounded bg-[#06b6d4] transition-all duration-1000 ease-out"
            style={{
              width: `${progressWidth}%`,
              boxShadow: "0 0 8px rgba(6,182,212,0.7)",
            }}
          />

          {steps.map((step, index) => {
            const completed = step.status === "completed";
            const running = step.status === "running";
            const pending = step.status === "pending";
            const failed = step.status === "failed";

            return (
              <div
                key={index}
                className="relative z-10 flex flex-col items-center"
              >

                <div
                  className={`flex h-10 w-10 items-center justify-center rounded-full border-2
                  ${completed
                      ? "border-green-500 bg-white"
                      : running
                        ? "border-amber-400 bg-white"
                        : failed
                          ? "border-red-500 bg-white"
                          : "border-gray-300 bg-white"
                    }`}
                >
                  <div
                    className={`flex h-6 w-6 items-center justify-center rounded-full
                    ${completed
                        ? "bg-green-500"
                        : running
                          ? "bg-amber-400 animate-pulse"
                          : failed
                            ? "bg-red-500"
                            : "bg-gray-300"
                      }`}
                  >
                    {completed && (
                      <Check size={14} className="text-white" />
                    )}
                  </div>
                </div>

                <div className="mt-4 w-36 bg-white text-center rounded-sm shadow-sm">
                  <div className="px-3 py-2 text-xs rounded-sm font-semibold border border-[#E1B3B3]">

                    <p className="text-xs text-[#25546E]">
                      {step.label}
                    </p>

                    {running && (
                      <div className="text-xs text-amber-500 font-semibold">
                        Running
                      </div>
                    )}

                    {completed && (
                      <div className="text-xs text-green-600 font-semibold">
                        Completed
                      </div>
                    )}

                    {failed && (
                      <div className="text-xs text-red-600 font-semibold">
                        Failed
                      </div>
                    )}

                    {pending && (
                      <div className="text-xs text-gray-400 font-semibold">
                        Waiting
                      </div>
                    )}

                  </div>
                </div>

              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}