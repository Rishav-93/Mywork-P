import React from "react";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import TracReconTable from "./tracReconTable";
import { useReconStore } from "@/store/reconStore";

/**
 * API → Table mapper
 */
const mapApiToTableData = (records = []) => {
  return records.map((item, index) => ({
    id: index + 1,

    runId: item.run_id || "-",
    batch: item.batch_number || "-",
    plantId: item.plant_id || "-",

    precheckStatus: item.precheck_status || "NOT_STARTED",

    remark:
      item.error_message && item.error_message !== "No error"
        ? item.error_message
        : "",

    downloadUrl: item.url || null,
  }));
};

export default function ReconTableTabs() {
  const { response } = useReconStore();
  // const { loading, response, isPolling, progress } = useReconStore();
  // const tableData = mapApiToTableData(response?.records || []);
  const tableData = response?.records || [];
  // normalize warehouse status values
  const isFailedRow = (r) => {
    const statuses = [
      r.precheck_status,
      r.ingest_status,
      r.prep_status,
      r.recon_status,
      r.export_status,
      r.review_status,
    ];

    return statuses.some(
      (status) =>
        status &&
        String(status).trim().toLowerCase() === "failed"
    );
  };
  const success = tableData.filter(
    (r) => r.recon_status === "Success"
  );
  console.log(success, "syukk");
  const failData = tableData.filter(isFailedRow);

  console.log("FAILED ROWS:", failData);
  console.log(failData, "failed")
  return (
    <div className="w-full bg-white rounded-md border border-border-muted p-4">
      <Tabs defaultValue="all">
        <div className="flex justify-between items-center mb-4">
          <TabsList className="gap-2" variant="line">
            <TabsTrigger value="all">All RECON</TabsTrigger>
            <TabsTrigger value="completed">COMPLETED</TabsTrigger>
            <TabsTrigger value="failed">FAILED</TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="all">
          <TracReconTable data={tableData} />
        </TabsContent>

        <TabsContent value="completed">
          <TracReconTable
            data={success}
          />
        </TabsContent>

        <TabsContent value="failed">
          <TracReconTable
            data={failData}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
}
