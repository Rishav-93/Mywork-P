"use client";

import React, { useState } from "react";
import ReconProgress from "./reconProgressBar";
import ReconTableTabs from "./reconTableTabs";

import {
  Calendar,
  Clock,
  ChevronDown,
  AlertTriangle,
} from "lucide-react";

import { Button } from "@/components/ui/button";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";

import { useReconStore } from "@/store/reconStore";
import { useMsal } from "@azure/msal-react";
import { useAuthStore } from "@/store/auth";

export default function Trac66() {

  const [showConfirm, setShowConfirm] = useState(false);
  const reconIframeUrl = process.env.NEXT_PUBLIC_RECONDETAILS_IFRAME_URL
  const {
    runRecon,
    loading,
    response,
    isPolling,
    currentTriggerId,
    selectedDate,
    setSelectedDate,
    resetRecon,
    hasHydrated
  } = useReconStore();

  const { accounts } = useMsal();
  const role = useAuthStore((s) => s.role);

  const userEmail =
    accounts?.[0]?.username ||
    accounts?.[0]?.idTokenClaims?.email ||
    "unknown@example.com";

  /* ============================ DERIVED STATE ============================ */
  const progress = useReconStore((s) => s.progress);
  const shouldShowWorkspace =
    hasHydrated &&
    (isPolling ||
      currentTriggerId ||
      (response && response.records?.length > 0));

  /* ============================ HELPERS ============================ */

  const generateTriggerId = () => {
    return Math.floor(100000 + Math.random() * 900000);
  };
  function ReconProgressBar({ value }) {
    const safeValue = value >= 100 ? 100 : value;

    return (
      <div className="w-full max-w-md mx-auto">

        <div className="flex justify-between text-sm mb-2">
          <span className="text-gray-500 font-medium">
            Processing reconciliation
          </span>
          <span className="font-semibold text-primary">
            {safeValue}%
          </span>
        </div>

        <div className="w-full h-4 bg-gray-200 rounded-full overflow-hidden shadow-inner relative">

          <div
            className="h-full relative rounded-full transition-all duration-700 ease-out bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 shadow-lg"
            style={{ width: `${safeValue}%` }}
          >
            <div className="absolute inset-0 animate-progress opacity-40"></div>
          </div>

        </div>
      </div>
    );
  }
  const formatMonthYear = (date) => {

    if (!date) return null;

    const parsedDate =
      typeof date === "string" ? new Date(date) : date;

    if (isNaN(parsedDate.getTime())) return null;

    const year = parsedDate.getFullYear();
    const month = String(parsedDate.getMonth() + 1).padStart(2, "0");

    return `${month}-${year}`;
  };

  /* ============================ HANDLERS ============================ */

  const handleStart = () => {

    if (!selectedDate) return;

    setShowConfirm(true);
  };

  const handleCancel = () => {
    setShowConfirm(false);
  };

  const handleConfirm = async () => {

    try {

      setShowConfirm(false);

      const payload = {
        recon_type: "batch",
        trigger_type: "MANUAL",
        requested_by: userEmail,
        request_type: "batch",
        trigger_id: generateTriggerId(),
        run_date: formatMonthYear(selectedDate),
      };

      console.log("🚀 Starting Recon:", payload);

      await runRecon(payload);

    } catch (err) {

      console.error("Recon Failed:", err);

    }
  };

  /* ============================ HYDRATION LOADER ============================ */

  if (!hasHydrated) {

    return (
      <div className="flex h-[calc(100vh-132px)] items-center justify-center">
        <p className="text-sm text-gray-500">Loading workspace...</p>
      </div>
    );
  }

  /* ============================ UI ============================ */

  return (
    <div className="relative">

      {/* ================= TOP CONTROLS ================= */}

      <div className="mb-4 flex items-center justify-between">

        <div className="flex items-center gap-3">

          {["P66_VABTP_CG_LEAD"].includes(role) && (

            <>
              <div className="flex items-center gap-2 rounded-md border bg-white px-3 py-2 shadow-sm">

                <Calendar className="h-4 w-4 text-[#EF1C26]" />

                <DatePicker
                  selected={selectedDate}
                  onChange={(d) => setSelectedDate(d)}
                  placeholderText="Select month"
                  dateFormat="MM/yyyy"
                  showMonthYearPicker
                  showFullMonthYearPicker
                  maxDate={new Date()}
                  className="w-[130px] cursor-pointer bg-transparent text-sm text-[#25546E] outline-none"
                />

                <ChevronDown className="h-4 w-4 text-[#25546E]" />

              </div>

              <Button
                onClick={handleStart}
                disabled={loading || isPolling}
                className="bg-[#064687] px-4 py-2 text-sm font-semibold text-white"
              >
                START
              </Button>
            </>
          )}

          <div className="flex items-center gap-2 rounded-md border bg-white px-3 py-2 shadow-sm">
            <Clock className="h-4 w-4 text-[#25546E]" />
            <span className="text-sm text-[#25546E]">Time</span>
            <ChevronDown className="h-4 w-4 text-[#25546E]" />
          </div>

          <Button
            variant="outline"
            disabled
            className="px-5 py-2 text-sm font-semibold text-[#064687]"
          >
            Schedule
          </Button>

          <Button
            onClick={resetRecon}
            disabled={!isPolling}
            className="bg-red-600 hover:bg-red-700 text-white px-4 py-2 text-sm font-semibold"
          >
            STOP
          </Button>

        </div>

      </div>

      {/* ================= WELCOME ================= */}

      {!shouldShowWorkspace && (

        <div className="flex h-[calc(100vh-132px)] items-center justify-center rounded-lg bg-white shadow-sm">

          <div className="text-center">

            <p className="text-xl font-semibold text-[#EF1C26]">
              WELCOME
            </p>

            <p className="text-sm tracking-wide text-gray-500">
              TO THE RECONCILIATION WORKSPACE
            </p>

          </div>

        </div>
      )}

      {/* ================= CONFIRM MODAL ================= */}

      {showConfirm && (

        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/40">

          <div className="w-[380px] rounded-lg bg-white p-6 shadow-lg">

            <h3 className="mb-2 text-[22px] font-semibold text-[#EF1C26]">
              REPOSITORY REQUIREMENTS
            </h3>

            <ul className="mb-5 list-decimal space-y-1 pl-5 text-xs text-black">

              <li>Blackline Recon Report</li>
              <li>TOR Report</li>
              <li>Transactional Report</li>
              <li>SAP Report</li>

            </ul>

            <div className="flex items-center gap-2 mb-3">

              <AlertTriangle className="h-4 w-4 text-[#EF1C26]" />
              <p>Missing Files can cause run to fail.</p>

            </div>

            <div className="flex justify-end gap-3">

              <Button variant="outline" onClick={handleCancel}>
                Cancel
              </Button>

              <Button
                onClick={handleConfirm}
                disabled={loading}
                className="bg-[#EF1C26] text-white"
              >
                {loading ? "Processing..." : "Confirm"}
              </Button>

            </div>

          </div>

        </div>
      )}

      {/* ================= WORKSPACE ================= */}

      {shouldShowWorkspace && (
        <>
          <ReconProgress value={progress} />
          {/* <ReconTableTabs /> */}
          <div style={{ height: 'calc(100vh - 80px)', overflow: 'hidden' }}>
            <div className=" flex items-center justify-center bg-white/70 mb-3">
              <ReconProgressBar value={isPolling ? progress : 100} />
            </div>
            <iframe
              src={reconIframeUrl}
              width="100%"
              height="100%"
              frameBorder="0"
              style={{ border: 'none' }}
              title="Databricks Dashboard"
            />
          </div>
        </>
      )}

    </div>
  );
}