"use client";

import React from "react";

import {
  Table,
  TableHeader,
  TableBody,
  TableRow,
  TableHead,
  TableCell,
} from "@/components/ui/table";

import { Button } from "@/components/ui/button";
import { Download, Eye } from "lucide-react";

import { useReconStore } from "@/store/reconStore";
import { useApproveStore } from "@/store/approveStore";

/* ================= PROGRESS ================= */
function ReconProgressBar({ value }) {
  return (
    <div className="w-full max-w-md mx-auto">

      {/* STATUS TEXT */}
      <div className="flex justify-between text-sm mb-2">
        <span className="text-gray-500 font-medium">Processing reconciliation</span>
        <span className="font-semibold text-primary">{value}%</span>
      </div>

      {/* BAR CONTAINER */}
      <div className="w-full h-4 bg-gray-200 rounded-full overflow-hidden shadow-inner relative">

        {/* PROGRESS */}
        <div
          className="h-full relative rounded-full transition-all duration-700 ease-out bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 shadow-lg"
          style={{ width: `${value}%` }}
        >

          {/* SHIMMER EFFECT */}
          <div className="absolute inset-0 animate-progress opacity-40"></div>

        </div>

      </div>

    </div>
  );
}
/* ================= STATUS ================= */
const getStatusStyle = (status) => {
  switch (status) {
    case "Success":
      return " text-green-600 text-bold";
    case "Running":
      return " text-yellow-600 text-bold";
    case "Failed":
      return " text-red-600 text-bold";
    default:
      return " text-gray-500 text-bold";
  }
};

/* ================= MAIN ================= */
export default function TracReconTable({ data }) {
  const { loading, response, isPolling, progress } = useReconStore();
  const setPlantIds = useApproveStore((s) => s.setPlantIds);

  // const data = response?.records || [];
  const handleDownload = () => {

  }
  console.log(data, "success Data")

  return (
    <div className="w-full bg-white rounded-md border p-4 relative">

      {/* OVERLAY */}
      {isPolling && (
        <div className="absolute inset-0 z-10 flex items-center justify-center bg-white/70">
          {/* <ReconProgressBar value={progress} /> */}
        </div>
      )}

      <Table className={isPolling ? "opacity-40" : ""}>

        {/* HEADER */}
        <TableHeader>
          <TableRow>
            {/* <TableHead>Run ID</TableHead>
            <TableHead>Batch</TableHead> */}
            <TableHead>Plant</TableHead>
            <TableHead>Status</TableHead>
            <TableHead>Remarks</TableHead>
            <TableHead>Download</TableHead>

          </TableRow>
        </TableHeader>

        <TableBody>

          {/* LOADING FIRST TIME */}
          {loading && data.length === 0 && (
            <TableRow>
              <TableCell colSpan={7} className="text-center py-8">
                Loading...
              </TableCell>
            </TableRow>
          )}

          {/* DATA */}
          {!loading &&
            data
              .filter(
                (row) =>
                  row.plant_id &&
                  row.plant_id.toLowerCase() !== "all plants"
              )
              .map((row) => {
                const style = getStatusStyle(row.precheck_status);

                return (
                  <TableRow key={`${row.run_id}-${row.plant_id}`}>
                    <TableCell>{row.plant_id}</TableCell>

                    <TableCell>
                      <span className={`px-2 py-1 rounded text-xs ${style}`}>
                        {row.precheck_status}
                      </span>
                    </TableCell>

                    <TableCell>
                      {row.error_message || "—"}
                    </TableCell>

                    <TableCell>
                      {row.url ? (
                        <Button
                          className="bg-transparent hover:bg-transparent"
                          size="sm"
                          onClick={() => window.open(row.url)}
                        >
                          <Download size={14} />
                        </Button>
                      ) : (
                        "—"
                      )}
                    </TableCell>
                  </TableRow>
                );
              })}


          {/* EMPTY */}
          {!loading && !isPolling && data.length === 0 && (
            <TableRow>
              <TableCell
                colSpan={7}
                className="text-center py-6 text-gray-400"
              >
                No records found
              </TableCell>
            </TableRow>
          )}

        </TableBody>
      </Table>
    </div>
  );
}
