"use client";

import Link from "next/link";
import Image from "next/image";
import { usePathname } from "next/navigation";
import { LogOut } from "lucide-react";
import { useMsal } from "@azure/msal-react";

import { useAuthStore } from "@/store/auth";
import { useReconStore } from "@/store/reconStore";

import UniLogo from "@/assets/images/uni-logo.png";
import Logout from "../common/logout";

const menuData = [
  {
    title: "Reconciliation",
    href: "/",
  },
  {
    title: "Dashboard",
    href: "/dashboard",
  },
  {
    title: "Reconciliation Details",
    href: "/reconciliationDetails",
  },
  {
    title: "Prompt Library",
    href: "/promptLibrary",
  },
  {
    title: "Varied Template",
    href: "/variedTemplate",
  },

];

export default function Sidebar() {
  const pathname = usePathname();

  return (
    <aside className="col-span-2 min-h-screen flex flex-col shadow bg-[#002858] p-4 px-3 rounded-xl border border-border-muted">

      {/* ================= LOGO ================= */}
      <div className="text-center mb-4">
        <Image
          src={UniLogo}
          alt="Logo"
          className="mx-auto w-20 h-20 object-contain"
        />
        <div className="mt-2 font-semibold text-lg text-[#fff]">
          PHILLIPS 66
        </div>
      </div>

      {/* ================= MENU ================= */}
      <nav className="mb-6">
        {menuData.map((m) => {
          const active =
            pathname === m.href ||
            (m.href !== "/" && pathname?.startsWith(m.href));

          return (
            <Link
              key={m.title}
              href={m.href}
              className={`flex items-center px-3 py-2 rounded-md mb-1 text-sm font-semibold transition-colors
              ${active
                  ? "text-[#101921] bg-[#CEE5E8]"
                  : "text-[#F2F2F2] hover:bg-[#CEE5E8] hover:text-[#101921]"
                }`}
            >
              {m.title}
            </Link>
          );
        })}
      </nav>

      {/* ================= LOGOUT (BOTTOM) ================= */}
      <div className="mt-auto pt-4 border-t mb-4 border-white/20">

        <Logout />

      </div>
    </aside>
  );
}
