"use client";

import { Button } from "@/components/ui/button";
import { ChevronDown } from "lucide-react";
import {
  Combobox,
  ComboboxContent,
  ComboboxEmpty,
  ComboboxInput,
  ComboboxItem,
  ComboboxList,
  ComboboxTrigger,
  ComboboxValue,
} from "@/components/ui/combobox";

export default function Dropdown({
  items = [],
  defaultValue = null,
  onChange = () => {},
  placeholder = "Search...",
  className = "w-56",
  showIcon = true,
}) {
  return (
    <Combobox
      items={items}
      defaultValue={defaultValue ?? items[0] ?? null}
      onValueChange={(val) => onChange(val)}
    >
      <ComboboxTrigger
        render={
          <Button
            variant="outline"
            className={`${className} justify-between font-normal bg-white border border-slate-200 shadow-sm rounded-md text-slate-700`}
          >
            <ComboboxValue />
            <ChevronDown className="size-4 text-slate-400 ml-2" />
          </Button>
        }
      />

      <ComboboxContent>
        <ComboboxInput showTrigger={false} placeholder={placeholder} />
        <ComboboxEmpty>No items found.</ComboboxEmpty>

        <ComboboxList>
          {(item) => (
            <ComboboxItem key={item.value ?? item.label} value={item}>
              <div className="flex items-center">
                {showIcon && item.icon && (
                  <item.icon className="size-4 mr-2 text-slate-400" />
                )}
                <span>{item.label}</span>
              </div>
            </ComboboxItem>
          )}
        </ComboboxList>
      </ComboboxContent>
    </Combobox>
  );
}
