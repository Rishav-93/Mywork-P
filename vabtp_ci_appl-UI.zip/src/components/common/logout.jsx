"use client";

import { useEffect, useState } from "react";
import { useMsal } from "@azure/msal-react";
import {
  InteractionRequiredAuthError,
  InteractionStatus,
} from "@azure/msal-browser";

import { useAuthStore } from "@/store/auth";
import { useReconStore } from "@/store/reconStore";

import { Button } from "@base-ui/react";
import { LogOut } from "lucide-react";

export default function Logout() {
  const { instance, accounts, inProgress } = useMsal();
  const [email, setEmail] = useState("");
  const [userName, setUserName] = useState("");
  const [profilePic, setProfilePic] = useState(null);

  /* ================= USER LOAD ================= */
  useEffect(() => {
    if (inProgress !== InteractionStatus.None || accounts.length === 0) return;

    const user = accounts[0];

    const userEmail =
      user.username ||
      user.idTokenClaims?.preferred_username ||
      user.idTokenClaims?.email;

    // Remove company part from name
    const cleanName = user.name?.replace(/\s*\(.*?\)\s*/g, "").trim();

    setUserName(cleanName);
    setEmail(userEmail);

    // Fetch profile picture
    // Fetch profile picture
    const fetchProfilePic = async () => {
      try {
        let tokenResponse;

        try {
          tokenResponse = await instance.acquireTokenSilent({
            account: user,
            scopes: ["User.Read"],
          });
        } catch (error) {
          // 🔥 If silent fails, fallback to redirect
          if (error instanceof InteractionRequiredAuthError) {
            await instance.acquireTokenRedirect({
              account: user,
              scopes: ["User.Read"],
            });
            return;
          }
          throw error;
        }

        const graphResponse = await fetch(
          "https://graph.microsoft.com/v1.0/me/photo/$value",
          {
            headers: {
              Authorization: `Bearer ${tokenResponse.accessToken}`,
            },
          }
        );

        if (graphResponse.ok) {
          const blob = await graphResponse.blob();

          // ✅ Convert to base64 (more reliable than createObjectURL in prod)
          const reader = new FileReader();
          reader.onloadend = () => {
            setProfilePic(reader.result);
          };
          reader.readAsDataURL(blob);
        } else {
          console.warn("No profile photo found:", graphResponse.status);
        }
      } catch (err) {
        console.error("Failed to fetch profile photo:", err);
      }
    };


    fetchProfilePic();
  }, [accounts, inProgress, instance]);

  /* ================= STORE RESET ================= */
  const clearRole = useAuthStore((s) => s.setRole);
  const resetRecon = useReconStore((s) => s.resetRecon);

  /* ================= LOGOUT ================= */
  const handleLogout = async () => {
    try {
      clearRole(null);
      // localStorage.clear();
      sessionStorage.clear();

      document.cookie.split(";").forEach((c) => {
        document.cookie = c
          .replace(/^ +/, "")
          .replace(
            /=.*/,
            "=;expires=" + new Date(0).toUTCString() + ";path=/"
          );
      });

      await instance.logoutRedirect({
        postLogoutRedirectUri:
          typeof window !== "undefined"
            ? window.location.origin
            : process.env.NEXT_PUBLIC_REDIRECT_URI,
      });
    } catch (err) {
      console.error("Logout failed:", err);
    }
  };

  return (
    <div className="flex justify-center items-center gap-3  ">
      {/* Profile Section */}


      {/* Logout Button */}
      <Button
        onClick={handleLogout}
        className="flex  items-center gap-2 rounded border border-red-200 bg-[#CEE5E8] px-3 py-2 text-[#EF1C26] hover:bg-red-100 rounded-[50px]"
      >
        {profilePic ? (
          <img
            src={profilePic}
            alt="Profile"
            className="w-10 h-10 rounded-full object-cover"
          />
        ) : (
          <div className="w-6 h-6 rounded-full bg-gray-300 flex items-center justify-center text-xs text-white">
            {userName?.charAt(0)}
          </div>
        )}
        <span className="text-md text-black max-w-[180px] truncate">
          {userName}
        </span>
        <LogOut className="w-5 h-5" />

      </Button>
    </div>
  );
}
