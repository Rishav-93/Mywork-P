import React from "react";
import { Button } from "@/components/ui/button";
import { Plus, Pencil } from "lucide-react";
export default function PromptChat() {
  return (
    <div className="   h-full bg-white border border-[#D1C8BE] rounded-lg p-4 flex flex-col gap-4">
      {/* Title */}
      <h2 className="text-sm font-semibold text-gray-700 uppercase">
        Prompt Settings
      </h2>

      {/* Dropdown */}
      <select className="w-full border rounded-md px-3 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-blue-500">
        <option>Prompt Version 1.3</option>
        <option>Prompt Version 1.2</option>
        <option>Prompt Version 1.1</option>
      </select>

      {/* Text Area */}
      <textarea
        placeholder="Enter Prompt"
        className="w-full h-60 border rounded-md p-3 text-sm resize-none focus:outline-none focus:ring-2 focus:ring-blue-500"
      />
      <div className="flex gap-3 text-gray-500 text-lg">
        {/* Add Button */}
        <Button variant="ghost" size="icon" className="hover:text-blue-600">
          <Plus size={20} />
        </Button>

        {/* Edit Button */}
        <Button variant="ghost" size="icon" className="hover:text-blue-600">
          <Pencil size={20} />
        </Button>
      </div>
      {/* Bottom Buttons */}
      <div className="flex flex-col gap-2 mt-auto">
        <Button className="w-full bg-primary text-white py-2 rounded-md hover:border hover:border-primary hover:text-primary hover:bg-transparent transition">
          Apply
        </Button>
        <Button className="ww-full bg-primary text-white py-2 rounded-md hover:border hover:border-primary hover:text-primary hover:bg-transparent transition">
          Prompt Library
        </Button>

        {/* <Button className="ww-full bg-primary text-white py-2 rounded-md hover:border hover:border-primary hover:text-primary hover:bg-transparent transition">
          Upload Document
        </Button> */}
      </div>
    </div>
  );
}
