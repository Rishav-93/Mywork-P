"use client";
import {
  BellDot,
  ChevronsRight,
  Cog,
  Globe,
  MessageSquareDot,
  Search,
} from "lucide-react";
import React, { useEffect, useState } from "react";
import { Button } from "../ui/button";
import { usePathname } from "next/navigation";
import Link from "next/link";
import Logout from "./logout";
import { useMsal } from "@azure/msal-react";

export default function Header({ title }) {
  const [email, setEmail] = useState("");
  const { accounts } = useMsal();

  useEffect(() => {
    if (accounts.length === 0) return;

    const user = accounts[0];

    const userEmail =
      user.username ||
      user.idTokenClaims?.preferred_username ||
      user.idTokenClaims?.email;

    console.log("Logged in User Email:", userEmail);

    setEmail(userEmail);
  }, [accounts]);


  const pathname = usePathname();
  return (
    <div className="bg-white w-full text-[#25556f] rounded-lg border border-border-muted p-1 px-2 flex items-center justify-between">
      <div className="flex items-center justify-center font-bold text-lg">
        {title}
      </div>

      <div className="flex items-center justify-center text-text-grey">
        {email && (
          <p className="text-sm text-gray-600 mt-1">
            {email}
          </p>
        )}
        <hr className="border w-6 -rotate-90 border-text-grey" />
        <span className="text-[11px] font-medium">
          Last Updated:{" "}
          {new Intl.DateTimeFormat("en-IN", {
            year: "numeric",
            month: "short",
            day: "2-digit",
            hour: "2-digit",
            minute: "2-digit",
            hour12: true,
            timeZone: "Asia/Kolkata",
          }).format(new Date())}
        </span>

        <hr className="border w-6 -rotate-90 border-text-grey" />

        <div className="flex items-center justify-between gap-2">

          {/* <Link
            href={!isCountry ? "/country-team" : "/reconciliation/3LP"}
            className="bg-[#da2b1f] text-white flex gap-1 p-1 px-2 text-[11px] rounded-lg items-center"
          >
            {isCountry ? (
              <>
                <Cog className="w-3 h-3 flex-shrink-0" />
                Operations Login
              </>
            ) : (
              <>
                <Globe className="w-3 h-3 flex-shrink-0" /> Country Login
              </>
            )}
          </Link> */}
        </div>
        {/* <Logout /> */}
      </div>
    </div>
  );
}
