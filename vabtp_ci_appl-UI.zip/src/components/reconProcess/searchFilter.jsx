"use client";

import { useState } from "react";
import Dropdown from "@/components/common/dropdown";
import { Button } from "@/components/ui/button";
import { FileText, ShieldCheck, AlertTriangle, ShieldX } from "lucide-react";
export const months = [
  { value: "", label: "Month" },
  { value: "01", label: "January" },
  { value: "02", label: "February" },
  { value: "03", label: "March" },
  { value: "04", label: "April" },
];

export const plants = [
  { value: "", label: "Plant : All" },
  { value: "plant1", label: "Plant 1" },
  { value: "plant2", label: "Plant 2" },
];

export const mots = [
  { value: "", label: "MOT : All" },
  { value: "mot1", label: "MOT 1" },
  { value: "mot2", label: "MOT 2" },
];

export const products = [
  { value: "", label: "Product : All" },
  { value: "product1", label: "Product 1" },
  { value: "product2", label: "Product 2" },
];
const stats = [
  {
    title: "Total",
    value: 187,
    icon: FileText,
    bg: "bg-blue-100",
    color: "text-blue-600",
  },
  {
    title: "Matched",
    value: 170,
    icon: ShieldCheck,
    bg: "bg-green-100",
    color: "text-green-600",
  },
  {
    title: "Corrections",
    value: 12,
    icon: AlertTriangle,
    bg: "bg-yellow-100",
    color: "text-yellow-600",
  },
  {
    title: "Unmatched",
    value: 5,
    icon: ShieldX,
    bg: "bg-red-100",
    color: "text-red-600",
  },
];
export default function SearchFilter({ onApply }) {
  const [month, setMonth] = useState(months[0]);
  const [plant, setPlant] = useState(plants[0]);
  const [mot, setMot] = useState(mots[0]);
  const [product, setProduct] = useState(products[0]);

  const handleApply = () => {
    onApply?.({
      month,
      plant,
      mot,
      product,
    });
  };

  return (
    <div>
      <div className="flex items-center gap-4">
        <Dropdown
          items={months}
          defaultValue={month}
          placeholder="Search months..."
          onChange={setMonth}
        />

        <Dropdown
          items={plants}
          defaultValue={plant}
          placeholder="Search plants..."
          onChange={setPlant}
        />

        <Dropdown
          items={mots}
          defaultValue={mot}
          placeholder="Search MOT..."
          onChange={setMot}
        />

        <Dropdown
          items={products}
          defaultValue={product}
          placeholder="Search products..."
          onChange={setProduct}
        />

        <Button className="bg-primary text-white px-6" onClick={handleApply}>
          APPLY
        </Button>
      </div>
      {/* <div className="bg-primary mt-4 p-3 rounded-xl flex gap-4">
        {stats.map((item, index) => {
          const Icon = item.icon;

          return (
            <div
              key={index}
              className="flex items-center justify-between bg-white rounded-xl px-5 py-3 w-full shadow-sm"
            >
              <div>
                <p className="text-sm text-gray-500">{item.title}</p>

                <h3 className="text-xl font-bold text-gray-900">
                  {item.value}
                </h3>
              </div>

              <div className={`p-2 rounded-full ${item.bg}`}>
                <Icon size={20} className={item.color} />
              </div>
            </div>
          );
        })}
      </div> */}
    </div>
  );
}
