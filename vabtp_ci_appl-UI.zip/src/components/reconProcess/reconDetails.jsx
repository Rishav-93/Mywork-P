import React from "react";
import SearchFilter from "./searchFilter";
import Report from "./report";

export default function ReconDetails() {
 

  return (
    <div>
      {/* <SearchFilter /> */}
      <Report />
    </div>
  );
}
