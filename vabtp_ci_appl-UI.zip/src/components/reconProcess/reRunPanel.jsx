"use client";
import React, { useEffect, useState } from "react";
import { Button } from "@/components/ui/button";
import { useApproveStore } from "@/store/approveStore";
import { useReconStore } from "@/store/reconStore";
import { useRerunStore } from "@/store/rerunStore";
import { ArrowLeft, Calendar } from "lucide-react";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { useMsal } from "@azure/msal-react";

import { Menu, MenuButton, MenuItem, MenuItems } from "@headlessui/react";
import { ChevronDownIcon, CheckIcon } from "@heroicons/react/20/solid";

export default function ReRunPanel({ onBack }) {
    const { accounts } = useMsal();
    const [email, setEmail] = useState("");

    const { selectedDate } = useReconStore();
    const failedPlantIds = useApproveStore((s) => s.failedPlantIds);
    const { triggerRerun, loading } = useRerunStore();

    const [rerunPlant, setRerunPlant] = useState("");

    useEffect(() => {
        if (failedPlantIds.length > 0) {
            setRerunPlant(failedPlantIds[0]);
        }
    }, [failedPlantIds]);

    const formatMonthYear = (date) => {
        if (!date) return null;

        const d = new Date(date);

        const month = String(d.getMonth() + 1).padStart(2, "0");

        // take only last 2 digits of year
        const year = String(d.getFullYear()).slice(-2);

        return `${month}${year}`;
    };

    /* -------------------- LOGIN EMAIL -------------------- */
    useEffect(() => {
        if (accounts.length === 0) return;

        const user = accounts[0];
        const userEmail =
            user.username ||
            user.idTokenClaims?.preferred_username ||
            user.idTokenClaims?.email;

        setEmail(userEmail);
    }, [accounts]);

    /* -------------------- RERUN HANDLER -------------------- */
    const handleReRun = async () => {
        if (!rerunPlant || !selectedDate) {
            alert("Select failed plant first");
            return;
        }

        const payload = {
            plant_id: rerunPlant,
            month_of_recon: formatMonthYear(selectedDate),
            requested_by: email,
            request_type: "rerun",
            recon_type: "rerun",
        };

        console.log("🚀 FINAL PAYLOAD:", payload);

        await triggerRerun(payload);
    };

    return (
        <div className="bg-[#EEF6F8] p-6 rounded-xl mb-6 mt-4">


            <Button variant="ghost" className="pl-0" onClick={onBack}>
                <ArrowLeft className="mr-1 w-4 h-4 l-0" />

            </Button>
            <div className="grid grid-cols-1 md:grid-cols-7 gap-4 mb-4">


                {/* Month */}
                <div>
                    <label className="text-sm mb-1 block">Month</label>
                    <div className="flex items-center gap-2 border rounded-md px-3 py-2 bg-white">
                        <Calendar size={16} />
                        <DatePicker
                            selected={selectedDate ? new Date(selectedDate) : null}
                            dateFormat="MM/yyyy"
                            showMonthYearPicker
                            className="outline-none text-sm"
                            disabled
                        />
                    </div>
                </div>

                {/* Failed Plant Dropdown */}
                <div>
                    <label className="text-sm mb-1 block">Failed Plant</label>

                    <Menu as="div" className="relative inline-block w-md">
                        <MenuButton className="inline-flex w-full items-center justify-between rounded-md px-3 py-2 text-sm border bg-white text-gray-700 border-gray-300">
                            {rerunPlant || "Select Failed Plant"}
                            <ChevronDownIcon className="ml-2 h-5 w-5 text-gray-400" />
                        </MenuButton>

                        <MenuItems className="absolute z-50 mt-1 w-full rounded-md bg-white shadow-lg border border-gray-200">
                            <div className="max-h-60 overflow-y-auto py-1">

                                {failedPlantIds.length === 0 && (
                                    <div className="px-4 py-2 text-sm text-gray-400">
                                        No Failed Plants
                                    </div>
                                )}

                                {failedPlantIds.map((id) => (
                                    <MenuItem key={id}>
                                        {({ focus }) => (
                                            <button
                                                onClick={() => setRerunPlant(id)}
                                                className={`flex items-center justify-between w-full px-4 py-2 text-sm ${focus ? "bg-red-50 text-red-600" : "text-gray-700"
                                                    }`}
                                            >
                                                {id}
                                                {rerunPlant === id && (
                                                    <CheckIcon className="h-4 w-4 text-red-600" />
                                                )}
                                            </button>
                                        )}
                                    </MenuItem>
                                ))}

                            </div>
                        </MenuItems>
                    </Menu>
                </div>

            </div>

            <Button
                className="bg-primary text-white px-6"
                onClick={handleReRun}
                disabled={!rerunPlant || failedPlantIds.length === 0 || loading}
            >
                {loading ? "Triggering..." : "Re-Run"}
            </Button>
        </div>
    );
}
