"use client";

import React, { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { useAuthStore } from "@/store/auth";
import { useApproveStore } from "@/store/approveStore";
import { useReconStore } from "@/store/reconStore";
import { Download } from "lucide-react";
import { useMsal } from "@azure/msal-react";
import { toast } from "sonner";
import { Popover } from "@headlessui/react";
import { ChevronDownIcon } from "@heroicons/react/20/solid";
import ReRunPanel from "./reRunPanel";
import { useManualStore } from "@/store/useManualStore";

export default function ReportTable() {
  const [email, setEmail] = useState("");
  const [showReRun, setShowReRun] = useState(false);
  const [lastActionPlants, setLastActionPlants] = useState([]);
  const [showApproveModal, setShowApproveModal] = useState(false);
  const [approveChecks, setApproveChecks] = useState([false, false, false, false]);

  const prevStatusRef = useRef(null);
  const loadingToastId = useRef(null);

  const role = useAuthStore((s) => s.role);

  const { accounts } = useMsal();

  /* STORES */
  const { selectedDate, response } = useReconStore();

  const approveRecon = useApproveStore((s) => s.approveRecon);
  const approveLoading = useApproveStore((s) => s.loading);
  const jobStatus = useApproveStore((s) => s.jobStatus);
  const result = useApproveStore((s) => s.result);

  const plantIds = useApproveStore((s) => s.plantIds);
  const selectedPlant = useApproveStore((s) => s.selectedPlant);
  const togglePlant = useApproveStore((s) => s.togglePlant);
  const processReconRecords = useApproveStore((s) => s.processReconRecords);

  const plantActionStatus = useApproveStore((s) => s.plantActionStatus);
  const setPlantActionStatus = useApproveStore((s) => s.setPlantActionStatus);

  const manualRecon = useManualStore((s) => s.manualRecon);
  const manualLoading = useManualStore((s) => s.loading);
  const manualStatus = useManualStore((s) => s.jobStatus);
  const manualResult = useManualStore((s) => s.result);

  /* ================= DOWNLOAD ================= */

  const downloadUrls = result?.url || [];
  const reconDetailIframeUrl = process.env.NEXT_PUBLIC_RECONDETAILS_IFRAME_URL;
  const handleDownload = () => {
    if (!downloadUrls.length) return;

    toast.success(`Downloading ${downloadUrls.length} file(s)`);

    downloadUrls.forEach((link) => {
      const a = document.createElement("a");
      a.href = link;
      a.target = "_blank";
      a.download = "";
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
    });
  };

  /* ================= DROPDOWN ================= */

  const PlantDropdown = () => (
    <Popover className="relative w-[260px]">
      <Popover.Button className="inline-flex w-full items-center justify-between rounded-md px-3 py-2 text-sm border bg-white">
        {selectedPlant.length === 0
          ? "Select Plants"
          : `${selectedPlant.length} Selected`}
        <ChevronDownIcon className="ml-2 h-5 w-5 text-gray-400" />
      </Popover.Button>

      <Popover.Panel className="absolute z-50 mt-1 w-full rounded-md bg-white shadow-lg border">
        <div className="max-h-60 overflow-y-auto py-2">

          {plantIds.length === 0 && (
            <div className="px-4 py-2 text-sm text-gray-400">
              No Plants Found
            </div>
          )}

          {plantIds.map((id) => {
            const checked = selectedPlant.includes(id);
            const status = plantActionStatus?.[id];
            const isDisabled = status !== undefined;

            return (
              <div
                key={id}
                className={`flex items-center justify-between px-4 py-2 
                ${isDisabled
                    ? "bg-gray-100 cursor-not-allowed"
                    : "hover:bg-blue-50 cursor-pointer"
                  }`}
                onClick={() => {
                  if (!isDisabled) togglePlant(id);
                }}
              >
                <div className="flex items-center gap-2">
                  <input
                    type="checkbox"
                    checked={checked}
                    readOnly
                    disabled={isDisabled}
                    className="accent-blue-600"
                  />
                  <span className="text-sm">{id}</span>
                </div>

                {status && (
                  <span
                    className={`text-xs px-2 py-1 rounded font-medium
                      ${status === "APPROVED"
                        ? "bg-green-100 text-green-700"
                        : ""}
                      ${status === "MANUAL"
                        ? "bg-blue-100 text-blue-700"
                        : ""}
                    `}
                  >
                    {status === "APPROVED" ? "Approved" : "Manual"}
                  </span>
                )}
              </div>
            );
          })}
        </div>
      </Popover.Panel>
    </Popover>
  );

  /* ================= APPROVE STATUS ================= */

  useEffect(() => {
    if (!jobStatus) return;
    if (prevStatusRef.current === jobStatus) return;

    prevStatusRef.current = jobStatus;

    if (jobStatus === "PENDING") {
      toast.info("Approve is in Queue");
      return;
    }

    if (jobStatus === "RUNNING") {
      loadingToastId.current = toast.loading("Approving...");
      return;
    }

    if (jobStatus === "TERMINATED") {
      if (loadingToastId.current) {
        toast.dismiss(loadingToastId.current);
        loadingToastId.current = null;
      }

      const isSuccess = result?.status?.toLowerCase() === "success";

      if (isSuccess) {
        toast.success("Approve Completed Successfully");

        setPlantActionStatus(lastActionPlants, "APPROVED");
      } else {
        toast.error(result?.error_message || "Approve Failed");
      }
    }
  }, [jobStatus, result]);

  /* ================= MANUAL STATUS ================= */

  useEffect(() => {
    if (!manualStatus) return;

    if (manualStatus === "PENDING") {
      toast.info("Manual is in Queue");
    }

    if (manualStatus === "RUNNING") {
      toast.loading("Manual Running...");
    }

    if (manualStatus === "TERMINATED") {
      const isSuccess = manualResult?.status?.toLowerCase() === "success";

      if (isSuccess) {
        toast.success("Manual Completed Successfully");

        setPlantActionStatus(lastActionPlants, "MANUAL");
      } else {
        toast.error(manualResult?.error_message || "Manual Failed");
      }
    }
  }, [manualStatus]);

  /* ================= USER ================= */

  useEffect(() => {
    if (accounts.length === 0) return;

    const user = accounts[0];

    const userEmail =
      user.username ||
      user.idTokenClaims?.preferred_username ||
      user.idTokenClaims?.email;

    setEmail(userEmail);
  }, [accounts]);

  /* ================= DATA ================= */
  useEffect(() => {
    if (!response || !response.records) return;

    console.log("🌱 Processing plants:", response.records);

    processReconRecords(response.records);

  }, [response, processReconRecords]);

  /* ================= HELPERS ================= */

  const generateTriggerId = () =>
    Math.floor(100000 + Math.random() * 900000);

  const formatMonthYear = (date) => {
    if (!date) return null;

    const d = new Date(date);
    const month = String(d.getMonth() + 1).padStart(2, "0");
    const year = String(d.getFullYear()).slice(-2);

    return `${month}${year}`;
  };

  /* ================= ACTIONS ================= */

  // Approve handler, only called after acknowledge
  const handleApprove = async () => {
    if (!selectedPlant.length) return;
    setLastActionPlants(selectedPlant);
    const payload = {
      plant_id: JSON.stringify(selectedPlant),
      month_of_recon: formatMonthYear(selectedDate),
      requested_by: email,
      trigger_id: generateTriggerId(),
      status: "Approved",
      request_type: "approval",
      approver: email
    };
    await approveRecon(payload);
    setShowApproveModal(false);
    setApproveChecks([false, false, false, false]);
  };

  const handleManual = async () => {
    if (!selectedPlant.length) return;

    setLastActionPlants(selectedPlant);

    const payload = {
      plant_id: JSON.stringify(selectedPlant),
      month_of_recon: formatMonthYear(selectedDate),
      requested_by: email,
      trigger_id: generateTriggerId(),
      status: "Approved",
      request_type: "approval",
    };

    await manualRecon(payload);
  };

  /* ================= UI ================= */

  return (
    <div>
      {showReRun && (
        <ReRunPanel onBack={() => setShowReRun(false)} />
      )}

      {!showReRun && (
        <div className="mt-6 bg-white rounded-xl border">

          <div className="flex items-center justify-between p-4 border-b">

            <h2 className="text-lg font-semibold text-red-500">
              Recon Approval
            </h2>

            <div className="flex gap-3">

              {["P66_VABTP_CG_PROCESSOR", "P66_VABTP_CG_LEAD", "P66_VABTP_P66_APPROVER"].includes(role) && (
                <>
                  <PlantDropdown />

                  <Button
                    className="bg-green-600 text-white hover:bg-green-700"
                    onClick={() => setShowApproveModal(true)}
                    disabled={
                      approveLoading ||
                      !selectedDate ||
                      plantIds.length === 0 ||
                      selectedPlant.length === 0
                    }
                  >
                    {approveLoading ? "Approving..." : "Approve"}
                  </Button>
                  {/* Approve Modal - Tailwind version */}
                  {showApproveModal && (
                    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-40">
                      <div className="bg-white rounded-lg shadow-lg w-full max-w-md p-6 border">
                        <h3 className="text-lg font-semibold mb-4">Acknowledge Before Approving</h3>
                        <div className="flex flex-col gap-3 mb-4 text-xs">
                          <label className="flex items-start gap-2 cursor-pointer">
                            <span>
                              <span className="block">I certify that
                                As the approver, my sign-off indicates that the following have been completed:</span>
                            </span>
                          </label>
                          <label className="flex items-start gap-2 cursor-pointer">
                            <input type="checkbox" className="accent-blue-600 mt-1" checked={approveChecks[0]} onChange={e => setApproveChecks(c => [e.target.checked, c[1], c[2], c[3]])} />

                            <span>I have reviewed the line items and Volume of Input data matched with that of Output data for both TOR and ERP or as the case may be.</span>
                          </label>
                          <label className="flex items-start gap-2 cursor-pointer">
                            <input type="checkbox" className="accent-blue-600 mt-1" checked={approveChecks[1]} onChange={e => setApproveChecks(c => [c[0], e.target.checked, c[2], c[3]])} />

                            <span>I have reviewed in Matched cases there is no variance over and above the approved threshold limit (rounding off issue)</span>
                          </label>
                          <label className="flex items-start gap-2 cursor-pointer">
                            <input type="checkbox" className="accent-blue-600 mt-1" checked={approveChecks[2]} onChange={e => setApproveChecks(c => [c[0], c[1], e.target.checked, c[3]])} />

                            <span>I have reviewed in Unmatched and Correction cases there and there are none of items which are reporting incorrectly to the best of my knowledge. </span>
                          </label>
                          <label className="flex items-start gap-2 cursor-pointer">

                            <input type="checkbox" className="accent-blue-600 mt-1" checked={approveChecks[3]} onChange={e => setApproveChecks(c => [c[0], c[1], c[2], e.target.checked])} />
                            <span>This report will be used for further analysis of Open Item and 4W's.</span>
                          </label>
                        </div>
                        <div className="flex justify-end gap-2">
                          <Button variant="outline" onClick={() => { setShowApproveModal(false); setApproveChecks([false, false, false, false]); }}>Close</Button>
                          <Button
                            className="bg-green-600 text-white hover:bg-green-700"
                            disabled={!approveChecks.every(Boolean)}
                            onClick={handleApprove}
                          >
                            Acknowledge
                          </Button>
                        </div>
                      </div>
                    </div>
                  )}
                </>
              )}

              {["P66_VABTP_CG_LEAD"].includes(role) && (
                <Button
                  className="bg-blue-600 text-white"
                  onClick={() => setShowReRun(true)}
                >
                  Re-Run
                </Button>
              )}

              {["P66_VABTP_CG_PROCESSOR", "P66_VABTP_CG_LEAD"].includes(role) && (
                <Button
                  variant="outline"
                  onClick={handleManual}
                  disabled={
                    manualLoading ||
                    !selectedDate ||
                    selectedPlant.length === 0
                  }
                >
                  {manualLoading ? "Running..." : "Manual"}
                </Button>
              )}

              <Button
                variant="outline"
                size="icon"
                disabled={!downloadUrls.length}
                onClick={handleDownload}
              >
                <Download className="w-4 h-4" />
              </Button>

            </div>
          </div>

          <div style={{ height: "calc(100vh - 90px)" }}>
            <iframe
              src={process.env.NEXT_PUBLIC_RECONDETAILS_IFRAME_URL}
              width="100%"
              height="100%"
              frameBorder="0"
              style={{ border: "none" }}
              title="Databricks Dashboard"
            />
          </div>

        </div>
      )}
    </div>
  );
}
