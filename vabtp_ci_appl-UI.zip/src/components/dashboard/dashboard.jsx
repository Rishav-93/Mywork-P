import React from "react";
import Header from "../common/header";

export default function Dashboard() {
  const dashboardUrl = process.env.NEXT_PUBLIC_DASHBOARD_IFRAME_URL;
  return (
    <div style={{ height: 'calc(100vh - 80px)', overflow: 'hidden' }}>
      <iframe
        src={dashboardUrl}
        width="100%"
        height="100%"
        frameBorder="0"
        style={{ border: 'none' }}
        title="Databricks Dashboard"
      />
    </div>
  );
}
