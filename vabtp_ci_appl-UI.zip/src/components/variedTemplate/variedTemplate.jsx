"use client";
import React, { useState, useRef, useEffect } from "react";
import { Popover } from "@headlessui/react";
import { ChevronDownIcon } from "@heroicons/react/20/solid";
import { Calendar } from "lucide-react";
import DatePicker from "react-datepicker";
import "react-datepicker/dist/react-datepicker.css";
import { useMsal } from "@azure/msal-react";
import { toast } from "sonner";
import axios from "axios";

/* ================= CUSTOM DROPDOWN ================= */
const CustomDropdown = ({ label, options, selected, onChange }) => {
    return (
        <Popover className="relative w-[200px]">
            {({ close }) => (
                <>
                    <Popover.Button className="flex items-center justify-between w-full rounded-md px-3 py-2 text-sm border bg-white">
                        {selected || label}
                        <ChevronDownIcon className="h-5 w-5 text-gray-400" />
                    </Popover.Button>

                    <Popover.Panel className="absolute z-50 mt-1 w-full rounded-md bg-white shadow border">
                        {options.map((opt) => (
                            <div
                                key={opt}
                                className="px-3 py-2 text-sm hover:bg-blue-50 cursor-pointer"
                                onClick={() => {
                                    onChange(opt);
                                    close();
                                }}
                            >
                                {opt}
                            </div>
                        ))}
                    </Popover.Panel>
                </>
            )}
        </Popover>
    );
};

export default function VariedTemplate() {
    const [selectedPlant, setSelectedPlant] = useState("");
    const [selectedMonthYear, setSelectedMonthYear] = useState(null);

    const [loadingResult, setLoadingResult] = useState(false);
    const [resultData, setResultData] = useState(null);
    const [triggerId, setTriggerId] = useState(null);
    const [actionLoading, setActionLoading] = useState(false);

    const [torPath, setTorPath] = useState("");
    const [plantOptions, setPlantOptions] = useState([]);
    const [outputPath, setOutputPath] = useState("");

    const pollingRef = useRef(null);

    const { accounts } = useMsal();
    const userEmail =
        accounts?.[0]?.username ||
        accounts?.[0]?.idTokenClaims?.email ||
        "unknown@example.com";
    const fetchPlantList = async () => {
        const ruleUpdatePlantList = process.env.NEXT_PUBLIC_RULE_PROMPT_PLANT_LIST;

        try {

            const res = await axios.get(
                `${process.env.NEXT_PUBLIC_RECON_API_URL}/recon/rules/listofplants/blackline?source_schema_path=${ruleUpdatePlantList}`
            );

            console.log(
                "PLANT LIST RESPONSE 👉",
                res?.data
            );

            setPlantOptions(
                Array.isArray(res?.data)
                    ? res.data
                    : []
            );

        } catch (err) {

            console.error(
                "PLANT API ERROR 👉",
                err?.response?.data ||
                err.message
            );

            toast.error(
                "Failed to load plants ❌"
            );
        }
    };

    useEffect(() => {

        fetchPlantList();

    }, []);

    /* ================= POLLING ================= */
    const pollResult = (taskRunId) => {
        if (!taskRunId) return;

        if (pollingRef.current) clearInterval(pollingRef.current);

        setLoadingResult(true);

        const fetchResult = async () => {
            try {
                const res = await axios.get(
                    `${process.env.NEXT_PUBLIC_RECON_API_URL}/recon/simplified-template/result?task_run_id=${taskRunId}`
                );

                const formula = res.data?.formula;

                // ✅ CASE 1: null / undefined
                if (!formula) {
                    console.log("⏳ Formula not ready");
                    return;
                }

                let parsed;

                try {
                    parsed = JSON.parse(formula);
                } catch (e) {
                    console.log("⏳ Waiting valid JSON...");
                    return;
                }

                // ✅ CASE 2: "null" → parsed = null
                if (!parsed || typeof parsed !== "object") {
                    console.log("⏳ Parsed is null, waiting...");
                    return;
                }

                console.log("✅ Parsed:", parsed);

                // ✅ SAFE ACCESS (NO CRASH NOW)
                if (parsed.tor_raw_file_path) {
                    setTorPath(parsed.tor_raw_file_path);
                }

                if (parsed.output_path) {
                    setOutputPath(parsed.output_path);
                }

                // ✅ STOP CONDITION
                if (parsed.status === "success" || parsed.status === "failed") {
                    setResultData(parsed);
                    setLoadingResult(false);

                    clearInterval(pollingRef.current);
                    pollingRef.current = null;

                    toast.success(`✅ ${parsed.status}`);
                }

            } catch (err) {
                console.error("Polling error:", err);
            }
        };
        fetchResult();
        pollingRef.current = setInterval(fetchResult, 60000);
    };

    /* ================= SUBMIT ================= */
    const handleSubmit = async () => {
        try {
            const d = new Date(selectedMonthYear);
            const month = d.toLocaleString("default", { month: "short" }).toUpperCase();
            const year = d.getFullYear();
            const mmyy = `${month}${year.toString().slice(-2)}`;

            const res = await axios.post(
                `${process.env.NEXT_PUBLIC_RECON_API_URL}/recon/simplified-template/run`,
                {
                    plant: selectedPlant,
                    "Month Of Reconcilation in MMMYY format": mmyy,
                    "Year Of Reconcilation": year,
                    // requested_by: userEmail,
                    "status": "null",
                }
            );

            setTriggerId(res.data.run_id);

            pollResult(res.data.task_run_id);

            toast.success("Submitted 🚀");
        } catch {
            toast.error("Submit failed");
        }
    };

    /* ================= APPROVAL ================= */
    const handleApproval = async (status) => {
        try {
            setActionLoading(true);

            const d = new Date(selectedMonthYear);
            const month = d.toLocaleString("default", { month: "short" }).toUpperCase();
            const year = d.getFullYear();
            const mmyy = `${month}${year.toString().slice(-2)}`;

            await axios.post(
                `${process.env.NEXT_PUBLIC_RECON_API_URL}/recon/upload/approve`,
                {
                    Plant_ID: selectedPlant,
                    month_date: mmyy,
                    requested_by: userEmail,
                    trigger_id: triggerId,
                    status: status.toLowerCase(),
                    year: year,
                    TOR_file_path: torPath,
                    output_path: outputPath,
                }
            );

            toast.success(`✅ ${status}`);
        } catch {
            toast.error("Failed");
        } finally {
            setActionLoading(false);
        }
    };

    useEffect(() => {
        return () => {
            if (pollingRef.current) clearInterval(pollingRef.current);
        };
    }, []);

    return (
        <div className="p-6">
            <h2 className="text-red-500 font-semibold mb-2">
                PLANT & MONTH SELECTION
            </h2>

            {/* INPUT SECTION */}
            <div className="bg-[#e6f2f5] p-4 rounded-lg flex gap-4 items-center flex-wrap">
                <CustomDropdown
                    label="Plant"
                    options={plantOptions}
                    selected={selectedPlant}
                    onChange={setSelectedPlant}
                />

                <div className="flex items-center gap-2 rounded-md border bg-white px-3 py-2">
                    <Calendar className="h-4 w-4 text-red-500" />
                    <DatePicker
                        selected={selectedMonthYear}
                        onChange={(d) => setSelectedMonthYear(d)}
                        placeholderText="Select month"
                        dateFormat="MM/yyyy"
                        showMonthYearPicker
                        className="text-sm outline-none"
                    />
                </div>

                <button
                    onClick={handleSubmit}
                    className="px-4 py-2 bg-blue-600 text-white rounded text-sm"
                >
                    Submit
                </button>
            </div>

            {/* LOADING */}
            {loadingResult && (
                <p className="mt-3 text-blue-600 font-medium">
                    ⏳ Processing...
                </p>
            )}

            {/* RESULT */}
            <div className="mt-4 bg-gray-100 p-4 rounded text-sm">
                <p className="font-semibold mb-2">
                    Calculation Logic:
                </p>

                <p className="bg-white p-2 rounded border">
                    {resultData ? resultData.IT_OT_calculation : ""}
                </p>

                {/* 🔥 OUTPUT PATH BELOW */}
                {outputPath && (
                    <div className="mt-3">
                        <p className="font-semibold text-gray-700">
                            Output files:
                        </p>
                        <p className="bg-white underline rounded border text-sm text-blue break-all">
                            {
                                outputPath
                            }
                        </p>
                    </div>
                )}
            </div>
            {/* ACTION */}
            {resultData && (
                <div className="mt-3">
                    <button
                        disabled={actionLoading}
                        onClick={() => handleApproval("approved")}
                        className="px-4 py-2 bg-green-600 text-white rounded text-sm"
                    >
                        {actionLoading ? "Processing..." : "Approve"}
                    </button>

                    <button
                        disabled={actionLoading}
                        onClick={() => handleApproval("rejected")}
                        className="px-4 py-2 bg-red-600 text-white rounded text-sm ml-2"
                    >
                        Reject
                    </button>
                </div>
            )}
        </div>
    );
}
