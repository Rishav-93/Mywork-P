import { create } from "zustand";

export const useConvertToNlpStore = create((set) => ({
  formData: {
    request_type: "",
    portal: "",
    rule_level: "",
    data_source: "",
    rule_id: null,
    rules_priority: null,
    rules_severity: "",
    rules_order: null,
    classify: "",
    fields: {},
  },

  setFormData: (updater) =>
    set((state) => ({
      formData:
        typeof updater === "function"
          ? updater(state.formData)
          : updater,
    })),

  resetForm: () =>
    set({
      formData: {
        request_type: "Rules Update",
        fields: {},
      },
    }),
}));