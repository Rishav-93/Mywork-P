import { create } from "zustand";
import axios from "axios";

const BASE_URL = `${process.env.NEXT_PUBLIC_RECON_API_URL}/recon/manual`;

export const useManualStore = create((set, get) => ({

    loading: false,
    response: null,
    result: null,
    error: null,

    isPolling: false,
    pollIntervalId: null,
    jobStatus: null,
    jobFinished: false,

    /* ================= STOP POLLING ================= */

    stopPolling: () => {
        const id = get().pollIntervalId;
        if (id) clearInterval(id);

        set({
            isPolling: false,
            pollIntervalId: null,
            jobFinished: true,
        });
    },

    /* ================= NORMALIZE ================= */

    normalizeState: (state) => {
        if (!state) return "PENDING";

        const s = state.toUpperCase();

        if (s === "PENDING" || s === "BLOCKED") return "PENDING";
        if (s === "RUNNING" || s === "TERMINATING") return "RUNNING";
        if (s === "TERMINATED") return "TERMINATED";

        return "PENDING";
    },

    /* ================= POLLING ================= */

    startResultPolling: (runId) => {
        if (!runId) return;

        const poll = async () => {
            try {
                const res = await axios.get(`${BASE_URL}/result`, {
                    params: { run_id: runId },
                });

                const data = res.data;

                const normalized = get().normalizeState(
                    data?.job_state?.life_cycle_state
                );

                if (get().jobFinished) return;

                set({
                    result: data,
                    jobStatus: normalized,
                });

                if (normalized === "TERMINATED") {
                    get().stopPolling();

                    set({
                        loading: false,
                        jobStatus: "TERMINATED",
                        result: data,
                    });
                }
            } catch (err) {
                console.error("Polling failed:", err);
                get().stopPolling();
                set({ loading: false });
            }
        };

        poll();
        const interval = setInterval(poll, 5000);

        set({
            isPolling: true,
            pollIntervalId: interval,
            jobStatus: "PENDING",
        });
    },

    /* ================= MANUAL API ================= */

    manualRecon: async (payload) => {
        try {
            console.log("🚀 MANUAL PAYLOAD:", payload);

            get().stopPolling();

            set({
                jobFinished: false,
                loading: true,
                error: null,
                response: null,
                result: null,
            });

            const res = await axios.post(BASE_URL, payload, {
                headers: {
                    "Content-Type": "application/json",
                    Accept: "application/json",
                },
            });

            const data = res.data;

            set({ response: data });

            const runId = data?.run_id;

            if (runId) {
                get().startResultPolling(runId);
            } else {
                set({ loading: false });
            }

            return data;
        } catch (err) {
            set({
                error: err.response?.data || err.message,
                loading: false,
            });

            throw err;
        }
    },
}));