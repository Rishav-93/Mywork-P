import { create } from "zustand";
import axios from "axios";

const BASE_URL = `${process.env.NEXT_PUBLIC_RECON_API_URL}/recon/approve`;

export const useApproveStore = create((set, get) => ({

  /* ============================
     STATE
  ============================ */

  loading: false,
  response: null,
  result: null,
  error: null,

  /* JOB TRACKING */
  isPolling: false,
  pollIntervalId: null,
  jobStatus: null,
  jobFinished: false,

  /* PLANTS */
  plantIds: [],
  failedPlantIds: [],
  selectedPlant: [],

  /* ✅ NEW: PLANT STATUS */
  plantActionStatus: {},

  /* ============================
     PLANT SELECTION
  ============================ */

  setSelectedPlant: (plants) => set({ selectedPlant: plants }),

  togglePlant: (plantId) =>
    set((state) => {
      const exists = state.selectedPlant.includes(plantId);

      return {
        selectedPlant: exists
          ? state.selectedPlant.filter((p) => p !== plantId)
          : [...state.selectedPlant, plantId],
      };
    }),

  clearPlants: () =>
    set({
      plantIds: [],
      failedPlantIds: [],
      selectedPlant: [],
    }),

  /* ============================
     ✅ NEW: SET PLANT STATUS
  ============================ */

  setPlantActionStatus: (plants, type) =>
    set((state) => {
      const updated = { ...state.plantActionStatus };

      plants.forEach((plantId) => {
        updated[plantId] = type; // "APPROVED" or "MANUAL"
      });

      return { plantActionStatus: updated };
    }),

  /* ============================
     NORMALIZE JOB STATE
  ============================ */

  normalizeState: (state) => {
    if (!state) return "PENDING";

    const s = state.toUpperCase();

    if (s === "PENDING" || s === "BLOCKED") return "PENDING";
    if (s === "RUNNING" || s === "TERMINATING") return "RUNNING";
    if (s === "TERMINATED") return "TERMINATED";

    return "PENDING";
  },

  /* ============================
     PROCESS RECON RECORDS
  ============================ */
  processReconRecords: (records) => {
    if (!records || !Array.isArray(records)) return;

    // ✅ SHOW ALL PLANTS (NOT FILTERED)
    const allPlantIds = [
      ...new Set(
        records
          .filter((r) => r.plant_id && r.plant_id !== "All Plants")
          .map((r) => r.plant_id)
      ),
    ];

    // ✅ FAILED PLANTS (keep this logic)
    const failedIds = [
      ...new Set(
        records
          .filter((r) => {
            const fields = [
              "precheck_status",
              "ingest_status",
              "prep_status",
              "recon_status",
              "export_status",
              "review_status",
            ];

            return fields.some((field) =>
              r[field]?.toLowerCase().includes("fail")
            );
          })
          .map((r) => r.plant_id)
          .filter((id) => id && id !== "All Plants")
      ),
    ];

    console.log("🌱 ALL PLANTS:", allPlantIds);

    set({
      plantIds: allPlantIds,     // ✅ FIXED
      failedPlantIds: failedIds,
    });
  },
  // processReconRecords: (records) => {
  //   if (!records || !Array.isArray(records)) return;

  //   const approveIds = [
  //     ...new Set(
  //       records
  //         .filter(
  //           (r) =>
  //             r.plant_id !== "All Plants" &&
  //             r.export_status === "Success" &&
  //             r.review_status === "NOT_STARTED"
  //         )
  //         .map((r) => r.plant_id)
  //         .filter(Boolean)
  //     ),
  //   ];

  //   const statusFields = [
  //     "precheck_status",
  //     "ingest_status",
  //     "prep_status",
  //     "recon_status",
  //     "export_status",
  //     "review_status",
  //   ];

  //   const failedIds = [
  //     ...new Set(
  //       records
  //         .filter((r) => {
  //           const statusFields = [
  //             "precheck_status",
  //             "ingest_status",
  //             "prep_status",
  //             "recon_status",
  //             "export_status",
  //             "review_status",
  //           ];

  //           return statusFields.some((field) => {
  //             const value = r[field];

  //             if (!value) return false;

  //             return value.toLowerCase().includes("fail");
  //           });
  //         })
  //         .map((r) => r.plant_id)
  //         .filter((id) => id && id !== "All Plants")
  //     ),
  //   ];

  //   set({
  //     plantIds: approveIds,
  //     failedPlantIds: failedIds,
  //   });
  // },

  /* ============================
     STOP POLLING
  ============================ */

  stopPolling: () => {
    const id = get().pollIntervalId;
    if (id) clearInterval(id);

    set({
      isPolling: false,
      pollIntervalId: null,
      jobFinished: true,
    });
  },

  /* ============================
     START POLLING
  ============================ */

  startResultPolling: (runId) => {
    if (!runId) return;

    const poll = async () => {
      try {
        const res = await axios.get(`${BASE_URL}/result`, {
          params: { run_id: runId },
        });

        const data = res.data;

        const normalized = get().normalizeState(
          data?.job_state?.life_cycle_state
        );

        if (get().jobFinished) return;

        set({
          result: data,
          jobStatus: normalized,
        });

        if (normalized === "TERMINATED") {
          get().stopPolling();

          set({
            loading: false,
            jobStatus: "TERMINATED",
            result: data,
          });
        }
      } catch (err) {
        console.error("Polling failed:", err);
        get().stopPolling();
        set({ loading: false });
      }
    };

    poll();
    const interval = setInterval(poll, 5000);

    set({
      isPolling: true,
      pollIntervalId: interval,
      jobStatus: "PENDING",
    });
  },

  /* ============================
     APPROVE API
  ============================ */

  approveRecon: async (payload) => {
    try {
      console.log("🚀 FINAL API PAYLOAD:", payload);

      get().stopPolling();

      set({
        jobFinished: false,
        loading: true,
        error: null,
        response: null,
        result: null,
      });

      const postRes = await axios.post(BASE_URL, payload, {
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
      });

      const approveData = postRes.data;
      set({ response: approveData });

      const runId = approveData?.run_id;

      if (runId) {
        get().startResultPolling(runId);
      } else {
        set({ loading: false });
      }

      return approveData;
    } catch (err) {
      set({
        error: err.response?.data || err.message,
        loading: false,
      });

      throw err;
    }
  },
}));