import { create } from "zustand";
import axios from "axios";

const API_URL = process.env.NEXT_PUBLIC_RECON_API_URL;

const TABLE_PATH = process.env.NEXT_PUBLIC_RULE_UPDATE_TABLEPATH;

export const useRuleStore = create((set) => ({
    rules: [],
    loading: false,
    error: null,

    fetchRules: async () => {
        try {
            set({ loading: true });

            const res = await axios.get(
                `${API_URL}/recon/rules?table_path=${TABLE_PATH}`
            );

            // Extract only required fields
            const formatted = res.data.records.map((item) => ({
                rule_id: item.rule_id,
                nlp_description: item.nlp_decription,
                rule_name: item.rule_name,
                rule_version: item.rule_version,
                created_by: "System", // fallback (API not giving)
                date: new Date().toLocaleString(),
                fullData: item, // store full record for view click
            }));

            set({ rules: formatted, loading: false });
        } catch (err) {
            console.error("Error fetching rules:", err);
            set({ error: err.message, loading: false });
        }
    },
}));