import { create } from "zustand";
import { persist } from "zustand/middleware";
import axios from "axios";
import { toast } from "sonner";

const API_URL = process.env.NEXT_PUBLIC_RECON_API_URL;

const STATIC_TABLE_PATH =
  process.env.NEXT_PUBLIC_STATIC_TABLE_PATH;
let pollingTimer = null;
let delayTimer = null;

const normalize = (value) =>
  value ? String(value).trim().toLowerCase() : "";

/* ================= STATUS → PROGRESS ================= */

const getProgressFromStatus = (status) => {
  switch (status) {
    case "queued":
      return 20;

    case "running":
      return 50;

    case "processing":
      return 75;

    case "success":
      return 100;

    case "failed":
      return 100;

    default:
      return 30;
  }
};

export const useReconStore = create(
  persist(
    (set, get) => ({
      loading: false,
      response: null,
      error: null,
      hasFetched: false,
      currentTriggerId: null,
      isPolling: false,
      progress: 0,
      selectedDate: null,
      hasHydrated: false, hasRunTriggered: false,

      setSelectedDate: (date) => set({ selectedDate: date }),
      setHasHydrated: (v) => set({ hasHydrated: v }),

      /* ================= RUN ================= */

      runRecon: async (payload) => {
        set({
          loading: true,
          isPolling: true,
          progress: 15,
          response: null,
          currentTriggerId: payload.trigger_id,

          // 🔥 ADD THIS
          hasRunTriggered: true,
        });

        try {
          const res = await axios.post(`${API_URL}/recon/runs`, payload);

          toast.success("Reconciliation Pipeline Triggered");

          get().startPolling();

          return res.data;
        } catch (err) {
          toast.error("Failed to trigger reconciliation");

          set({
            loading: false,
            isPolling: false,
            hasRunTriggered: false, // reset on failure
          });

          throw err;
        }
      },

      // 🔥 ADD THIS FUNCTION inside your store (anywhere inside create)

      fetchCurrentStatus: async () => {
        const { hasRunTriggered, isPolling } = get();

        if (hasRunTriggered || isPolling) {
          console.log("⛔ Skipping current status (batch running)");
          return;
        }

        try {
          console.log("📡 Calling current status API...");

          const res = await axios.get(`${API_URL}/recon/currentstatus`, {
            params: { _ts: Date.now() },
          });

          const data = res.data;
          const records = data?.records || [];

          if (!records.length) return;

          const allPlantRow = records.find(
            (r) => r.plant_id === "All Plants"
          );

          const triggerId =
            allPlantRow?.trigger_id || records[0]?.trigger_id;

          // ✅ SET INITIAL STATE
          set({
            response: data,
            hasFetched: true,
            currentTriggerId: triggerId,
          });

          if (!allPlantRow) return;

          const status = normalize(
            allPlantRow.All_plant_completion_status
          );

          const progress = getProgressFromStatus(status);

          set({ progress });

          /* ================= HANDLE STATUS ================= */

          if (status === "success" || status === "failed") {
            console.log("✅ Already completed");

            set({
              progress: 100,
              loading: false,
              isPolling: false,
              hasRunTriggered: false,
            });

            get().stopPolling();
          } else {
            console.log("🔁 Not completed → starting polling");

            // 🔥 IMPORTANT: mark as running
            set({
              hasRunTriggered: true,
              isPolling: true,
            });

            // 🔥 START POLLING SAME AS RUN
            get().startPolling();
          }

          return data;
        } catch (err) {
          console.error("❌ Current status API failed:", err);
        }
      },
      /* ================= RESTORE ================= */

      restoreSession: async () => {
        const triggerId = get().currentTriggerId;

        if (!triggerId) return;

        try {
          const res = await axios.get(`${API_URL}/recon/status`, {
            params: {
              table_path: STATIC_TABLE_PATH,
              trigger_id: triggerId,
              _ts: Date.now(),
            },
          });

          const records = res.data?.records || [];

          set({
            response: res.data,
            hasFetched: true,
          });

          if (!records.length) {
            if (!pollingTimer && !delayTimer) get().startPolling();
            return;
          }

          const allPlantRow = records.find(
            (r) => r.plant_id === "All Plants"
          );

          if (!allPlantRow) return;

          const status = normalize(
            allPlantRow.All_plant_completion_status
          );

          const progress = getProgressFromStatus(status);

          set({ progress });

          if (status === "success" || status === "failed") {
            get().stopPolling();

            set({
              progress: 100,
              loading: false,
              isPolling: false,
              hasRunTriggered: false, // ✅ FIX
            });
          } else {
            set({ hasRunTriggered: true }); // ✅ IMPORTANT

            if (!pollingTimer && !delayTimer) {
              get().startPolling();
            }
          }
        } catch (err) {
          console.error("Restore error:", err);
        }
      },

      /* ================= POLL STATUS ================= */

      pollReconStatus: async () => {
        const triggerId = get().currentTriggerId;

        if (!triggerId) return;

        try {
          const res = await axios.get(`${API_URL}/recon/status`, {
            params: {
              table_path: STATIC_TABLE_PATH,
              trigger_id: triggerId,
              _ts: Date.now(),
            },
          });

          const records = res.data?.records || [];

          if (!records.length) return;

          const allPlantRow = records.find(
            (r) => r.plant_id === "All Plants"
          );

          if (!allPlantRow) return;

          const status = normalize(
            allPlantRow.All_plant_completion_status
          );

          const progress = getProgressFromStatus(status);

          set({
            response: res.data,
            hasFetched: true,
            progress,
          });

          if (status === "success" || status === "failed") {
            get().stopPolling();

            toast.success(
              status === "success"
                ? "Reconciliation Completed 🎯"
                : "Reconciliation Failed ❌"
            );

            set({
              progress: 100,
              loading: false,
              isPolling: false,
              hasRunTriggered: false, // ✅ FIX
            });
          }
        } catch (err) {
          console.error("Polling error:", err);
        }
      },

      /* ================= START POLLING ================= */

      startPolling: () => {

        // clear previous timers
        if (pollingTimer) {
          clearInterval(pollingTimer);
          pollingTimer = null;
        }

        if (delayTimer) {
          clearTimeout(delayTimer);
          delayTimer = null;
        }

        console.log("🚀 First polling immediately");

        // FIRST POLL
        get().pollReconStatus();

        console.log("⏳ Waiting 1 minute for second polling...");

        delayTimer = setTimeout(() => {

          console.log("🟢 Second polling started");

          get().pollReconStatus();

          console.log("🔁 Polling every 1 minute started");

          pollingTimer = setInterval(() => {

            console.log("📡 Polling API:", new Date());

            get().pollReconStatus();

          }, 1 * 60 * 1000); // ✅ 1 minute

          set({ isPolling: true });

        }, 1 * 60 * 1000); // ✅ wait 1 minute
      },
      /* ================= STOP POLLING ================= */

      stopPolling: () => {
        if (pollingTimer) {
          clearInterval(pollingTimer);
          pollingTimer = null;
        }

        if (delayTimer) {
          clearTimeout(delayTimer);
          delayTimer = null;
        }

        set({ isPolling: false });
      },

      /* ================= RESET ================= */

      resetRecon: () => {
        get().stopPolling();

        set({
          loading: false,
          response: null,
          currentTriggerId: null,
          progress: 0,
          isPolling: false,
        });
      },
    }),
    {
      name: "recon-store",

      // 🔥 ADD THIS IN PARTIALIZE (IMPORTANT)
      partialize: (state) => ({
        currentTriggerId: state.currentTriggerId,
        progress: state.progress,
        selectedDate: state.selectedDate,
        response: state.response,
        isPolling: state.isPolling,
        loading: state.loading,
        hasRunTriggered: state.hasRunTriggered, // ✅ NEW
      }),

      onRehydrateStorage: () => (state) => {
        if (!state) return;

        state.setHasHydrated(true);

        if (state.currentTriggerId) {
          setTimeout(() => {
            state.restoreSession();
          }, 500);
        }
      },
    }
  )
);




// import { create } from "zustand";
// import { persist } from "zustand/middleware";
// import axios from "axios";
// import { toast } from "sonner";

// const API_URL = process.env.NEXT_PUBLIC_RECON_API_URL;

// const STATIC_TABLE_PATH =
//   process.env.NEXT_PUBLIC_STATIC_TABLE_PATH;
// let pollingTimer = null;
// let delayTimer = null;

// const normalize = (value) =>
//   value ? String(value).trim().toLowerCase() : "";

// /* ================= STATUS → PROGRESS ================= */

// const getProgressFromStatus = (status) => {
//   switch (status) {
//     case "queued":
//       return 20;

//     case "running":
//       return 50;

//     case "processing":
//       return 75;

//     case "success":
//       return 100;

//     case "failed":
//       return 100;

//     default:
//       return 30;
//   }
// };

// export const useReconStore = create(
//   persist(
//     (set, get) => ({
//       loading: false,
//       response: null,
//       error: null,
//       hasFetched: false,
//       currentTriggerId: null,
//       isPolling: false,
//       progress: 0,
//       selectedDate: null,
//       hasHydrated: false,

//       setSelectedDate: (date) => set({ selectedDate: date }),
//       setHasHydrated: (v) => set({ hasHydrated: v }),

//       /* ================= RUN ================= */

//       runRecon: async (payload) => {
//         set({
//           loading: true,
//           isPolling: true,
//           progress: 15,
//           response: null,
//           currentTriggerId: payload.trigger_id,
//         });

//         try {
//           const res = await axios.post(`${API_URL}/recon/runs`, payload);

//           toast.success("Reconciliation Pipeline Triggered");

//           get().startPolling();

//           return res.data;
//         } catch (err) {
//           toast.error("Failed to trigger reconciliation");

//           set({
//             loading: false,
//             isPolling: false,
//           });

//           throw err;
//         }
//       },

//       /* ================= RESTORE ================= */

//       restoreSession: async () => {
//         const triggerId = get().currentTriggerId;

//         if (!triggerId) return;

//         try {
//           const res = await axios.get(`${API_URL}/recon/status`, {
//             params: {
//               table_path: STATIC_TABLE_PATH,
//               trigger_id: triggerId,
//               _ts: Date.now(),
//             },
//           });

//           const records = res.data?.records || [];

//           set({
//             response: res.data,
//             hasFetched: true,
//           });

//           if (!records.length) {
//             if (!pollingTimer && !delayTimer) get().startPolling();
//             return;
//           }

//           const allPlantRow = records.find(
//             (r) => r.plant_id === "All Plants"
//           );

//           if (!allPlantRow) return;

//           const status = normalize(
//             allPlantRow.All_plant_completion_status
//           );

//           const progress = getProgressFromStatus(status);

//           set({ progress });

//           if (status === "success" || status === "failed") {
//             get().stopPolling();

//             set({
//               progress: 100,
//               loading: false,
//               isPolling: false,
//             });
//           } else {
//             if (!pollingTimer && !delayTimer) {
//               get().startPolling();
//             }
//           }
//         } catch (err) {
//           console.error("Restore error:", err);
//         }
//       },

//       /* ================= POLL STATUS ================= */

//       pollReconStatus: async () => {
//         const triggerId = get().currentTriggerId;

//         if (!triggerId) return;

//         try {
//           const res = await axios.get(`${API_URL}/recon/status`, {
//             params: {
//               table_path: STATIC_TABLE_PATH,
//               trigger_id: triggerId,
//               _ts: Date.now(),
//             },
//           });

//           const records = res.data?.records || [];

//           if (!records.length) return;

//           const allPlantRow = records.find(
//             (r) => r.plant_id === "All Plants"
//           );

//           if (!allPlantRow) return;

//           const status = normalize(
//             allPlantRow.All_plant_completion_status
//           );

//           const progress = getProgressFromStatus(status);

//           set({
//             response: res.data,
//             hasFetched: true,
//             progress,
//           });

//           if (status === "success" || status === "failed") {
//             get().stopPolling();

//             toast.success(
//               status === "success"
//                 ? "Reconciliation Completed 🎯"
//                 : "Reconciliation Failed ❌"
//             );

//             set({
//               progress: 100,
//               loading: false,
//               isPolling: false,
//             });
//           }
//         } catch (err) {
//           console.error("Polling error:", err);
//         }
//       },

//       /* ================= START POLLING ================= */

//       startPolling: () => {

//         // clear previous timers
//         if (pollingTimer) {
//           clearInterval(pollingTimer);
//           pollingTimer = null;
//         }

//         if (delayTimer) {
//           clearTimeout(delayTimer);
//           delayTimer = null;
//         }

//         console.log("🚀 First polling immediately");

//         // FIRST POLL
//         get().pollReconStatus();

//         console.log("⏳ Waiting 1 minute for second polling...");

//         delayTimer = setTimeout(() => {

//           console.log("🟢 Second polling started");

//           get().pollReconStatus();

//           console.log("🔁 Polling every 1 minute started");

//           pollingTimer = setInterval(() => {

//             console.log("📡 Polling API:", new Date());

//             get().pollReconStatus();

//           }, 1 * 60 * 1000); // ✅ 1 minute

//           set({ isPolling: true });

//         }, 1 * 60 * 1000); // ✅ wait 1 minute
//       },
//       /* ================= STOP POLLING ================= */

//       stopPolling: () => {
//         if (pollingTimer) {
//           clearInterval(pollingTimer);
//           pollingTimer = null;
//         }

//         if (delayTimer) {
//           clearTimeout(delayTimer);
//           delayTimer = null;
//         }

//         set({ isPolling: false });
//       },

//       /* ================= RESET ================= */

//       resetRecon: () => {
//         get().stopPolling();

//         set({
//           loading: false,
//           response: null,
//           currentTriggerId: null,
//           progress: 0,
//           isPolling: false,
//         });
//       },
//     }),
//     {
//       name: "recon-store",

//       partialize: (state) => ({
//         currentTriggerId: state.currentTriggerId,
//         progress: state.progress,
//         selectedDate: state.selectedDate,
//         response: state.response,
//         isPolling: state.isPolling,
//         loading: state.loading,
//       }),

//       onRehydrateStorage: () => (state) => {
//         if (!state) return;

//         state.setHasHydrated(true);

//         if (state.currentTriggerId) {
//           setTimeout(() => {
//             state.restoreSession();
//           }, 500);
//         }
//       },
//     }
//   )
// );