import { create } from "zustand";
import { toast } from "sonner";
import { useReconStore } from "./reconStore";

const API_URL = process.env.NEXT_PUBLIC_RECON_API_URL;

export const useRerunStore = create((set) => ({
    loading: false,
    rerunResponse: null,
    error: null,

    triggerRerun: async (payload) => {
        try {
            set({ loading: true, error: null });

            const reconState = useReconStore.getState();
            const triggerId = reconState.currentTriggerId;

            if (!triggerId) {
                toast.error("No active reconciliation found.");
                set({ loading: false });
                return;
            }

            console.log("🔁 Rerunning with Trigger ID:", triggerId);

            const response = await fetch(`${API_URL}/recon/rerun`, {
                method: "POST",
                headers: {
                    "Content-Type": "application/json",
                    accept: "application/json",
                },
                body: JSON.stringify({
                    ...payload,
                    trigger_id: triggerId,   // ✅ USING reconStore ID
                }),
            });

            const data = await response.json();

            toast.success("Rerun Triggered");

            const recon = useReconStore.getState();

            /* ===============================
               VERY IMPORTANT PART
            =============================== */

            // Stop any existing polling first
            recon.stopPolling();

            // Reset monitoring state but KEEP trigger ID
            useReconStore.setState({
                progress: 5,
                isPolling: true,
                loading: true,
                hasFetched: false,
                response: null,
            });

            // Immediate API hit
            await recon.pollReconStatus();

            // Restart polling
            recon.startPolling();

            set({
                rerunResponse: data,
                loading: false,
            });
        } catch (err) {
            console.error(err);
            toast.error("Rerun failed");
            set({ error: err.message, loading: false });
        }
    },
}));