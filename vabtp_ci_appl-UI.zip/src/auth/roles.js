export const ROLE_CONFIG = {


  P66_VABTP_P66_APPROVER: {
    role: "P66_VABTP_P66_APPROVER",
    groupId: "06da0075-ca3b-4683-9e12-62718b0af6f6",
  },

  P66_VABTP_CG_PROCESSOR: {
    role: "P66_VABTP_CG_PROCESSOR",
    groupId: "54ea3288-d682-4f93-bded-7a6c2f593538",
  },
  P66_VABTP_CG_LEAD: {
    role: "P66_VABTP_CG_LEAD",
    groupId: "2a75ad7a-1d8e-4bdd-87e3-2b96a706d0fe",
  },
};
