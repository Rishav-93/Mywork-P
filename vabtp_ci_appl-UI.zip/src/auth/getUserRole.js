import { ROLE_CONFIG } from "./roles";

export function getUserRole(user) {
  const { groups = [] } = user;

  // 👇 Add this line here
  // console.log("ALL GROUPS:", groups);

  for (const key in ROLE_CONFIG) {
    const { role, groupId } = ROLE_CONFIG[key];

    const matched = groups.includes(groupId);

    console.log(
      `Checking ${key} → ${groupId} → Match:`,
      matched
    );

    if (matched) {
      console.log("✅ ROLE FOUND:", role);
      return role;
    }
  }

  console.log("❌ NO ROLE MATCHED");

  return "NO_ACCESS";
}
