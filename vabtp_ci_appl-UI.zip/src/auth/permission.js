export const PERMISSIONS = {
P66_VABTP_CG_PROCESSOR: {
    viewStatus: true,
    askQuery: true,
    requestRerun: true,
    approveExport: true,
    triggerRecon: false,
    ruleUpdate: false,
  },

  P66_VABTP_CG_LEAD: {
    viewStatus: true,
    askQuery: true,
    requestRerun: true,
    approveExport: true,
    triggerRecon: true,
    ruleUpdate: true,
  },

  P66_VABTP_P66_APPROVER: {
    dashboard: true,
    approveRule: true,
    approveExport: true,
  },
};
