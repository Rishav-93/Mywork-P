"use client";

import { useEffect } from "react";
import { useMsal, useMsalAuthentication } from "@azure/msal-react";
import { InteractionStatus, InteractionType } from "@azure/msal-browser";
import { useAuthStore } from "@/store/auth";
import { getUserRole } from "./getUserRole";
import { loginRequest } from "../../authConfig";

export default function AuthProvider({ children }) {
  const { instance, accounts, inProgress } = useMsal();

  useMsalAuthentication(InteractionType.Redirect, loginRequest);

  const setUser = useAuthStore((s) => s.setUser);
  const setRole = useAuthStore((s) => s.setRole);

  useEffect(() => {
    if (inProgress !== InteractionStatus.None) {
      console.log("MSAL busy, skipping...");
      return;
    }

    const currentAccounts =
      accounts.length > 0 ? accounts : instance.getAllAccounts();

    if (!currentAccounts.length) {
      return;
    }

    const account = currentAccounts[0];
    instance.setActiveAccount(account);

    const claims = account.idTokenClaims;

    const user = {
      name: account.name,
      email:
        claims?.preferred_username ||
        claims?.email ||
        account.username,
      roles: claims?.roles || [],
      groups: claims?.groups || [],
    };

    console.log("AUTH USER:", user);

    setUser(user);

    const role = getUserRole(user);
    setRole(role);
  }, [accounts, inProgress, instance, setUser, setRole]);

  return children;
}
