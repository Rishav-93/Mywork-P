import { useMsal } from "@azure/msal-react";
import { useEffect, useState } from "react";

export function useAuth() {
  const { accounts } = useMsal();
  const [user, setUser] = useState(null);

  useEffect(() => {
    if (!accounts.length) return;

    const account = accounts[0];
    const claims = account.idTokenClaims;

    setUser({
      name: account.name,
      email: claims.preferred_username,
      roles: claims.roles || [],
      groups: claims.groups || [],
    });
  }, [accounts]);

  return user;
}
