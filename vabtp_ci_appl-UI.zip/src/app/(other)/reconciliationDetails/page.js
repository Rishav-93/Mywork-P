"use client";

import Header from "@/components/common/header";
import Logout from "@/components/common/logout";
import PromptChat from "@/components/common/promptChat";
import ReconDetails from "@/components/reconProcess/reconDetails";
import Sidebar from "@/components/sidebar/sidebar";

export default function ReconciliationDetails() {
  return (
    <div className="min-h-screen grid grid-cols-12 gap-3">
      <Sidebar />
      <div className="col-span-10 gap-4 h-full">
        <div className="col-span-12 grid grid-cols-12">
          <div className="col-span-12 mb-3">
            <Header title="Reconciliation Detail" />
            {/* <FilterPanel /> */}
          </div>
        </div>

        <div className="grid grid-cols-10 gap-3  ">
          <div className="col-span-12    rounded-xl   ">
            <ReconDetails />
          </div>
        </div>
      </div>

      {/* <div className="col-span-2">
     
        <div className=" h-full">
          <PromptChat />
        </div>
      </div> */}
    </div>
  );
}
