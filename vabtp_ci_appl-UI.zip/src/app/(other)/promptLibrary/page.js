"use client";

import Header from "@/components/common/header";
import Logout from "@/components/common/logout";
import PromptChat from "@/components/common/promptChat";
import PromptLibrary from "@/components/promptLibrary/promptLibrary";
import ReconDetails from "@/components/reconProcess/reconDetails";
import Sidebar from "@/components/sidebar/sidebar";
import TriggerLog from "@/components/triggerLog/triggerLog";

export default function Page() {
  return (
    <div className="min-h-screen grid grid-cols-12 gap-3">
      <Sidebar />
      <div className="col-span-10 gap-4 h-full">
        <div className="col-span-12 grid grid-cols-12">
          <div className="col-span-12 mb-3">
            <Header title="Prompt Library" />
            {/* <FilterPanel /> */}
          </div>
        </div>

        <div className="grid grid-cols-10 gap-3  ">
          
          <div className="col-span-12    rounded-xl   ">
            <PromptLibrary />
          </div>
        </div>
      </div>
    </div>
  );
}
