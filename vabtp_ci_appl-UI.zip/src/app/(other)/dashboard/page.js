"use client";

import Header from "@/components/common/header";
import Logout from "@/components/common/logout";
import PromptChat from "@/components/common/promptChat";
import Dashboard from "@/components/dashboard/dashboard";
import Sidebar from "@/components/sidebar/sidebar";

export default function DashboardPage() {
  return (
    <div className="min-h-screen grid grid-cols-12 gap-3">
      <Sidebar />

      {/* <div className="col-span-10 gap-4 h-full">
        <div className="col-span-12 grid grid-cols-12">
          <div className="col-span-12 mb-3">
            <Header title="Dashboard" /> 
          </div>
        </div>

        <div className="grid grid-cols-8 gap-3  ">
          <div className="col-span-12 bg-white p-4 rounded-xl border border-border-muted">
            <Dashboard />
          </div>
        </div>
          
      </div> */}
       <div className="col-span-10 gap-4 h-full">
              <div className="col-span-10 grid grid-cols-12">
                <div className="col-span-12 mb-3">
                  <Header title="Dashboard" />
                  {/* <FilterPanel /> */}
                </div>
              </div>
      
              <div className="grid grid-cols-10 gap-3  ">
                <div className="col-span-12    rounded-xl   ">
                  <Dashboard />
                </div>
              </div>
            </div>
{/*       
            <div className="col-span-2">
              
              <div className="h-full">
                <PromptChat />
              </div>
            </div> */}
    </div>
  );
}
