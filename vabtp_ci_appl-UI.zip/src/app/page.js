"use client";

import Header from "@/components/common/header";
import Trac66 from "@/components/trac/trac66";
import Sidebar from "@/components/sidebar/sidebar";

import { useMsal } from "@azure/msal-react";
import { useEffect, useState } from "react";
import { InteractionStatus } from "@azure/msal-browser";

import { useReconStore } from "@/store/reconStore";

export default function Home() {
  const { accounts, inProgress } = useMsal();

  const [email, setEmail] = useState("");

  // ✅ Zustand selectors
  const hasHydrated = useReconStore((s) => s.hasHydrated);
  const restoreSession = useReconStore((s) => s.restoreSession);
  const fetchCurrentStatus = useReconStore((s) => s.fetchCurrentStatus);

  /* ================= MAIN FLOW ================= */
  useEffect(() => {
    if (inProgress !== InteractionStatus.None) return;

    if (accounts.length === 0) {
      return;
    }

    /* ================= WAIT FOR HYDRATION ================= */
    if (!hasHydrated) {
      console.log("⏳ Waiting for hydration...");
      return;
    }

    const user = accounts[0];

    const userEmail =
      user.username ||
      user.idTokenClaims?.preferred_username ||
      user.idTokenClaims?.email;

    console.log("✅ Logged in User Email:", userEmail);

    setEmail(userEmail);

    const {
      currentTriggerId,
      hasRunTriggered,
      isPolling,
    } = useReconStore.getState();

    console.log("🧠 STORE STATE:", {
      currentTriggerId,
      hasRunTriggered,
      isPolling,
    });

    /* ================= CASE 1: ACTIVE RUN ================= */
    if (isPolling || hasRunTriggered) {
      console.log("♻️ Active run → restoring session");
      restoreSession();
      return;
    }

    /* ================= CASE 2: NO ACTIVE RUN ================= */
    console.log("📡 Calling current status API");
    fetchCurrentStatus();

  }, [accounts, inProgress, hasHydrated, fetchCurrentStatus, restoreSession]);
  /* ================= UI ================= */
  return (
    <div className="min-h-screen grid grid-cols-12 gap-3">
      <Sidebar />

      <div className="col-span-10 gap-4 h-full">
        <div className="col-span-12 grid grid-cols-12">
          <div className="col-span-12 mb-3">
            <Header title="Trac66" />
          </div>
        </div>

        <div className="grid grid-cols-10 gap-3">
          <div className="col-span-12 rounded-xl">
            <Trac66 />
          </div>
        </div>
      </div>
    </div>
  );
}
