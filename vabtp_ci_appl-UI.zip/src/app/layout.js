import "./globals.css";
import MsalAuthProvider from "../../msalProvider";
import AuthProvider from "@/auth/authProvider"; // 👈 ADD
import { Toaster } from "sonner";

export const metadata = {
  title: "Phillips 66",
  description: "Phillips 66",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className="bg-[#fff] h-full p-2">

        <MsalAuthProvider>
          <AuthProvider>   {/* 👈 ADD */}
            {children}
          </AuthProvider>
        </MsalAuthProvider>
        <Toaster position="top-right" closeButton richColors />
      </body>
    </html>
  );
}
