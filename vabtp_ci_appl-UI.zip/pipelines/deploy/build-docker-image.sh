echo "Building Docker image..."

export IMAGE_NAME="vabtp-ui"
export TAG="${RELEASE_RELEASEID}"

cd "$(System.DefaultWorkingDirectory)/_vabtp_ci_appl-UI/Package"

echo "====================================="
echo "AZURE DEVOPS PIPELINE VARIABLES"
echo "====================================="

echo "NEXT_PUBLIC_CLIENT_ID=$(nextPublicClientId)"
echo "NEXT_PUBLIC_TENANT_ID=$(nextPublicTenantId)"
echo "NEXT_PUBLIC_REDIRECT_URI=$(nextPublicRedirectUri)"
echo "NEXT_PUBLIC_RECON_API_URL=$(nextPublicReconApiUrl)"
echo "NEXT_PUBLIC_DASHBOARD_IFRAME_URL=$(nextPublicDashboardIframeUrl)"
echo "NEXT_PUBLIC_RESULT_IFRAME_URL=$(nextPublicResultIframeUrl)"
echo "NEXT_PUBLIC_RECONDETAILS_IFRAME_URL=$(nextPublicRecondetailsIframeUrl)"
echo "NEXT_PUBLIC_STATIC_TABLE_PATH=$(nextPublicStaticTablePath)"
echo "NEXT_PUBLIC_RULE_UPDATE_TABLEPATH=$(nextPublicRuleUpdateTablepath)"
echo "NEXT_PUBLIC_SOURCE_SCHEMA_PATH=$(nextPublicSourceSchemaPath)"
echo "NEXT_PUBLIC_INDEX_MOT_PATH=$(nextPublicIndexMotPath)"
echo "NEXT_PUBLIC_RULE_PROMPT_PLANT_TABLE=$(nextPublicRulePromptPlantTable)"
echo "NEXT_PUBLIC_RULE_PROMPT_PLANT_LIST=$(nextPublicRulePromptPlantList)"

echo "====================================="

docker build \
  --build-arg NEXT_PUBLIC_CLIENT_ID="$(nextPublicClientId)" \
  --build-arg NEXT_PUBLIC_TENANT_ID="$(nextPublicTenantId)" \
  --build-arg NEXT_PUBLIC_REDIRECT_URI="$(nextPublicRedirectUri)" \
  --build-arg NEXT_PUBLIC_RECON_API_URL="$(nextPublicReconApiUrl)" \
  --build-arg NEXT_PUBLIC_DASHBOARD_IFRAME_URL="$(nextPublicDashboardIframeUrl)" \
  --build-arg NEXT_PUBLIC_RESULT_IFRAME_URL="$(nextPublicResultIframeUrl)" \
  --build-arg NEXT_PUBLIC_RECONDETAILS_IFRAME_URL="$(nextPublicRecondetailsIframeUrl)" \
  --build-arg NEXT_PUBLIC_STATIC_TABLE_PATH="$(nextPublicStaticTablePath)" \
  --build-arg NEXT_PUBLIC_RULE_UPDATE_TABLEPATH="$(nextPublicRuleUpdateTablepath)" \
  --build-arg NEXT_PUBLIC_SOURCE_SCHEMA_PATH="$(nextPublicSourceSchemaPath)" \
  --build-arg NEXT_PUBLIC_INDEX_MOT_PATH="$(nextPublicIndexMotPath)" \
  --build-arg NEXT_PUBLIC_RULE_PROMPT_PLANT_TABLE="$(nextPublicRulePromptPlantTable)" \
  --build-arg NEXT_PUBLIC_RULE_PROMPT_PLANT_LIST="$(nextPublicRulePromptPlantList)" \
  -t "${IMAGE_NAME}:${TAG}" .

echo "Docker image build completed successfully."

echo "Creating TAR file..."

docker save "${IMAGE_NAME}:${TAG}" \
  -o "./${IMAGE_NAME}-${TAG}.tar"

echo "TAR file created successfully."

ls -lh