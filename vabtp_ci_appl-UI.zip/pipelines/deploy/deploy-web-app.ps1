$ErrorActionPreference = "Stop"

# ---------------------------
# Variables (from Variable Group)
# ---------------------------
$ResourceGroup = $env:DEPLOYMENT_RG
$WebAppName    = $env:WEBAPP_NAME
$AcrName       = $env:ACR_NAME
$ImageName     = $env:DOCKER_IMAGE_NAME_UI

# Tag logic (Release or Build)
$ImageTag = $env:RELEASE_RELEASEID
if ([string]::IsNullOrWhiteSpace($ImageTag)) {
    $ImageTag = $env:BUILD_BUILDID
}

# ---------------------------
# Validation
# ---------------------------
if ([string]::IsNullOrWhiteSpace($ResourceGroup)) { throw "RESOURCE_GROUP is empty" }
if ([string]::IsNullOrWhiteSpace($WebAppName))    { throw "WEBAPP_NAME is empty" }
if ([string]::IsNullOrWhiteSpace($AcrName))       { throw "ACR_NAME is empty" }
if ([string]::IsNullOrWhiteSpace($ImageName))     { throw "DOCKER_IMAGE_NAME_UI is empty" }
if ([string]::IsNullOrWhiteSpace($ImageTag))      { throw "ImageTag is empty" }

$AcrLoginServer = "$AcrName.azurecr.io"
$ImageFullName  = "${AcrLoginServer}/${ImageName}:${ImageTag}"

Write-Host "Deploying image:"
Write-Host "  $ImageFullName"

# ---------------------------
# Azure Login (already done in AzureCLI task)
# ---------------------------
az account show 1>$null

# ---------------------------
# Configure Web App Container
# ---------------------------
az webapp config container set `
  --resource-group $ResourceGroup `
  --name $WebAppName `
  --container-image-name $ImageFullName `
  --container-registry-url "https://$AcrLoginServer"

# ---------------------------
# Restart Web App (important)
# ---------------------------
az webapp restart `
  --resource-group $ResourceGroup `
  --name $WebAppName

Write-Host "✅ Deployment to Azure Web App completed successfully"