$ErrorActionPreference = "Stop"

# ---------------------------
# Fetch from Variable Group
# ---------------------------
$AcrName   = $env:ACR_NAME
$ImageName = $env:DOCKER_IMAGE_NAME_UI

# Use ReleaseId or BuildId as tag
$ImageTag = if ($env:RELEASE_RELEASEID) {
    $env:RELEASE_RELEASEID
} else {
    $env:BUILD_BUILDID
}

# ---------------------------
# Artifact Location
# ---------------------------
$ArtifactRoot = "$env:SYSTEM_DEFAULTWORKINGDIRECTORY/_vabtp_ci_appl-UI/Package"

Write-Host "Artifact root: $ArtifactRoot"

Write-Host "Listing files:"
Get-ChildItem -Path $ArtifactRoot -Recurse

# ---------------------------
# Find TAR File
# ---------------------------
$TarFile = Get-ChildItem `
    -Path $ArtifactRoot `
    -Filter "*.tar" `
    -Recurse |
    Select-Object -First 1

if (-not $TarFile) {
    throw "❌ No TAR file found in artifact directory."
}

$TarImagePath = $TarFile.FullName

# ---------------------------
# ACR Details
# ---------------------------
$AcrLoginServer = "$AcrName.azurecr.io"
$AcrImage = "${AcrLoginServer}/${ImageName}:${ImageTag}"

Write-Host "Using TAR file: $TarImagePath"
Write-Host "Target ACR image: $AcrImage"

# ---------------------------
# Login to Azure & ACR
# ---------------------------
Write-Host "Logging into Azure..."
az account show 1>$null

Write-Host "Logging into ACR..."
az acr login --name $AcrName

# ---------------------------
# Load Docker Image from TAR
# ---------------------------
Write-Host "Loading Docker image from TAR..."

$loadOutput = docker load -i $TarImagePath

Write-Host $loadOutput

if ($loadOutput -match "Loaded image:\s(.+)") {
    $LocalImage = $matches[1]
}
else {
    throw "❌ Failed to extract image name from docker load output."
}

Write-Host "Loaded local image: $LocalImage"

# ---------------------------
# Tag Image for ACR
# ---------------------------
Write-Host "Tagging image..."
docker tag $LocalImage $AcrImage

# ---------------------------
# Push Image to ACR
# ---------------------------
Write-Host "Pushing image to ACR..."
docker push $AcrImage

Write-Host "✅ Image successfully pushed to ACR"