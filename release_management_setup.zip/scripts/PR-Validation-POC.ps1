$ErrorActionPreference = "Stop"

# -------------------------------------------------
# Azure DevOps PR Variables
# -------------------------------------------------
$organizationUrl = "$(System.CollectionUri)".TrimEnd('/')
$project         = "$(System.TeamProject)"
$repositoryId    = "$(Build.Repository.ID)"
$pullRequestId   = "$(System.PullRequest.PullRequestId)"
$accessToken     = "$(System.AccessToken)"

# -------------------------------------------------
# Validate PR Context
# -------------------------------------------------
Write-Host "Build Reason      : $(Build.Reason)"
Write-Host "Pull Request ID   : $pullRequestId"

if ([string]::IsNullOrWhiteSpace($pullRequestId)) {
    Write-Error "No Pull Request ID found. Ensure this pipeline runs as PR validation."
}

# -------------------------------------------------
# Build Auth Header
# -------------------------------------------------
$base64AuthInfo = [Convert]::ToBase64String(
    [Text.Encoding]::ASCII.GetBytes(":$accessToken")
)

$headers = @{
    Authorization = "Basic $base64AuthInfo"
    "Content-Type" = "application/json"
}

# -------------------------------------------------
# PR API URL
# -------------------------------------------------
$prUrl = "$organizationUrl/$project/_apis/git/repositories/$repositoryId/pullRequests/$pullRequestId?api-version=7.1"

Write-Host ""
Write-Host "Fetching current PR details..."
Write-Host "PR URL: $prUrl"
Write-Host ""

# -------------------------------------------------
# Get Current PR
# -------------------------------------------------
try {

    $pr = Invoke-RestMethod `
        -Uri $prUrl `
        -Headers $headers `
        -Method Get
}
catch {

    Write-Host "Failed to fetch current PR."
    throw
}

# -------------------------------------------------
# Output PR Details
# -------------------------------------------------
Write-Host "=========================================="
Write-Host "Current Pull Request Details"
Write-Host "=========================================="

Write-Host "PR ID           : $($pr.pullRequestId)"
Write-Host "Title           : $($pr.title)"
Write-Host "Description     : $($pr.description)"
Write-Host "Created By      : $($pr.createdBy.displayName)"
Write-Host "Status          : $($pr.status)"
Write-Host "Source Branch   : $($pr.sourceRefName)"
Write-Host "Target Branch   : $($pr.targetRefName)"
Write-Host "Creation Date   : $($pr.creationDate)"

Write-Host "=========================================="