param (
    [string]$BuildReason,
    [string]$PullRequestId,
    #[string]$RepositoryId,
    [string]$Project,
    [string]$CollectionUri,
    [string]$AccessToken
)

$ErrorActionPreference = "Stop"

# -------------------------------------------------
# Debug Information
# -------------------------------------------------
Write-Host "Build Reason: $BuildReason"
Write-Host "PullRequestId: $PullRequestId"
# Write-Host "Repository Name: $reponame"
Write-Host "BUILD_REPOSITORY_NAME: $env:BUILD_REPOSITORY_NAME"
Write-Host "SYSTEM_PULLREQUEST_SOURCEREPOSITORYURI: $repoUri"
Write-Host "Actual PR Repository Name: $reponame"
Write-Host "Project: $Project"
Write-Host "Collection URI: $CollectionUri"

# -------------------------------------------------
# Variables
# -------------------------------------------------
$organizationUrl = $CollectionUri.TrimEnd('/')
$project         = $Project
# $repoId        = $RepositoryId
#$reponame        = $env:BUILD_Repository_Name

# Get actual PR repository from source branch
$repoUri = $env:SYSTEM_PULLREQUEST_SOURCEREPOSITORYURI

if ([string]::IsNullOrWhiteSpace($repoUri)) {
    Write-Error "SYSTEM_PULLREQUEST_SOURCEREPOSITORYURI is empty."
}

$reponame = $repoUri.Split('/')[-1]

# -------------------------------------------------
# Get PR ID
# -------------------------------------------------
$prId = $PullRequestId

# if ([string]::IsNullOrWhiteSpace($prId)) {
#     Write-Host "Primary PR variable is empty. Trying fallback..."
#     $prId = $PullRequestNumber
# }

if ([string]::IsNullOrWhiteSpace($prId)) {
    Write-Error "Pull Request ID could not be determined."
}

Write-Host "Final PR ID: $prId"

# -------------------------------------------------
# OAuth Token
# -------------------------------------------------
$token = $AccessToken

if ([string]::IsNullOrWhiteSpace($token)) {
    Write-Error "Access token is empty. Enable OAuth token in pipeline."
}

$base64AuthInfo = [Convert]::ToBase64String(
    [Text.Encoding]::ASCII.GetBytes(":$token")
)

$headers = @{
    Authorization = "Basic $base64AuthInfo"
    "Content-Type" = "application/json"
}

# -------------------------------------------------
# PR Details API
# -------------------------------------------------
$prUrl = "${organizationUrl}/${project}/_apis/git/repositories/${reponame}/pullRequests/${prId}?api-version=7.1"

Write-Host "`nPR URL:`n$prUrl`n"

# -------------------------------------------------
# Fetch PR Details
# -------------------------------------------------
Write-Host "Fetching PR details..."

$pr = Invoke-RestMethod -Uri $prUrl -Headers $headers -Method Get

$title       = $pr.title
$description = $pr.description

Write-Host "`nPR Title:`n$title`n"

$validationFailed = $false

# -------------------------------------------------
# Validation 1 : Title length > 15
# -------------------------------------------------

# Validate PR title format:
# <Story_number>_Description_DDMMYYYY
# Example:
# 12345_Login Fix_25052026

$pattern = '^\d+_[A-Za-z0-9 _-]+_\d{8}$'

if ([string]::IsNullOrWhiteSpace($title) -or ($title -notmatch $pattern)) {

    Write-Host "##vso[task.logissue type=error]PR title must follow format: <Story_number>_Description_DDMMYYYY"
    Write-Host "##vso[task.logissue type=error]Example: 12345_Login Fix_25052026"

    $validationFailed = $true
}
else {
    Write-Host "Title validation passed."
}

#if ([string]::IsNullOrWhiteSpace($title) -or $title.Length -le 15) {
 #   Write-Host "##vso[task.logissue type=error]PR title must be greater than 15 characters."
  #  $validationFailed = $true
#}
#else {
 #   Write-Host "Title validation passed."
#}

# -------------------------------------------------
# Validation 2 : Description exists
# -------------------------------------------------
if ([string]::IsNullOrWhiteSpace($description)) {
    Write-Host "##vso[task.logissue type=error]PR description is missing."
    $validationFailed = $true
}
else {
    Write-Host "Description validation passed."
}

# -------------------------------------------------
# Threads API
# -------------------------------------------------
$threadsUrl = "$organizationUrl/$project/_apis/git/repositories/$reponame/pullRequests/$prId/threads?api-version=7.1"

Write-Host "`nThreads URL:`n$threadsUrl`n"
Write-Host "Fetching PR comments..."

$threads = Invoke-RestMethod -Uri $threadsUrl -Headers $headers -Method Get

$commentCount = 0

foreach ($thread in $threads.value) {
    foreach ($comment in $thread.comments) {
        if (-not [string]::IsNullOrWhiteSpace($comment.content)) {
            $commentCount++
        }
    }
}

Write-Host "`nTotal comments found: $commentCount`n"

# -------------------------------------------------
# Validation 3 : At least one comment
# -------------------------------------------------
if ($commentCount -lt 1) {
    Write-Host "##vso[task.logissue type=error]At least one PR comment is required."
    $validationFailed = $true
}
else {
    Write-Host "Comment validation passed."
}

# -------------------------------------------------
# Final Result
# -------------------------------------------------
if ($validationFailed) {
    Write-Error "PR validation failed."
}
else {
    Write-Host "`n=========================================="
    Write-Host "All PR validations passed successfully."
    Write-Host "==========================================`n"
}