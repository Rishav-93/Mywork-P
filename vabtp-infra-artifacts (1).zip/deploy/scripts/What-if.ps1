param (
    [Parameter(Mandatory)]
    [string]$DeploymentResourceGroup,

    [Parameter(Mandatory)]
    [string]$DeploymentName,

    [Parameter(Mandatory)]
    [string]$TemplateFile,

    [Parameter(Mandatory)]
    [string]$ParameterFile,

    # Generic override string (ANY parameters, space-separated)
    [Parameter(Mandatory)]
    [string]$CliOverrideParameters
)

Write-Host "=============================================="
Write-Host " ARM WHAT-IF DEPLOYMENT (Generic Parameters)"
Write-Host "=============================================="

Write-Host "Overrides from pipeline (raw string):"
Write-Host $CliOverrideParameters

# -------------------------------------------------
# Build tags INSIDE the script (owned by script)
# -------------------------------------------------
$tags = @{
    Application    = $env:WORKLOAD_NAME
    BusinessStream = "AES"
    CostCenter     = "1011100180"
    Customer       = "va_btp_team"
    Environment    = $env:ENVIRONMENT
    UserGroup      = "SD_GLOBAL_APPS_CG-VA_BUILD"
}

# Write tags to JSON file
$tagsFile = "tags.json"
$tags | ConvertTo-Json -Depth 5 | Out-File $tagsFile -Encoding utf8

Write-Host "Generated tags.json:"
Get-Content $tagsFile | Write-Host

# -------------------------------------------------
# Convert CLI overrides into an ARRAY (CRITICAL)
# -------------------------------------------------
$CliOverrideArray = $CliOverrideParameters -split '\s+'

# Append tags as OBJECT reference (no quotes)
$CliOverrideArray += "p66_tags=@$tagsFile"

Write-Host "Final CLI override parameter array:"
$CliOverrideArray | ForEach-Object {
    Write-Host "  $_"
}

# -------------------------------------------------
# Execute WHAT-IF
# -------------------------------------------------
az deployment group what-if `
    --resource-group $DeploymentResourceGroup `
    --name $DeploymentName `
    --template-file $TemplateFile `
    --parameters "@$ParameterFile" `
    --parameters $CliOverrideArray `
    --result-format FullResourcePayloads