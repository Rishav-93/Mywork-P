function Grant-StorageBlobDataContributorRole {
    param (
        [string]$subscription,
        [string]$storageaccount,
        [string]$resourcegroup,
        [string]$appclientid
    )

    $scope = "/subscriptions/$($subscription)/resourceGroups/$($resourcegroup)/providers/Microsoft.Storage/storageAccounts/$($storageaccount)"
    $role  = "Storage Blob Data Contributor"

    # Resolve the App Registration's service principal objectId from clientId
    $appObjectId = az ad sp show --id "$($appclientid)" --query id -o tsv

    if (-not $appObjectId) {
      Write-Error " Unable to resolve service principal objectId for APP_CLIENT_ID $($appclientid)."
      exit 1
    }

    # Check if role assignment already exists
    $existing = az role assignment list `
      --assignee $appObjectId `
      --scope $scope `
      --role "$role" | ConvertFrom-Json

    if (-not $existing) {
      Write-Host "Creating data-plane RBAC assignment ($role) for objectId $appObjectId on $scope ..."
      az role assignment create `
        --assignee-object-id $appObjectId `
        --assignee-principal-type ServicePrincipal `
        --role "$role" `
        --scope $scope | Out-Null
    }
    else {
      Write-Host "Data-plane RBAC already exists. Skipping."
    }
}

function Test-AdlsDnsResolution {
    param (
        [string]$AdlsAccount
    )

    $dfsFqdn = "$AdlsAccount.dfs.core.windows.net"

    try {
        Resolve-DnsName $dfsFqdn -ErrorAction Stop | Out-Null
    }
    catch {
        Write-Error " Cannot resolve $dfsFqdn. Ensure Private DNS zone link and VNet DNS are configured."
        exit 1
    }

    Write-Host " DNS resolution OK for $dfsFqdn"
}

#Test-AdlsDnsResolution -AdlsAccount $env:ADLS_ACCOUNT

# function New-AdlsDirectories {
#     param (
#         [string]$AdlsAccount,
#         [string]$AppClientId,
#         [string]$AppClientSecret,
#         [string]$TenantId
#     )

#     # Sign in as the App Registration for data-plane operations
#     az account clear | Out-Null

#     az login --service-principal `
#       -u "$AppClientId" `
#       -p "$AppClientSecret" `
#       --tenant "$TenantId" | Out-Null

#     # Sanity: list file systems using Entra token
#     az storage fs list --account-name $AdlsAccount --auth-mode login | Out-Null

#     Write-Host "Creating folders inside ADLS Gen2..."

#     $containers = @("p66-files","p66-files-backup")
#     $dirs = @("input-files","output-files")

#     foreach ($container in $containers) {
#       foreach ($folder in $dirs) {

#         Write-Host "Creating directory: $container/$folder"

#         az storage fs directory create `
#           --account-name $AdlsAccount `
#           --file-system $container `
#           --name $folder `
#           --auth-mode login `
#           --output none
#       }
#     }

#     Write-Host "Folder creation completed."

#     # -------------------------
#     # Validation (existence)
#     # -------------------------
#     $missing = @()

#     foreach ($container in $containers) {
#       foreach ($folder in $dirs) {

#         $exists = az storage fs directory exists `
#           --account-name $AdlsAccount `
#           --file-system  $container `
#           --name         $folder `
#           --auth-mode    login `
#           --query exists -o tsv 2>$null

#         if ($exists -ne 'true') {
#           Write-Host "MISSING: $container/$folder"
#           $missing += "$container/$folder"
#         }
#         else {
#           Write-Host "Present:  $container/$folder"
#         }
#       }
#     }

#     if ($missing.Count -gt 0) {
#       Write-Error "One or more directories are missing: $($missing -join ', ')"
#       exit 2
#     }
#     else {
#       Write-Host "All expected directories exist."
#     }
# }
function New-AdlsDirectories {

    [CmdletBinding()]
    param (
        [Parameter(Mandatory = $true)]
        [string]$AdlsAccount,

        [Parameter(Mandatory = $true)]
        [string]$AppClientId,

        [Parameter(Mandatory = $true)]
        [string]$AppClientSecret,

        [Parameter(Mandatory = $true)]
        [string]$TenantId,

        [string[]]$Containers = @(
            "p66-files",
            "p66-files-backup"
        ),

        [string[]]$Directories = @(
            "input-files",
            "output-files"
        )
    )

    $ErrorActionPreference = 'Stop'

    Write-Host "Authenticating using Service Principal..."

    az login `
        --service-principal `
        --username $AppClientId `
        --password $AppClientSecret `
        --tenant $TenantId `
        --output none

    Write-Host "Validating ADLS access..."

    az storage fs list `
        --account-name $AdlsAccount `
        --auth-mode login `
        --output none

    foreach ($container in $Containers) {

        Write-Host "Checking container: $container"

        $containerExists = az storage fs exists `
            --account-name $AdlsAccount `
            --name $container `
            --auth-mode login `
            --query "exists" `
            --output tsv 2>$null

        if ($containerExists -ne "true") {

            Write-Host "Container does not exist. Creating: $container"

            az storage fs create `
                --account-name $AdlsAccount `
                --name $container `
                --auth-mode login `
                --output none

            Write-Host "Container created: $container"
        }
        else {

            Write-Host "Container already exists: $container"
        }

        foreach ($directory in $Directories) {

            Write-Host "Creating directory: $container/$directory"

            az storage fs directory create `
                --account-name $AdlsAccount `
                --file-system $container `
                --name $directory `
                --auth-mode login `
                --output none
        }
    }

    Write-Host "Directory creation completed."

    # -------------------------
    # Validation
    # -------------------------

    $missingDirectories = @()

    Write-Host "Validating created directories..."

    foreach ($container in $Containers) {

        foreach ($directory in $Directories) {

            $exists = az storage fs directory exists `
                --account-name $AdlsAccount `
                --file-system $container `
                --name $directory `
                --auth-mode login `
                --query "exists" `
                --output tsv 2>$null

            if ($exists -eq "true") {

                Write-Host "Present: $container/$directory"
            }
            else {

                Write-Host "Missing: $container/$directory"

                $missingDirectories += "$container/$directory"
            }
        }
    }

    if ($missingDirectories.Count -gt 0) {

        throw "One or more directories are missing: $($missingDirectories -join ', ')"
    }
    else {

        Write-Host "All expected directories exist."
    }
}
# New-AdlsDirectories `
#     -AdlsAccount $env:ADLS_ACCOUNT `
#     -AppClientId $env:APP_CLIENT_ID `
#     -AppClientSecret $env:APP_CLIENT_SECRET `
#     -TenantId $env:TENANT_ID

function Set-AdlsLeadPermissions {
    param (
        [string]$storageAccount,
        [string]$leadGroup1,
        [string]$leadGroup2,
        [string[]]$containers
    )

    $ErrorActionPreference = "Stop"

    Write-Host "Fetching Storage Account Resource ID..."
    $saId = az storage account show `
      --name $storageAccount `
      --query id `
      -o tsv

    Write-Host "Fetching AD Group Object IDs..."
    $lead1ObjId = az ad group show `
      --group $leadGroup1 `
      --query id `
      -o tsv

    $lead2ObjId = az ad group show `
      --group $leadGroup2 `
      --query id `
      -o tsv

    Write-Host "Assigning Reader Role..."
    az role assignment create `
      --assignee-object-id $lead1ObjId `
      --assignee-principal-type Group `
      --role "Reader" `
      --scope $saId

    az role assignment create `
      --assignee-object-id $lead2ObjId `
      --assignee-principal-type Group `
      --role "Reader" `
      --scope $saId

    Write-Host "Assigning Storage Blob Data Reader..."
    az role assignment create `
      --assignee-object-id $lead1ObjId `
      --assignee-principal-type Group `
      --role "Storage Blob Data Reader" `
      --scope $saId

    az role assignment create `
      --assignee-object-id $lead2ObjId `
      --assignee-principal-type Group `
      --role "Storage Blob Data Reader" `
      --scope $saId

    foreach ($container in $containers) {

        Write-Host "Processing Container: $container"

        Write-Host "Applying RWX on input-files..."
        az storage fs access set-recursive `
          --account-name $storageAccount `
          --file-system $container `
          --path "input-files" `
          --acl "group:$lead1ObjId:rwx,default:group:$lead1ObjId:rwx" `
          --auth-mode login

        az storage fs access set-recursive `
          --account-name $storageAccount `
          --file-system $container `
          --path "input-files" `
          --acl "group:$lead2ObjId:rwx,default:group:$lead2ObjId:rwx" `
          --auth-mode login

        Write-Host "Applying R-X on output-files..."
        az storage fs access set-recursive `
          --account-name $storageAccount `
          --file-system $container `
          --path "output-files" `
          --acl "group:$lead1ObjId:r-x,default:group:$lead1ObjId:r-x" `
          --auth-mode login

        az storage fs access set-recursive `
          --account-name $storageAccount `
          --file-system $container `
          --path "output-files" `
          --acl "group:$lead2ObjId:r-x,default:group:$lead2ObjId:r-x" `
          --auth-mode login
    }

    Write-Host "ACL Assignment Completed Successfully"
}

# Set-AdlsLeadPermissions `
#     -storageAccount "azrvabtpadls01r3" `
#     -leadGroup1 "P66_VABTP_CG_LEAD" `
#     -leadGroup2 "P66_VABTP_CG_LEAD_QA" `
#     -containers @("p66-files","p66-files-backup")

# function Update-KeyVaultSecretExpiry {
#     param(
#         [Parameter(Mandatory = $true)]
#         [string]$KeyVaultName
#     )

#     $ErrorActionPreference = 'Stop'

#     $clientId = az account show --query user.name -o tsv
#     az ad sp show --id $clientId -o json

#     $secretNamesTsv = az keyvault secret list `
#         --vault-name $KeyVaultName `
#         --query "[].name" `
#         -o tsv

#     if ([string]::IsNullOrWhiteSpace($secretNamesTsv)) {
#         Write-Host "No secrets found."
#         return
#     }

#     $secretNames = $secretNamesTsv -split "\r?\n" |
#         Where-Object { $_ } |
#         ForEach-Object { $_.Trim() }

#     $newExpiry = (Get-Date).ToUniversalTime().AddYears(1).ToString("yyyy-MM-ddTHH:mm:ssZ")

#     foreach ($name in $secretNames) {

#         if ([string]::IsNullOrWhiteSpace($name)) {
#             continue
#         }

#         $value = az keyvault secret show `
#             --vault-name $KeyVaultName `
#             --name $name `
#             --query "value" `
#             -o tsv

#         if (-not $value) {
#             continue
#         }

#         az keyvault secret set `
#             --vault-name $KeyVaultName `
#             --name $name `
#             --value $value `
#             --expires $newExpiry | Out-Null

#         Write-Host "Updated $name"
#     }

#     Write-Host "Secret expiry update completed successfully."
# }
function Update-KeyVaultSecretExpiry {
    param(
        [Parameter(Mandatory = $true)]
        [string]$KeyVaultName,

        [Parameter(Mandatory = $true)]
        [string]$AppClientId,

        [Parameter(Mandatory = $true)]
        [string]$AppClientSecret,

        [Parameter(Mandatory = $true)]
        [string]$TenantId
    )

    $ErrorActionPreference = 'Stop'

    az account clear | Out-Null

    az login --service-principal `
        -u "$AppClientId" `
        -p "$AppClientSecret" `
        --tenant "$TenantId" | Out-Null

    $secretNamesTsv = az keyvault secret list `
        --vault-name $KeyVaultName `
        --query "[].name" `
        -o tsv

    if ([string]::IsNullOrWhiteSpace($secretNamesTsv)) {
        Write-Host "No secrets found."
        return
    }

    $secretNames = $secretNamesTsv -split "\r?\n" |
        Where-Object { $_ } |
        ForEach-Object { $_.Trim() }

    $newExpiry = (Get-Date).ToUniversalTime().AddYears(1).ToString("yyyy-MM-ddTHH:mm:ssZ")

    foreach ($name in $secretNames) {

        $value = az keyvault secret show `
            --vault-name $KeyVaultName `
            --name $name `
            --query "value" `
            -o tsv

        if (-not $value) {
            continue
        }

        az keyvault secret set `
            --vault-name $KeyVaultName `
            --name $name `
            --value $value `
            --expires $newExpiry | Out-Null

        Write-Host "Updated $name"
    }

    Write-Host "Secret expiry update completed successfully."
}
#Update-KeyVaultSecretExpiry -KeyVaultName "my-keyvault"

function Set-VariableGroupSasToken {
    param(
        [string]$StorageAccountName,
        [string]$ResourceGroupName,
        [string]$ProjectUrl,
        [string]$VariableGroupId,
        [string]$PatToken,
        [string]$VariableName = "R3_SAS_TOKEN",
        [int]$ExpiryHours = 8760
    )

    $ErrorActionPreference = "Stop"

    Write-Host "Generating SAS token for storage account: $StorageAccountName"

    # Expiry
    $expiry = (Get-Date).ToUniversalTime().AddHours($ExpiryHours).ToString("yyyy-MM-ddTHH:mmZ")

    Write-Host "Expiry UTC: $expiry"

    # Get Storage Account Key
    $key = az storage account keys list `
        --account-name $StorageAccountName `
        --resource-group $ResourceGroupName `
        --query "[0].value" -o tsv

    if (-not $key) {
        throw "Failed to retrieve storage account key."
    }

    # Generate Account SAS
    $sas = az storage account generate-sas `
        --permissions rwdlacup `
        --services bqtf `
        --resource-types sco `
        --expiry $expiry `
        --account-name $StorageAccountName `
        --account-key $key `
        -o tsv

    if ([string]::IsNullOrWhiteSpace($sas)) {
        throw "Failed to generate SAS token."
    }

    Write-Host "SAS token generated successfully."

    # REST API URL
    $vgUrl = "$ProjectUrl/_apis/distributedtask/variablegroups/$VariableGroupId?api-version=7.1-preview.2"

    # PAT Auth
    $base64AuthInfo = [Convert]::ToBase64String(
        [Text.Encoding]::ASCII.GetBytes(":$PatToken")
    )

    $headers = @{
        Authorization = "Basic $base64AuthInfo"
        "Content-Type" = "application/json"
    }

    # Get existing variable group
    Write-Host "Fetching existing variable group..."

    $existingGroup = Invoke-RestMethod `
        -Uri $vgUrl `
        -Method GET `
        -Headers $headers

    # Add/update variable
    $existingGroup.variables.$VariableName = @{
        value    = $sas
        isSecret = $false
    }

    # Build request body
    $body = @{
        id            = $existingGroup.id
        type          = $existingGroup.type
        name          = $existingGroup.name
        description   = $existingGroup.description
        variables     = $existingGroup.variables
        variableGroupProjectReferences = $existingGroup.variableGroupProjectReferences
    } | ConvertTo-Json -Depth 20

    Write-Host "Updating variable group..."

    # Update variable group
    Invoke-RestMethod `
        -Uri $vgUrl `
        -Method PUT `
        -Headers $headers `
        -Body $body

    Write-Host "Variable group updated successfully."
    Write-Host "Stored variable: $VariableName"
    Write-Host ("SAS generated (***" + $sas.Substring([Math]::Max(0,$sas.Length-6)) + ")")
}

Export-ModuleMember -Function `
    Grant-StorageBlobDataContributorRole, `
    Test-AdlsDnsResolution, `
    New-AdlsDirectories, `
    Set-AdlsLeadPermissions, `
    Update-KeyVaultSecretExpiry,`
    Set-VariableGroupSasToken