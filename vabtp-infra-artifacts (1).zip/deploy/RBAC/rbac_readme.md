# RBAC Role Assignments — ARM Template

This template deploys all Azure RBAC role assignments for the VA-BTP platform resources.  
It is designed to be deployed **after** the main infrastructure template, since it depends on resources (WebApp, FuncApp, ACR, ADLS, etc.) already existing.

---

## Files

| File | Purpose |
|------|---------|
| `rbac_arm_template.json` | ARM template — all role assignments |
| `rbac_arm_parameters.json` | Parameters file — fill this before deploying |
| `README.md` | This file |

---


## What This Template Deploys

### ACR Pull — Container Image Access

| Principal | Role | Scope |
|-----------|------|-------|
| WebApp System-Assigned MSI | AcrPull | Azure Container Registry |
| FuncApp System-Assigned MSI | AcrPull | Azure Container Registry |

> Required because both apps use `acrUseManagedIdentityCreds: true`. Without this, apps fail to start with a 401 error on image pull.

---

### rbacPrincipalId — Platform / Ops Identity

> **Note:** `rbacPrincipalId` is intentionally generic. It could be a pipeline SP, a platform ops identity, or a UAMI depending on your org. Confirm what this identity is before deploying.

| Role | Scope |
|------|-------|
| App Service Contributor | WebApp |
| App Service Contributor | FuncApp |
| Monitoring Contributor | WebApp |
| Monitoring Contributor | FuncApp |
| Application Insights Component Contributor | App Insights (Web) |
| Application Insights Component Contributor | App Insights (Func) |
| Log Analytics Contributor | Log Analytics Workspace |
| Storage Queue Data Contributor | Blob Storage Account |
| Key Vault Secrets User | Key Vault |

---

### ADLS Service Principal — adlsfolderprincipalId

| Role | Scope |
|------|-------|
| Storage Blob Data Contributor | ADLS Gen2 Storage Account |

---

### AAD Groups — ADLS Data Access

| Group | Role | Scope |
|-------|------|-------|
| P66-CG-DEV-VA-BTP | Storage Blob Data Contributor | ADLS Gen2 |
| P66-CG-DEV-VA-BTP | Storage Blob Data Reader | ADLS Gen2 |
| P66_VABTP_CG_LEAD | Storage Blob Data Contributor | ADLS Gen2 |
| P66_VABTP_CG_LEAD_QA | Storage Blob Data Contributor | ADLS Gen2 |

---

## How to Fill the Parameters File

### Step 1 — Resource Names
These are straightforward — just the names of the already-deployed resources.

```bash
# Verify resources exist before deploying RBAC
az webapp show --name <webAppName> --resource-group <rg> --query name -o tsv
az functionapp show --name <funcAppName> --resource-group <rg> --query name -o tsv
az acr show --name <acrName> --resource-group <rg> --query name -o tsv
```

---

### Step 2 — WebApp & FuncApp Principal IDs (SAMI)

These are the Object IDs of the System-Assigned Managed Identities created by the main deployment.

**Option A — From deployment outputs (recommended):**
```bash
az deployment group show \
  --resource-group <rg> \
  --name <main-deployment-name> \
  --query "properties.outputs"
```

**Option B — Directly from the resource:**
```bash
# WebApp principal ID
az webapp show --name <webAppName> --resource-group <rg> --query identity.principalId -o tsv

# FuncApp principal ID
az functionapp show --name <funcAppName> --resource-group <rg> --query identity.principalId -o tsv
```

---

### Step 3 — rbacPrincipalId

Confirm with your team what identity this is, then get its Object ID.

**If it is a Service Principal (by App/Client ID):**
```bash
az ad sp show --id <app-id> --query id -o tsv
```

**If it is a Service Principal (by display name):**
```bash
az ad sp list --display-name "<sp-display-name>" --query "[0].id" -o tsv
```

**If it is a User-Assigned Managed Identity:**
```bash
az identity show --name <uami-name> --resource-group <rg> --query principalId -o tsv
```

---

### Step 4 — ADLS Service Principal (adlsfolderprincipalId)

```bash
# By App/Client ID
az ad sp show --id <app-id> --query id -o tsv

# By display name
az ad sp list --display-name "<sp-name>" --query "[0].id" -o tsv
```

---

### Step 5 — AAD Group Object IDs

```bash
# P66-CG-DEV-VA-BTP
az ad group show --group "P66-CG-DEV-VA-BTP" --query id -o tsv

# P66_VABTP_CG_LEAD
az ad group show --group "P66_VABTP_CG_LEAD" --query id -o tsv

# P66_VABTP_CG_LEAD_QA
az ad group show --group "P66_VABTP_CG_LEAD_QA" --query id -o tsv
```

**If the exact name doesn't work, search by partial name:**
```bash
az ad group list --display-name "P66" --query "[].{name:displayName, id:id}" -o table
```

---

## Deploy

```bash
az deployment group create --resource-group <rg> --template-file rbac-assignments.json --parameters @rbac-assignments.parameters.json
```

**Dry run first (validate without deploying):**
```bash
az deployment group validate --resource-group <rg> --template-file rbac-assignments.json --parameters @rbac-assignments.parameters.json
```

**What-if (see changes before applying):**
```bash
az deployment group what-if --resource-group <rg> --template-file rbac-assignments.json --parameters @rbac-assignments.parameters.json
```

---

## Verify After Deployment

```bash
# Check all role assignments on the ADLS account
az role assignment list --scope <adls-resource-id> --output table

# Check role assignments on the ACR
az role assignment list --scope <acr-resource-id> --output table

# Check role assignments on the Key Vault
az role assignment list --scope <kv-resource-id> --output table
```

---

## Notes

- Role assignment names use `guid(scope, principalId, roleId)` — this is deterministic, so re-deploying the template will not create duplicate assignments.
- All assignments are scoped to individual resources (not subscription or resource group level) — following least-privilege principle.
- This template does **not** create any resources — only role assignments on existing resources.
