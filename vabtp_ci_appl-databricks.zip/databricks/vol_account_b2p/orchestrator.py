# Databricks notebook source
# DBTITLE 1,bronze table
# MAGIC %run /Workspace/shared/vol_account_b2p/vol_account_b2p_bronze/tables/bronze_table_creation.py

# COMMAND ----------

# DBTITLE 1,silver and tables
# MAGIC %run /Workspace/shared/vol_account_b2p/vol_account_b2p_silver/tables/silver_table_creation.py

# COMMAND ----------

# MAGIC %run /Workspace/shared/vol_account_b2p/vol_account_b2p_silver/tables/gold_table_creation.py

# COMMAND ----------

# DBTITLE 1,bronze view
# MAGIC %run /Workspace/shared/vol_account_b2p/vol_account_b2p_bronze/views/bronze_view_creation.py

# COMMAND ----------

# DBTITLE 1,silver view
# MAGIC %run /Workspace/shared/vol_account_b2p/vol_account_b2p_silver/views/silver_view_creation.py

# COMMAND ----------

# DBTITLE 1,gold view
# MAGIC %run /Workspace/shared/vol_account_b2p/vol_account_b2p_silver/views/gold_view_creation.py

# COMMAND ----------

# DBTITLE 1,uc function creation
# MAGIC %run /Workspace/shared/vol_account_b2p/vol_account_b2p_silver/tables/uc_function_creation.py