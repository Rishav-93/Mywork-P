# Databricks notebook source
dbutils.widgets.text('anlc_ringname', '', 'ring3')
ring_name = dbutils.widgets.get('anlc_ringname')
CATALOG_NAME = f"vabtp_{ring_name}"
SCHEMA_NAME_BRONZE = "vol_account_b2p_bronze"
SCHEMA_NAME_SILVER = "vol_account_b2p_silver"
SCHEMA_NAME_GOLD = "vol_account_b2p"

# COMMAND ----------

spark.sql(f'''CREATE OR REPLACE VIEW {CATALOG_NAME}.{SCHEMA_NAME_BRONZE}.vw_blackline AS
SELECT
  period_nme,
  plant_ID,
  product_ID,
  product,
  approver_nme,
  reviewer_nme
FROM
  {CATALOG_NAME}.{SCHEMA_NAME_BRONZE}.blackline''')