# Databricks notebook source
dbutils.widgets.text('anlc_ringname', "", 'ring3')
ring_name = dbutils.widgets.get('anlc_ringname')
CATALOG_NAME = f"vabtp_{ring_name}"
SCHEMA_NAME_BRONZE = "vol_account_b2p_bronze"
SCHEMA_NAME_SILVER = "vol_account_b2p_silver"
SCHEMA_NAME_GOLD = "vol_account_b2p"

# COMMAND ----------

spark.sql(f'''
          CREATE OR REPLACE VIEW {CATALOG_NAME}.{SCHEMA_NAME_SILVER}.vw_recon_run_status_latest  AS
WITH blackline_periods  AS (
  SELECT DISTINCT 
    plant_ID,
    CAST(DATE_FORMAT(period_nme, 'MMyy') AS INT) AS period_mmyy
  FROM {CATALOG_NAME}.{SCHEMA_NAME_BRONZE}.blackline
),
ranked_recon AS (
  SELECT 
    r.*,
    ROW_NUMBER() OVER (PARTITION BY r.plant_id, r.Month_of_recon ORDER BY r.created_at DESC) AS rn
  FROM {CATALOG_NAME}.{SCHEMA_NAME_SILVER}.recon_run_status r
  INNER JOIN blackline_periods b
    ON r.plant_id = b.plant_ID
    AND r.Month_of_recon = b.period_mmyy
)
SELECT 
  run_id,
  trigger_id,
  batch_number,
  plant_id,

  -- Format Month_of_recon (e.g., 1025 -> Oct,2025)
  DATE_FORMAT(
    TO_DATE(
      CONCAT(
        '20',
        LPAD(CAST(Month_of_recon % 100 AS STRING), 2, '0'),     -- YY -> 20YY
        LPAD(CAST(FLOOR(Month_of_recon / 100) AS STRING), 2, '0'), -- MM
        '01'
      ),
      'yyyyMMdd'
    ),
    'MMM,yyyy'
  ) AS Month_of_recon,

  -- (Optional: keep the old computed name as "movement" if you still want it)
  DATE_FORMAT(
    TO_DATE(
      CONCAT(
        '20',
        LPAD(CAST(Month_of_recon % 100 AS STRING), 2, '0'),
        LPAD(CAST(FLOOR(Month_of_recon / 100) AS STRING), 2, '0'),
        '01'
      ),
      'yyyyMMdd'
    ),
    'MMM, yyyy'
  ) AS movement,

  precheck_status,
  ingest_status,
  prep_status,
  recon_status,
  export_status,
  review_status,
  precheck_start_ts,
  ingest_start_ts,
  prep_start_ts,
  recon_start_ts,
  export_start_ts,
  review_start_ts,
  precheck_end_ts,
  ingest_end_ts,
  prep_end_ts,
  recon_end_ts,
  export_end_ts,
  review_end_ts,
  url,
  error_message,
  created_at,
  updated_at
FROM ranked_recon
WHERE rn = 1;
''')

# COMMAND ----------

spark.sql(f'''
CREATE OR REPLACE VIEW {CATALOG_NAME}.{SCHEMA_NAME_SILVER}.vw_tor_summary AS
WITH base AS (
  SELECT
    Plant_ID,
    Month_date,
    FacilityCode,
    FacilityName,
    ShipperCode,
    ShipperName,
    ProductCode,
    ProductName,
    OpenInventory,
    PLReceipt,
    OtherReceipt,
    TransferIn,
    TransferOut,
    Rack,
    PLShipment,
    OtherShipment,
    RebrandIn,
    RebrandOut,
    ClosingInventory,
    GainLoss,
    ReportingStatus,
    KickoutsPending,
    LGDelivery,
    LGReceipts,
    Percentage,
    IT_OT,

    -- Normalize Month_date to a 4-char string like 'MMYY'
    LPAD(CAST(Month_date AS STRING), 4, '0') AS md4
  FROM {CATALOG_NAME}.{SCHEMA_NAME_SILVER}.tor_summary
)
SELECT
  Plant_ID,
  Month_date,
  FacilityCode,
  FacilityName,
  ShipperCode,
  ShipperName,
  ProductCode,
  ProductName,
  OpenInventory,
  PLReceipt,
  OtherReceipt,
  TransferIn,
  TransferOut,
  Rack,
  PLShipment,
  OtherShipment,
  RebrandIn,
  RebrandOut,
  ClosingInventory,
  GainLoss,
  ReportingStatus,
  KickoutsPending,
  LGDelivery,
  LGReceipts,
  Percentage,
  IT_OT,

  -- Convert MMYY -> date (YYYY-MM-01) -> 'MMM,yyyy'
  date_format(
    to_date(
      concat('20', substr(md4, 3, 2), '-', substr(md4, 1, 2), '-01')
    ),
    'MMM,yyyy'
  ) AS `Month`
FROM base; ''')

# COMMAND ----------

spark.sql(f'''
CREATE OR REPLACE VIEW {CATALOG_NAME}.{SCHEMA_NAME_SILVER}.vw_tor_control_check as
WITH base AS (
    SELECT
        Plant_id,
        month_date,
        Product_Code_Row_Labels,
        TOR_Sum_of_Receipt,
        TOR_Sum_of_Deliveries,
        Transaction_Sum_of_Receipts,
        Transaction_Sum_of_Deliveries,
        Variance_Receipt,
        Variance_Delivery,


        -- Normalize month_date to 4-digit MMYY
        LPAD(CAST(month_date AS STRING), 4, '0') AS md4
    FROM {CATALOG_NAME}.{SCHEMA_NAME_SILVER}.tor_control_check
)
SELECT
    b.Plant_id,
    b.month_date,
    b.Product_Code_Row_Labels,
    b.TOR_Sum_of_Receipt,
    b.TOR_Sum_of_Deliveries,
    b.Transaction_Sum_of_Receipts,
    b.Transaction_Sum_of_Deliveries,
   b.Variance_Receipt,
    b.Variance_Delivery,
    -- Apply the same MMYY → date → 'MMM,yyyy' logic
    date_format(
        to_date(
            concat(
                '20', substr(b.md4, 3, 2),   -- YY
                '-', substr(b.md4, 1, 2),    -- MM
                '-01'
            )
        ),
        'MMM,yyyy'
    ) AS Month,

    p.SAP_Product_Name AS Product_Name
FROM base b
LEFT JOIN {CATALOG_NAME}.{SCHEMA_NAME_BRONZE}.index_product p
    ON b.Product_Code_Row_Labels = p.Product_Code
''')