# Databricks notebook source
dbutils.widgets.text('anlc_ringname', '', 'ring3')
ring_name = dbutils.widgets.get('anlc_ringname')
CATALOG_NAME = f"vabtp_{ring_name}"
SCHEMA_NAME_BRONZE = "vol_account_b2p_bronze"
SCHEMA_NAME_SILVER = "vol_account_b2p_silver"
SCHEMA_NAME_GOLD = "vol_account_b2p"

# COMMAND ----------

spark.sql(f'''
CREATE OR REPLACE VIEW {CATALOG_NAME}.{SCHEMA_NAME_GOLD}.vw_recon_summary_org AS
WITH base AS (
  SELECT
    ro.*,
    COALESCE(ro.TT_Product, ro.sap_Product) AS derived_product
  FROM
    {CATALOG_NAME}.{SCHEMA_NAME_GOLD}.recon_output ro
),
-- Deduplicate blackline per PRODUCT so join becomes 1-to-1
bl_dedup AS (
  SELECT
    *
  FROM
    (
      SELECT
        bl.*,
        ROW_NUMBER() OVER (PARTITION BY UPPER(TRIM(bl.product)) ORDER BY bl.period_nme DESC) AS rn -- you can choose any rule here
      FROM
        {CATALOG_NAME}.{SCHEMA_NAME_BRONZE}.blackline bl
    ) t
  WHERE
    rn = 1
)
SELECT
  bl.plant_ID,
  bl.product_ID,
  bl.product,
  date_format(
    COALESCE(TRY_TO_DATE(bl.period_nme, 'yyyy-M-d'), TRY_TO_DATE(bl.period_nme, 'yyyy-MM-dd')),
    'MMM,yyyy'
  ) AS MonthOfReconcilition,
  -- Recon output fields
  base.TT_Plant_ID,
  base.TT_Month_date,
  base.TT_BOL_Number,
  base.TT_Movement_Date,
  base.TT_MovementType,
  base.TT_Product,
  base.TT_Receipt_Delivery,
  base.TT_Inventory_Qty,
  base.sap_Plant_ID,
  base.sap_Month_date,
  base.sap_BOL_Number,
  base.sap_Movement_Date,
  base.sap_MovementType,
  base.sap_Product,
  base.sap_Receipt_Delivery,
  base.sap_Inventory_Qty,
  base.variance,
  base.Reconciliation_Status AS Status,
    base.MatchingCriteria AS Rule_Used,
  rr2.Rule_Conditions AS `Rule Defination`
FROM
  base
    LEFT JOIN bl_dedup bl
      ON TRIM(UPPER(bl.product)) = TRIM(UPPER(base.derived_product))
    LEFT JOIN (SELECT
    rule_id,
    Rule_Conditions
FROM
    (
        SELECT
            EXPLODE(
                FROM_JSON(rule_conditions, 'MAP<STRING, STRING>')
            ) AS (rule_id, Rule_Conditions)
        FROM
           {CATALOG_NAME}.{SCHEMA_NAME_SILVER}.rule_registry_final
    )) rr2
    ON rr2.rule_id = base.MatchingCriteria;
     ''')
 

# COMMAND ----------

spark.sql(f'''
CREATE OR REPLACE VIEW {CATALOG_NAME}.{SCHEMA_NAME_GOLD}.vw_mlflow_all_runs  AS
Select
  *
FROM
  {CATALOG_NAME}.{SCHEMA_NAME_GOLD}.mlflow_all_runs 
 ''')