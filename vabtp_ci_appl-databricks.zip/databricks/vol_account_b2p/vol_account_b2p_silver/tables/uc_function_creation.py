# Databricks notebook source
ring_name = dbutils.widgets.get('anlc_ringname')
CATALOG_NAME = f"vabtp_{ring_name}"
SCHEMA_NAME_BRONZE = "vol_account_b2p_bronze"
SCHEMA_NAME_SILVER = "vol_account_b2p_silver"
SCHEMA_NAME_GOLD = "vol_account_b2p"

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE FUNCTION shared_datalake_ring3.vol_account_b2p_silver.get_execution_context(
# MAGIC   params STRING COMMENT 'JSON string with key input_dict containing reconciliation parameters'
# MAGIC )
# MAGIC RETURNS STRING
# MAGIC COMMENT 'Initializes execution context for reconciliation runs. Returns JSON with parent_run_id and status.'
# MAGIC LANGUAGE SQL
# MAGIC RETURN (
# MAGIC   WITH
# MAGIC   -- Parse input parameters
# MAGIC   parsed_params AS (
# MAGIC     SELECT
# MAGIC       TRY_PARSE_JSON(params) AS params_json
# MAGIC   ),
# MAGIC   
# MAGIC   -- Extract input_dict
# MAGIC   input_dict AS (
# MAGIC     SELECT
# MAGIC       CASE 
# MAGIC         WHEN params_json IS NULL THEN NULL
# MAGIC         ELSE TRY_PARSE_JSON(GET_JSON_OBJECT(params, '$.input_dict'))
# MAGIC       END AS input_dict_json
# MAGIC     FROM parsed_params
# MAGIC   ),
# MAGIC   
# MAGIC   -- Extract individual fields
# MAGIC   extracted_fields AS (
# MAGIC     SELECT
# MAGIC       COALESCE(CAST(input_dict_json:recon_type AS STRING), '') AS recon_type,
# MAGIC       COALESCE(CAST(input_dict_json:trigger_type AS STRING), '') AS trigger_type,
# MAGIC       CAST(input_dict_json:requested_by AS STRING) AS requested_by,
# MAGIC       CAST(input_dict_json:trigger_id AS STRING) AS trigger_id,
# MAGIC       CAST(input_dict_json:request_type AS STRING) AS request_type,
# MAGIC       CAST(input_dict_json:plant_id AS STRING) AS plant_id,
# MAGIC       CAST(input_dict_json:month_of_recon AS STRING) AS month_of_reconcilation
# MAGIC     FROM input_dict
# MAGIC   ),
# MAGIC   
# MAGIC   -- Validate required fields
# MAGIC   validation AS (
# MAGIC     SELECT
# MAGIC       *,
# MAGIC       CASE
# MAGIC         WHEN (SELECT params_json FROM parsed_params) IS NULL 
# MAGIC           THEN 'fail - Failed to parse params as JSON'
# MAGIC         WHEN (SELECT input_dict_json FROM input_dict) IS NULL 
# MAGIC           THEN 'fail - input_dict is empty or invalid'
# MAGIC         WHEN requested_by IS NULL OR trigger_id IS NULL OR request_type IS NULL 
# MAGIC           THEN 'fail - Missing required fields'
# MAGIC         WHEN request_type != 'batch' AND (plant_id IS NULL OR month_of_reconcilation IS NULL)
# MAGIC           THEN 'fail - Rerun requires plant_id and Month_of_reconcilation'
# MAGIC         ELSE NULL
# MAGIC       END AS error_status
# MAGIC     FROM extracted_fields
# MAGIC   ),
# MAGIC   
# MAGIC   -- Constants
# MAGIC   cfg AS (
# MAGIC     SELECT
# MAGIC       'shared_datalake_ring3' AS catalog_name,
# MAGIC       'vol_account_b2p_silver' AS schema_name,
# MAGIC       'recon_run_status' AS recon_status_name,
# MAGIC       'execution_context_table' AS exec_context_table
# MAGIC   ),
# MAGIC   
# MAGIC   -- For rerun: lookup parent_run_id
# MAGIC   parent_lookup AS (
# MAGIC     SELECT
# MAGIC       v.request_type,
# MAGIC       v.error_status,
# MAGIC       CASE
# MAGIC         WHEN v.error_status IS NOT NULL THEN NULL
# MAGIC         WHEN v.request_type = 'batch' THEN ''
# MAGIC         ELSE (
# MAGIC           SELECT run_id
# MAGIC           FROM shared_datalake_ring3.vol_account_b2p_silver.recon_run_status
# MAGIC           WHERE plant_id = v.plant_id
# MAGIC             AND Month_of_recon = v.month_of_reconcilation
# MAGIC           LIMIT 1
# MAGIC         )
# MAGIC       END AS parent_run_id,
# MAGIC       v.recon_type,
# MAGIC       v.trigger_type,
# MAGIC       v.requested_by,
# MAGIC       v.trigger_id
# MAGIC     FROM validation v
# MAGIC   ),
# MAGIC   
# MAGIC   -- Final status determination
# MAGIC   final_status AS (
# MAGIC     SELECT
# MAGIC       COALESCE(parent_run_id, '') AS parent_run_id,
# MAGIC       CASE
# MAGIC         WHEN error_status IS NOT NULL THEN error_status
# MAGIC         WHEN request_type != 'batch' AND parent_run_id IS NULL 
# MAGIC           THEN 'fail - No parent_id found for given plant_id and month'
# MAGIC         ELSE 'success'
# MAGIC       END AS status,
# MAGIC       request_type,
# MAGIC       recon_type,
# MAGIC       trigger_type,
# MAGIC       requested_by,
# MAGIC       trigger_id
# MAGIC     FROM parent_lookup
# MAGIC   )
# MAGIC   
# MAGIC   -- Return JSON result
# MAGIC   SELECT TO_JSON(NAMED_STRUCT(
# MAGIC     'parent_run_id', parent_run_id,
# MAGIC     'status', status
# MAGIC   ))
# MAGIC   FROM final_status
# MAGIC );

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE FUNCTION shared_datalake_ring3.vol_account_b2p_silver.validate_prerequisites(params STRING)
# MAGIC RETURNS STRING
# MAGIC LANGUAGE SQL
# MAGIC COMMENT 'Validates prerequisites for reconciliation pipeline. Returns JSON with Success_or_Failure, plant_list, period_list, product_list, completed_plant_list, completed_period_list.'
# MAGIC RETURN
# MAGIC   CASE
# MAGIC     -- Check if blackline table exists
# MAGIC     WHEN NOT EXISTS (
# MAGIC       SELECT 1
# MAGIC       FROM shared_datalake_ring3.information_schema.tables
# MAGIC       WHERE table_schema = 'vol_account_b2p_bronze'
# MAGIC         AND table_name = 'blackline'
# MAGIC     ) THEN
# MAGIC       to_json(named_struct(
# MAGIC         'Success_or_Failure', array('Failed'),
# MAGIC         'plant_list', array(),
# MAGIC         'period_list', array(),
# MAGIC         'product_list', array(),
# MAGIC         'completed_plant_list', array(),
# MAGIC         'completed_period_list', array()
# MAGIC       ))
# MAGIC     
# MAGIC     -- Check if blackline table is empty
# MAGIC     WHEN NOT EXISTS (
# MAGIC       SELECT 1 
# MAGIC       FROM shared_datalake_ring3.vol_account_b2p_bronze.blackline 
# MAGIC       LIMIT 1
# MAGIC     ) THEN
# MAGIC       to_json(named_struct(
# MAGIC         'Success_or_Failure', array('Failed'),
# MAGIC         'plant_list', array(),
# MAGIC         'period_list', array(),
# MAGIC         'product_list', array(),
# MAGIC         'completed_plant_list', array(),
# MAGIC         'completed_period_list', array()
# MAGIC       ))
# MAGIC     
# MAGIC     -- Handle BATCH request type
# MAGIC     WHEN lower(trim(get_json_object(params, '$.input_dict.request_type'))) = 'batch' THEN (
# MAGIC       WITH 
# MAGIC       -- Use run_date from input params (MMYY as string or int)
# MAGIC       run_date_param AS (
# MAGIC         SELECT trim(get_json_object(params, '$.input_dict.run_date')) AS run_date
# MAGIC       ),
# MAGIC       
# MAGIC       -- Get plant-period-product combinations for the run_date
# MAGIC       batch_data AS (
# MAGIC         SELECT
# MAGIC           bl.plant_ID,
# MAGIC           CAST(CONCAT(
# MAGIC             date_format(bl.period_nme, 'M'),
# MAGIC             date_format(bl.period_nme, 'yy')
# MAGIC           ) AS STRING) AS period_code,
# MAGIC           collect_list(bl.product) AS product_list
# MAGIC         FROM shared_datalake_ring3.vol_account_b2p_bronze.blackline bl
# MAGIC         CROSS JOIN run_date_param rdp
# MAGIC         WHERE CAST(CONCAT(
# MAGIC           date_format(bl.period_nme, 'M'),
# MAGIC           date_format(bl.period_nme, 'yy')
# MAGIC         ) AS STRING) = rdp.run_date
# MAGIC         GROUP BY bl.plant_ID, CAST(CONCAT(
# MAGIC           date_format(bl.period_nme, 'M'),
# MAGIC           date_format(bl.period_nme, 'yy')
# MAGIC         ) AS STRING)
# MAGIC       ),
# MAGIC       
# MAGIC       -- Get already completed plant-period combinations
# MAGIC       recon_processed AS (
# MAGIC         SELECT DISTINCT
# MAGIC           rrs.plant_id AS plant_ID,
# MAGIC           CAST(rrs.Month_of_recon AS STRING) AS period_code
# MAGIC         FROM shared_datalake_ring3.vol_account_b2p_silver.recon_run_status rrs
# MAGIC         WHERE rrs.precheck_status = 'Success'
# MAGIC           AND EXISTS (
# MAGIC             SELECT 1
# MAGIC             FROM shared_datalake_ring3.information_schema.tables
# MAGIC             WHERE table_schema = 'vol_account_b2p_silver'
# MAGIC               AND table_name = 'recon_run_status'
# MAGIC           )
# MAGIC       ),
# MAGIC       
# MAGIC       -- Split into pending and completed
# MAGIC       pending_data AS (
# MAGIC         SELECT
# MAGIC           bd.plant_ID,
# MAGIC           bd.period_code,
# MAGIC           bd.product_list
# MAGIC         FROM batch_data bd
# MAGIC         LEFT JOIN recon_processed rp
# MAGIC           ON bd.plant_ID = rp.plant_ID
# MAGIC           AND bd.period_code = rp.period_code
# MAGIC         WHERE rp.plant_ID IS NULL
# MAGIC       ),
# MAGIC       
# MAGIC       completed_data AS (
# MAGIC         SELECT
# MAGIC           bd.plant_ID,
# MAGIC           bd.period_code
# MAGIC         FROM batch_data bd
# MAGIC         INNER JOIN recon_processed rp
# MAGIC           ON bd.plant_ID = rp.plant_ID
# MAGIC           AND bd.period_code = rp.period_code
# MAGIC       )
# MAGIC       
# MAGIC       SELECT to_json(named_struct(
# MAGIC         'Success_or_Failure', array('Success'),
# MAGIC         'plant_list', COALESCE((SELECT collect_list(plant_ID) FROM pending_data), array()),
# MAGIC         'period_list', COALESCE((SELECT collect_list(period_code) FROM pending_data), array()),
# MAGIC         'product_list', COALESCE((SELECT collect_list(concat_ws(',', product_list)) FROM pending_data), array()),
# MAGIC         'completed_plant_list', COALESCE((SELECT collect_list(plant_ID) FROM completed_data), array()),
# MAGIC         'completed_period_list', COALESCE((SELECT collect_list(period_code) FROM completed_data), array())
# MAGIC       ))
# MAGIC     )
# MAGIC     
# MAGIC     -- Handle RERUN request type
# MAGIC     WHEN lower(trim(get_json_object(params, '$.input_dict.request_type'))) = 'rerun' THEN (
# MAGIC       WITH rerun_data AS (
# MAGIC         SELECT
# MAGIC           bl.plant_ID,
# MAGIC           CAST(CONCAT(
# MAGIC             date_format(bl.period_nme, 'M'),
# MAGIC             date_format(bl.period_nme, 'yy')
# MAGIC           ) AS STRING) AS period_code,
# MAGIC           collect_list(bl.product) AS product_list
# MAGIC         FROM shared_datalake_ring3.vol_account_b2p_bronze.blackline bl
# MAGIC         WHERE bl.plant_ID = get_json_object(params, '$.input_dict.plant_id')
# MAGIC           AND upper(CAST(CONCAT(
# MAGIC             date_format(bl.period_nme, 'MM'),
# MAGIC             date_format(bl.period_nme, 'yy')
# MAGIC           ) AS STRING)) = upper(trim(get_json_object(params, '$.input_dict.month_of_recon')))
# MAGIC         GROUP BY bl.plant_ID, CAST(CONCAT(
# MAGIC           date_format(bl.period_nme, 'M'),
# MAGIC           date_format(bl.period_nme, 'yy')
# MAGIC         ) AS STRING)
# MAGIC       )
# MAGIC       
# MAGIC       SELECT 
# MAGIC         CASE
# MAGIC           WHEN (SELECT COUNT(*) FROM rerun_data) = 0 THEN
# MAGIC             to_json(named_struct(
# MAGIC               'Success_or_Failure', array('Failed'),
# MAGIC               'plant_list', array(),
# MAGIC               'period_list', array(),
# MAGIC               'product_list', array(),
# MAGIC               'completed_plant_list', array(),
# MAGIC               'completed_period_list', array()
# MAGIC             ))
# MAGIC           ELSE
# MAGIC             to_json(named_struct(
# MAGIC               'Success_or_Failure', array('Success'),
# MAGIC               'plant_list', (SELECT collect_list(plant_ID) FROM rerun_data),
# MAGIC               'period_list', (SELECT collect_list(period_code) FROM rerun_data),
# MAGIC               'product_list', (SELECT collect_list(concat_ws(',', product_list)) FROM rerun_data)
# MAGIC             ))
# MAGIC         END
# MAGIC     )
# MAGIC     
# MAGIC     -- Invalid or missing request_type
# MAGIC     ELSE
# MAGIC       to_json(named_struct(
# MAGIC         'Success_or_Failure', array('Failed'),
# MAGIC         'plant_list', array(),
# MAGIC         'period_list', array(),
# MAGIC         'product_list', array(),
# MAGIC         'completed_plant_list', array(),
# MAGIC         'completed_period_list', array()
# MAGIC       ))
# MAGIC   END

# COMMAND ----------

# MAGIC %sql
# MAGIC CREATE OR REPLACE FUNCTION shared_datalake_ring3.vol_account_b2p_silver.invoke_rule_selector(params STRING)
# MAGIC RETURNS STRING
# MAGIC LANGUAGE SQL
# MAGIC COMMENT 'Returns a JSON payload describing the latest rule versions and hierarchy for the specified request_type. Supports "batch", "rerun", "exception_run", and "rules_update" types. Used by the AI agent to select rule sets for reconciliation workflows in Unity Catalog.'
# MAGIC RETURN
# MAGIC WITH
# MAGIC -- Parse request_type (case-insensitive) from the single JSON arg
# MAGIC arg AS (
# MAGIC   SELECT lower(trim(get_json_object(params, '$.request_type'))) AS request_type
# MAGIC ),
# MAGIC
# MAGIC -- Active latest versions per rule_id from rule_versions
# MAGIC rv_ranked AS (
# MAGIC   SELECT
# MAGIC     rule_id,
# MAGIC     CAST(rule_version   AS INT) AS rule_version,
# MAGIC     CAST(registry_version AS INT) AS registry_version,
# MAGIC     rule_status,
# MAGIC     date_removed_ts,
# MAGIC     ROW_NUMBER() OVER (PARTITION BY rule_id ORDER BY CAST(registry_version AS INT) DESC, CAST(rule_version AS INT) DESC) AS rn
# MAGIC   FROM shared_datalake_ring3.vol_account_b2p_silver.rule_versions
# MAGIC   WHERE upper(rule_status) = 'ACTIVE' AND date_removed_ts IS NULL
# MAGIC ),
# MAGIC rv_latest AS (
# MAGIC   SELECT rule_id, rule_version
# MAGIC   FROM rv_ranked
# MAGIC   WHERE rn = 1
# MAGIC ),
# MAGIC
# MAGIC -- Split into PREP and RECON rule maps (rule_id prefix)
# MAGIC prep_rules AS (
# MAGIC   SELECT map_from_entries(collect_list(named_struct('key', rule_id, 'value', rule_version))) AS m
# MAGIC   FROM rv_latest
# MAGIC   WHERE substr(rule_id, 1, 1) = 'P'
# MAGIC ),
# MAGIC recon_rules AS (
# MAGIC   SELECT map_from_entries(collect_list(named_struct('key', rule_id, 'value', rule_version))) AS m
# MAGIC   FROM rv_latest
# MAGIC   WHERE substr(rule_id, 1, 1) = 'R'
# MAGIC ),
# MAGIC
# MAGIC -- Build PREP hierarchy map: source -> 1
# MAGIC hier_prep AS (
# MAGIC   SELECT map_from_entries(
# MAGIC            collect_list(
# MAGIC              named_struct(
# MAGIC                'key', regexp_replace(lower(coalesce(Tranc_source, '')), '[\\s()]+', ''),
# MAGIC                'value', CAST(1 AS INT)
# MAGIC              )
# MAGIC            )
# MAGIC          ) AS m
# MAGIC   FROM shared_datalake_ring3.vol_account_b2p_silver.rule_hierarchy
# MAGIC   WHERE lower(rule_type) = 'prep'
# MAGIC ),
# MAGIC
# MAGIC -- Build RECON hierarchy: source -> (movement -> 1)
# MAGIC hier_recon_flat AS (
# MAGIC   SELECT
# MAGIC     regexp_replace(lower(coalesce(Tranc_source, '')),  '[\\s()]+', '') AS src,
# MAGIC     regexp_replace(lower(coalesce(MovementType,'all')),'[\\s()]+', '') AS mv
# MAGIC   FROM shared_datalake_ring3.vol_account_b2p_silver.rule_hierarchy
# MAGIC   WHERE lower(rule_type) = 'recon'
# MAGIC ),
# MAGIC hier_recon_by_src AS (
# MAGIC   SELECT
# MAGIC     src,
# MAGIC     map_from_entries(collect_list(named_struct('key', mv, 'value', CAST(1 AS INT)))) AS mv_map
# MAGIC   FROM hier_recon_flat
# MAGIC   GROUP BY src
# MAGIC ),
# MAGIC hier_recon AS (
# MAGIC   SELECT map_from_entries(collect_list(named_struct('key', src, 'value', mv_map))) AS m
# MAGIC   FROM hier_recon_by_src
# MAGIC ),
# MAGIC
# MAGIC -- Payloads by request_type (we keep versions as the four strings agent expects)
# MAGIC payload_batch AS (
# MAGIC   SELECT to_json(
# MAGIC            named_struct(
# MAGIC              'prep_rule_version',  'v_prep_batch',
# MAGIC              'recon_rule_version', 'v_recon_batch',
# MAGIC              'hierarchy_version',  'v_h_batch',
# MAGIC              'output_layout_id',   'layout_batch',
# MAGIC              -- optional: detailed objects for future use
# MAGIC              'v_prep_batch',       prep_rules.m,
# MAGIC              'v_recon_batch',      recon_rules.m,
# MAGIC              'v_h_batch',          named_struct('prep', hier_prep.m, 'recon', hier_recon.m)
# MAGIC            )
# MAGIC          ) AS json_payload
# MAGIC   FROM prep_rules, recon_rules, hier_prep, hier_recon
# MAGIC ),
# MAGIC payload_exception AS (
# MAGIC   SELECT to_json(
# MAGIC            named_struct(
# MAGIC              'prep_rule_version',  'v_prep_exception',
# MAGIC              'recon_rule_version', 'v_recon_exception',
# MAGIC              'hierarchy_version',  'v_h_exception',
# MAGIC              'output_layout_id',   'layout_exception'
# MAGIC            )
# MAGIC          ) AS json_payload
# MAGIC ),
# MAGIC payload_rules_update AS (
# MAGIC   SELECT to_json(
# MAGIC            named_struct(
# MAGIC              'prep_rule_version',  'v_prep_rules_update',
# MAGIC              'recon_rule_version', 'v_recon_rules_update',
# MAGIC              'hierarchy_version',  'v_h_rules_update',
# MAGIC              'output_layout_id',   'layout_rules_update'
# MAGIC            )
# MAGIC          ) AS json_payload
# MAGIC )
# MAGIC
# MAGIC SELECT
# MAGIC   CASE
# MAGIC     WHEN (SELECT request_type FROM arg) IN ('batch', 'batchrun') THEN (SELECT json_payload FROM payload_batch)
# MAGIC     WHEN (SELECT request_type FROM arg) IN ('rerun', 'exception_run') THEN (SELECT json_payload FROM payload_exception)
# MAGIC     WHEN (SELECT request_type FROM arg) =  'rules_update'         THEN (SELECT json_payload FROM payload_rules_update)
# MAGIC     ELSE to_json(named_struct('error', concat('Unsupported request_type: ', (SELECT request_type FROM arg))))
# MAGIC   END;

# COMMAND ----------

# DBTITLE 1,Install unitycatalog-ai package
# MAGIC %pip install unitycatalog-ai[databricks]

# COMMAND ----------

def invoke_rule_executor(plant_period_dict: str, run_id: str, batch_id: str) -> str:
    """
    Triggers the Databricks Data Processing Pipeline notebook and returns its execution result.
 
    This function acts as a wrapper around `dbutils.notebook.run()` and is used to
    programmatically start the Data Processing Pipeline notebook located at:
        /Workspace/Shared/Recon/CG-RECON-MOSAIC-AI-AGENT/spark/Data Processing Pipeline
 
    Parameters:
        plant_period_dict (str): A JSON-formatted string containing plant and period
                                 information required by the pipeline.
        run_id (str): A unique identifier for the current pipeline run.
        batch_id (str): Identifier representing the batch being processed.
 
    Returns:
        str: The output returned by the executed notebook. This is typically a status
             message such as "Success" or error details if the execution fails.
    """
    notebook_path = "/Workspace/Shared/Recon/CG-RECON-MOSAIC-AI-AGENT/spark/Data Processing Pipeline"
    return dbutils.notebook.run(
        notebook_path,
        3600,
        {
            "plant_period_dict": plant_period_dict,
            "run_id": run_id,
            "batch_id": batch_id
        }
    )
from unitycatalog.ai.core.base import get_uc_function_client

client = get_uc_function_client()

function_info = client.create_python_function(
    func=invoke_rule_executor,
    catalog='shared_datalake_ring3',
    schema='vol_account_b2p_silver',
    replace=True
)

# COMMAND ----------

def update_run_status() -> str:
    """
    Returns a test string.

    This function is a placeholder and currently returns the string "Testing".

    Returns:
        str: The string "Testing".
    """
    return "Testing"
    
from unitycatalog.ai.core.base import get_uc_function_client

client = get_uc_function_client()

function_info = client.create_python_function(
    func=update_run_status,
    catalog='shared_datalake_ring3',
    schema='vol_account_b2p_silver',
    replace=True
)