# Databricks notebook source
ring_name = dbutils.widgets.get('anlc_ringname')
CATALOG_NAME = f"vabtp_{ring_name}"
SCHEMA_NAME_BRONZE = "vol_account_b2p_bronze"
SCHEMA_NAME_SILVER = "vol_account_b2p_silver"
SCHEMA_NAME_GOLD = "vol_account_b2p"

# COMMAND ----------


spark.sql(f'''
          CREATE OR REPLACE TABLE {CATALOG_NAME}.{SCHEMA_NAME_GOLD}.recon_results
(
Plant_ID STRING COMMENT "Identifier for the plant location or plant code; also known as Location. Examples: 03AG, A34H, 03JM, 03AA.",
Date DATE COMMENT "Date at which reconcilation is done Example : 14/01/2025",
Month_date INT COMMENT "Month of reconciliation in MMYY format; Example 0925,1025, 1125",
BOL_Number	STRING COMMENT "Bill of Lading Number; also referred to as Ticket or Ticket Number.Example: 936328.",
Nomination_Number STRING COMMENT "Combined key of plant location, BOL, volume, and contract details; also known as Batch #, Batch Code, Batch ID; eg:  'PHY2 943PA, 'ITC-KC-AV092025, 'PHY2 944PA",
Movement_Date DATE COMMENT	"Date of Transaction Recorded in Books also known as Transaction Date, Ticket Date, Start Date, or Stop Date.
Examples:  09/03/2025, 09/04/2025, 09/05/2025",
MovementType STRING COMMENT	"Mode of transport used for product movement; also known as Trans Code, Mode of Transport, or MOT.Examples: Truck, Pipeline, In‑tank, Rail, Blend.",
Product	STRING COMMENT "Product or material name; also referred to as Product Details, Inv, or Product Code.Examples: 'CBOB REG H RVP FBW ETH 10%, 'TRANSMIX, 'AVGAS 100 LL, 'NORMAL BUTANE.",
Receipt_Delivery STRING	COMMENT "Indicates whether the product movement is a Receipt or Delivery; also known as Trans Code or Rcpt Delvr.Examples: Receipts, Delivery.",
Inventory_Qty DOUBLE COMMENT "Net volume in barrels; also known as Net BBL, Net Volume, Qty, Volume, or Received Inv Vol + Delivered Vol.Examples: 77.36, -1337, -77.36.",
Truck_Number STRING COMMENT "Truck or rail movement identifier (MOT number); also referred to as Volume in some operational contexts.Examples: PPRX171436, PPRX171314,PPRX171276, PPRX171127.",
External_Batch	STRING COMMENT "Product movement identifier for a batch; also known as Batch Code or Legacy Batch Code.Examples: 'DSSMC, 'MKMCGA, 'GSSMC.",
Is_Open_Item BOOLEAN COMMENT "Mentions whether that value is open item or not; Example : 1 or 0",
Month_open INT COMMENT "Indicates the reconciliation open item month. For example: 1225, 0925",
Close_date DATE COMMENT "Indicates the date on which the open item entry was closed. For example: 14‑01‑2025.",
Close_Month_date INT COMMENT "Indicates the month on which the open item entry was closed; Formated in MMYY; For example: 0925,1125",
Source STRING COMMENT "Indicates the third‑party source from which the information is received, such as Trac66 or T4.",
Portal	STRING COMMENT "source portal. example : T4, P66",
File_Type STRING COMMENT "Indicates how the data is received, such as via Excel file or email."
 )USING DELTA
COMMENT 'Matched transactions'

          ''')

# COMMAND ----------

                
spark.sql(f'''DROP TABLE IF EXISTS {CATALOG_NAME}.{SCHEMA_NAME_GOLD}.Recon_Output''')                


spark.sql(f'''
CREATE TABLE IF NOT EXISTS {CATALOG_NAME}.{SCHEMA_NAME_GOLD}.Recon_Output
(
TT_Plant_ID		STRING	,
TT_group_id		STRING	,
TT_row_uid      bigint, 
TT_Date		DATE	,
TT_Month_date		INT	,
TT_BOL_Number		STRING	,
TT_Nomination_Number		STRING	,
TT_Movement_Date		DATE	,
TT_MovementType		STRING	,
TT_Product		STRING	,
TT_Receipt_Delivery 		STRING	,
TT_Inventory_Qty 		DOUBLE	,
TT_Truck_Number		STRING	,
sap_Plant_ID		STRING	,
sap_group_id	string,
sap_row_uid 	bigint,
sap_Date		DATE	,
sap_Month_date		INT	,
sap_BOL_Number		STRING	,
sap_Nomination_Number		STRING	,
sap_Movement_Date		DATE	,
sap_MovementType 		STRING	,
sap_Product 		STRING	,
sap_Receipt_Delivery		STRING	,
sap_Inventory_Qty		DOUBLE	,
sap_Truck_Number		STRING	,
variance		DOUBLE	,
Is_Open_Item		BOOLEAN	,
Reconciliation_Status		STRING	,
MatchingCriteria		STRING	,
previous_month_open_item		BOOLEAN	,
previous_month_Month_open		DATE	,
previous_month_Item_Close_date		DATE	,
previous_month_Close_Month_date		DATE,
processing_month_date		INT
)USING DELTA
COMMENT 'Hold Final recon result'

''')

# COMMAND ----------

spark.sql(f'''
CREATE OR REPLACE TABLE {CATALOG_NAME}.{SCHEMA_NAME_GOLD}.recon_output_export 
  AS SELECT * FROM {CATALOG_NAME}.{SCHEMA_NAME_GOLD}.recon_output
''')

# COMMAND ----------

spark.sql(f"""
CREATE TABLE IF NOT EXISTS {CATALOG_NAME}.{SCHEMA_NAME_GOLD}.mlflow_all_runs (
    artifact_uri STRING,
    duration_ms BIGINT,
    experiment_id STRING,
    experiment_type STRING,
    run_id STRING,
    status STRING,
    user_id STRING,
    params_widget_year_of_reconcilation STRING,
    params_widget_plant STRING,
    params_widget_product_list STRING,
    params_widget_month_of_reconcilation_in_mmmyy_format STRING,
    params_widget_batch_id STRING,
    params_widget_run_id STRING,
    metrics_index_mot_distinct_txn DOUBLE,
    metrics_index_product_distinct_code DOUBLE,
    metrics_index_rec_del_distinct_txn DOUBLE,
    metrics_mapping_distinct_portals DOUBLE,
    metrics_rule_hierarchy_count DOUBLE,
    metrics_result_count DOUBLE,
    metrics_portal_count DOUBLE,
    metrics_rule_registry_count DOUBLE,
    metrics_movementtype_count DOUBLE,
    tags_product_list_count DOUBLE,
    tags_component STRING,
    tags_source STRING,
    tags_experiment_path STRING,
    tags_mlflow_databricks_webappurl STRING,
    tags_mlflow_user STRING,
    tags_mlflow_runname STRING,
    tags_system STRING,
    tags_mlflow_databricks_notebookrevisionid STRING,
    tags_mlflow_source_name STRING,
    tags_mlflow_databricks_cluster_info STRING,
    tags_mlflow_databricks_jobrunid STRING,
    tags_mlflow_databricks_jobid STRING,
    tags_mlflow_databricks_cluster_libraries STRING,
    tags_plant STRING,
    tags_mlflow_databricks_notebook_commandid STRING,
    tags_mlflow_runcolor STRING,
    tags_user STRING,
    tags_sparkdatasourceinfo STRING,
    tags_status STRING,
    tags_mlflow_databricks_notebookpath STRING,
    tags_notebook_path STRING,
    tags_job_id STRING,
    tags_job_run_id STRING,
    tags_mlflow_databricks_jobtype STRING,
    tags_mlflow_databricks_workspaceid STRING,
    tags_exit_message STRING,
    tags_mlflow_databricks_cluster_id STRING,
    tags_mlflow_databricks_notebookid STRING,
    tags_mlflow_databricks_workspaceurl STRING,
    tags_mlflow_source_type STRING,
    tags_mlflow_databricks_cluster_libraries_error STRING,
    tags_export_result STRING,
    start_time BIGINT,
    end_time BIGINT
)
USING DELTA
""")