############################################
# GenAI_config.py — Centralized configuration
# All configurable constants for the IT/OT
# LLM-Driven Pipeline. Update values here;
# no notebook cell should contain hardcoded
# paths, names, or thresholds.
############################################

# --- LLM Endpoint ---
LLM_ENDPOINT_NAME = "databricks-meta-llama-3-3-70b-instruct"

# --- Unity Catalog ---
catalogs = [row['catalog'] for row in spark.sql("SHOW CATALOGS").collect()]
for cat in ['vabtp_dev','shared_datalake_ring3', 'shared_datalake_ring2', 'shared_datalake_ring5']:
    if cat in catalogs:
        CATALOG_NAME = cat
        break
SCHEMA_NAME_BRONZE = "vol_account_b2p_bronze"
SCHEMA_NAME_GOLD = "vol_account_b2p"
SYNONYMS_TABLE_NAME = "synonyms_library"
IT_OT_MAPPING_TABLE = f"{CATALOG_NAME}.{SCHEMA_NAME_BRONZE}.IT_OT_columns_mapping"

# --- File Paths ---
BASE_WORKSPACE_PATH = "/Workspace/vabtp/Recon/CG-RECON-MOSAIC-AI-AGENT/mosaic-ai/Local-DEV/SHUBHAM_Y"
SUMMERY_UPDATED_EXCEL_PATH = f"{BASE_WORKSPACE_PATH}/IT_OT/03U7_TOR_12-25-Updated.xlsx"
IT_OT_PIPELINE_SCRIPT_PATH = f"{BASE_WORKSPACE_PATH}/IT_OT/IT_OT_calculation_pipeline.py"

# --- MLflow ---
MLFLOW_EXPERIMENT_PATH = "/vabtp/Recon/CG-RECON-MOSAIC-AI-AGENT/mosaic-ai/Local-DEV/SHUBHAM_Y/IT_OT/(Shubham)bhau_Varied_Agent_Final"

# --- Pipeline Settings ---
MAX_RETRIES = 2
