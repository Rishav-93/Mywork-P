############################################
# GenAI_config.py — Centralized configuration
# All configurable constants for the IT/OT
# LLM-Driven Pipeline. Update values here;
# no notebook cell should contain hardcoded
# paths, names, or thresholds.
############################################

# --- LLM Endpoint ---
LLM_ENDPOINT_NAME = "databricks-meta-llama-3-3-70b-instruct"

# --- Unity Catalog ---
CATALOG_NAME = "vabtp_dev"
SCHEMA_NAME_BRONZE = "vol_account_b2p_bronze"
SCHEMA_NAME_SILVER = "vol_account_b2p_silver"
SCHEMA_NAME_GOLD = "vol_account_b2p"
SYNONYMS_TABLE_NAME = "synonyms_library"
IT_OT_MAPPING_TABLE = f"{CATALOG_NAME}.{SCHEMA_NAME_BRONZE}.it_ot_column_mapping"
TOR_DATA_TABLE = f"{CATALOG_NAME}.{SCHEMA_NAME_SILVER}.tor_data"

# --- IT/OT Threshold ---
# Rows with percentage > OT_THRESHOLD are classified as OT, else IT
OT_THRESHOLD = 0.25

# --- Volume Path ---
VOLUME_BASE_PATH = f"/Volumes/{CATALOG_NAME}/dbfs_files/vabtp_dev/vabtp"

# --- File Paths ---
BASE_WORKSPACE_PATH = "/Workspace/vabtp/Recon/CG-RECON-MOSAIC-AI-AGENT/mosaic-ai/live/secondary/varied_template"
# Directory where updated summary Excel files are kept (same folder as the notebook)
SUMMERY_UPDATED_EXCEL_DIR = BASE_WORKSPACE_PATH
IT_OT_PIPELINE_SCRIPT_PATH = f"{BASE_WORKSPACE_PATH}/(live)ADLS_TOR_Data_Processing_Pipeline"

# --- MLflow ---
MLFLOW_EXPERIMENT_PATH = "/vabtp/Recon/CG-RECON-MOSAIC-AI-AGENT/mosaic-ai/live/secondary/varied_template/(Shubham)bhau_Varied_Agent_Final"

# --- Pipeline Settings ---
MAX_RETRIES = 2
