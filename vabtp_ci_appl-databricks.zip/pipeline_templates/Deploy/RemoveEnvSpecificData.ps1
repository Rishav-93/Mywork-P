param(
    [Parameter(Mandatory = $true)]
    [string]$InputPath,        # Folder with JSON artifacts
    [switch]$NormalizeNames    # Optional logical normalization (deterministic)
)

Write-Host "Cleaning all artifacts inside: $InputPath"

# ============================================================
# CLEAN NESTED (Lakeview‑aware, SAFE)
# ============================================================
# - Does NOT remove IDs blindly
# - Does NOT break datasetName / queryName references
# - Rewrites only unsafe path strings
# ============================================================

function CleanNested {
    param($node)

    if ($null -eq $node) { return $null }

    switch ($node.GetType().Name) {

        "String" {
            # Normalize user home paths safely
            if ($node -match "^/Users/[^/]+") {
                return "/Shared"
            }

            # Normalize Lakeview-internal paths ONLY (safe, non-destructive)
            $node = $node -replace "/dashboards/[A-Za-z0-9]+", "/dashboards/<ID>"
            $node = $node -replace "/datasets/[A-Za-z0-9]+", "/datasets/<ID>"

            return $node
        }

        "PSCustomObject" {
            foreach ($p in $node.PSObject.Properties.Name) {
                $node.$p = CleanNested $node.$p
            }
            return $node
        }

        "Object[]" {
            return $node | ForEach-Object { CleanNested $_ }
        }

        default { return $node }
    }
}

# ============================================================
# JOB‑SAFE CLEANER (NO recursion)
# ============================================================

function CleanJob {
    param($obj)

    if ($null -eq $obj) { return $obj }

    $removeFields = @(
        "job_id",
        "created_time",
        "creator_user_name",
        "run_as_user_name",
        "run_as_owner",
        "effective_budget_policy_id",
        "effective_usage_policy_id",
        "existing_cluster_id",
        "new_cluster",
        "environment",
        "environment_key",
        "job_cluster_key"
    )

    # ✅ Remove properties safely
    foreach ($rf in $removeFields) {
        if ($obj.PSObject.Properties.Match($rf)) {
            $obj.PSObject.Properties.Remove($rf)
        }
    }

    # ✅ SAFE recursion
    foreach ($prop in @($obj.PSObject.Properties)) {

        $value = $prop.Value

        # ✅ If array
        if ($value -is [object[]]) {
            for ($i = 0; $i -lt $value.Count; $i++) {
                if ($value[$i] -is [psobject]) {
                    $value[$i] = CleanJob $value[$i]
                }
            }
            $obj.$($prop.Name) = $value
        }
        # ✅ If nested object
        elseif ($value -is [psobject]) {
            $obj.$($prop.Name) = CleanJob $value
        }

        # ✅ Do nothing for primitives
    }

    return $obj
}

# ============================================================
# GENIE‑SAFE CLEANER (NO recursion)
# ============================================================
function Clean-GenieJson {
    param(
        [Parameter(Mandatory)]
        [psobject]$Genie
    )

    Write-Host "🔧 Deep Cleaning Genie JSON..." -ForegroundColor Cyan

    function Clean-Object($obj) {

        if ($null -eq $obj) { return $null }

        # Handle arrays
        if ($obj -is [System.Collections.IEnumerable] -and $obj -isnot [string]) {

            $cleanArray = @()

            foreach ($item in $obj) {
                $cleanItem = Clean-Object $item
                if ($null -ne $cleanItem) {
                    $cleanArray += $cleanItem
                }
            }

            return $cleanArray
        }

        # Handle objects
        if ($obj -is [psobject]) {

            $props = @($obj.PSObject.Properties)

            foreach ($p in $props) {

                # ✅ DELETE any workspace reference
                if ($p.Value -is [string] -and $p.Value -match "/workspace/") {
                    Write-Host "❌ Removing workspace reference: $($p.Name)" -ForegroundColor Yellow
                    $obj.PSObject.Properties.Remove($p.Name)
                    continue
                }

                # ✅ REMOVE known problematic fields
                if ($p.Name -in @(
                    "created_at","updated_at","creator_id",
                    "owner","permissions","assets","source",
                    "query_id","dashboard_id","parent_path"
                )) {
                    Write-Host "❌ Removing field: $($p.Name)" -ForegroundColor Yellow
                    $obj.PSObject.Properties.Remove($p.Name)
                    continue
                }

                # ✅ RECURSE deeper
                $cleanValue = Clean-Object $p.Value

                if ($null -eq $cleanValue) {
                    $obj.PSObject.Properties.Remove($p.Name)
                } else {
                    $obj.$($p.Name) = $cleanValue
                }
            }

            return $obj
        }

        return $obj
    }

    return Clean-Object $Genie
}
# ============================================================
# DASHBOARD VALIDATION (guardrail)
# ============================================================

function ValidateDashboard {
    param($dash)

    if (-not $dash.datasets -or $dash.datasets.Count -eq 0) {
        throw "Dashboard has no datasets; deployment would create broken visuals."
    }

    $datasetNames = $dash.datasets.name
    $queryRefs = @()

    foreach ($p in $dash.pages) {
        foreach ($l in $p.layout) {
            if ($l.widget?.queries) {
                foreach ($q in $l.widget.queries) {
                    if ($q.query?.datasetName) {
                        $queryRefs += $q.query.datasetName
                    }
                }
            }
        }
    }

    foreach ($ref in $queryRefs) {
        if ($datasetNames -notcontains $ref) {
            throw "Query references missing dataset: $ref"
        }
    }

    Write-Host "Dashboard validation passed"
}

# ============================================================
# MAIN LOOP
# ============================================================

Get-ChildItem -Path $InputPath -Recurse -File -Filter *.json | ForEach-Object {

    $file = $_
    Write-Host ""
    Write-Host "Processing: $($file.FullName)"

    $json = Get-Content $file.FullName -Raw | ConvertFrom-Json

    # --------------------------------------------------------
    # ARTIFACT TYPE DETECTION
    # --------------------------------------------------------
    $type = "Unknown"

    if ($json.serialized_dashboard) {
        $type = "Dashboard"
    }
    elseif ($json.settings -and ($json.settings.tasks -or $json.format -eq "MULTI_TASK")) {
        $type = "Job"
    }
    elseif ($json.space_id -or $json.serialized_space) {
        $type = "Genie"
    }
    elseif (
        # FILTER
        ($json.widgetType -like "filter*") -or
        ($json.spec?.widgetType -like "filter*") -or
        ($json.name -match "^dashboards/.+/datasets/.+_" -and
         $json.query?.fields?.name -match "associativity$")
    ) {
        $type = "Filter"
    }
    elseif (
        # QUERY
        ($json.query -and -not $json.queryLines) -or
        ($json.fields -and $json.datasetName) -or
        ($json.name -match "^dashboards/.+/datasets/")
    ) {
        $type = "Query"
    }
    elseif (
        # DATASET
        $json.displayName -and $json.queryLines
    ) {
        $type = "Dataset"
    }

    Write-Host "Detected Type: $type"

    # --------------------------------------------------------
    # CLEAN PER TYPE
    # --------------------------------------------------------

    switch ($type) {

        # ================= DASHBOARD =================
        "Dashboard" {

            $removeFields = @(
                "warehouse_id",
                "etag",
                "create_time",
                "update_time",
                "path",
                "dashboard_id",
                "parent_path",
                "lifecycle_state",
                "created_at",
                "updated_at",
                "owner_user_id",
                "run_as_user_id"
            )

            foreach ($rf in $removeFields) {
                if ($json.PSObject.Properties.Name -contains $rf) {
                    $json.PSObject.Properties.Remove($rf)
                }
            }

            # Remove Genie workspace override
            if ($json.uiSettings?.genieSpace) {
                $json.uiSettings.genieSpace.PSObject.Properties.Remove("overrideId")
            }

            # Deserialize, clean, validate, re-serialize
            $dash = $json.serialized_dashboard | ConvertFrom-Json
            $dash = CleanNested $dash
            ValidateDashboard $dash
            $json.serialized_dashboard = $dash | ConvertTo-Json -Depth 100
            
        }

        # ================= JOB =================
        "Job" {

            $json = CleanJob $json

            if ($NormalizeNames -and $json.settings?.name) {
                $json.settings.name = "$($json.settings.name)"
            }
        }

        # ================= GENIE =================
        
        "Genie" {
            # Remove ONLY environment-specific fields
            
            $json = Clean-GenieJson -Genie $json

            # Validate required fields
            if (-not $json.title) {
                throw "Invalid Genie JSON: missing 'title'"
            }

            if (-not $json.serialized_space) {
                throw "Invalid Genie JSON: missing 'serialized_space'"
            }

            # IMPORTANT:
            # DO NOT call CleanNested for Genie
        }
        # ================= DATASET =================
        "Dataset" {

            $removeFields = @(
                "id",
                "created_at",
                "updated_at",
                "owner_user_id"
            )

            foreach ($rf in $removeFields) {
                if ($json.PSObject.Properties.Name -contains $rf) {
                    $json.PSObject.Properties.Remove($rf)
                }
            }

            # Safe SQL / path normalization
            $json = CleanNested $json
        }

        # ================= QUERY =================
        "Query" {

            $removeFields = @(
                "id",
                "created_at",
                "updated_at",
                "owner_user_id",
                "dashboard_id"
            )

            foreach ($rf in $removeFields) {
                if ($json.PSObject.Properties.Name -contains $rf) {
                    $json.PSObject.Properties.Remove($rf)
                }
            }

            # Deterministic normalization (no random names)
            if ($NormalizeNames -and $json.name) {
                $json.name = $json.name -replace "/dashboards/.+?/datasets/", "/dashboards/<ID>/datasets/"
            }

            $json = CleanNested $json
        }

        # ================= FILTER =================
        "Filter" {

            $removeFields = @(
                "id",
                "dashboard_id"
            )

            foreach ($rf in $removeFields) {
                if ($json.PSObject.Properties.Name -contains $rf) {
                    $json.PSObject.Properties.Remove($rf)
                }
            }

            # Keep filter/query relationships intact
            $json = CleanNested $json
        }

        default {
            Write-Host "Unknown artifact type; no destructive cleanup applied."
        }
    }

    # --------------------------------------------------------
    # WRITE BACK (IDEMPOTENT)
    # --------------------------------------------------------
    $json | ConvertTo-Json -Depth 100 | Set-Content -Path $file.FullName -Encoding UTF8
    Write-Host "Cleaned and updated"
}

Write-Host ""
Write-Host "Completed cleaning all artifacts safely and idempotently"
