param(
    [Parameter(Mandatory = $true)]
    [string]$DatabricksHost,

    [Parameter(Mandatory = $true)]
    [string]$DatabricksToken,

    [Parameter(Mandatory = $true)]
    [string] $SpnId,# ✅ REQUIRED

    [switch]$ImportJobs
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

# Root folder where exported job JSONs exist
$ArtifactRoot = Join-Path $env:SYSTEM_DEFAULTWORKINGDIRECTORY "_sox_vabtp_ci_appl-databricks"
$JobsFolder   = Join-Path $ArtifactRoot "Dashboards/exported_jobs"

# ======================================================
# 🔧 Databricks API Wrapper (FAIL PIPELINE ON ERROR)
# ======================================================
function Invoke-DBApi {
    param(
        [ValidateSet("GET","POST","PATCH","PUT","DELETE")]
        [string]$Method,
        [Parameter(Mandatory)]
        [string]$Endpoint,
        $Body = $null
    )

    $Headers = @{
        Authorization = "Bearer $DatabricksToken"
    }

    $base = $DatabricksHost.TrimEnd("/")
    $ep   = $Endpoint.TrimStart("/")
    $Uri  = "$base/api/2.1/$ep"

    try {
        if ($null -ne $Body) {
            $json = $Body | ConvertTo-Json -Depth 100
            Write-Host "➡️ $Method $Uri (payload size=$($json.Length))"
            # Uncomment for debug:
            # Write-Host "REQUEST BODY:`n$json"

            return Invoke-RestMethod -Method $Method -Uri $Uri -Headers $Headers -ContentType "application/json" -Body $json
        }
        else {
            Write-Host "➡️ $Method $Uri"
            return Invoke-RestMethod -Method $Method -Uri $Uri -Headers $Headers
        }
    }
    catch {
        $msg = $_.Exception.Message
        Write-Host "Databricks API call failed: $Method $Uri" -ForegroundColor Red
        Write-Host "Message: $msg" -ForegroundColor Red

        if ($_.ErrorDetails -and $_.ErrorDetails.Message) {
            Write-Host "Details: $($_.ErrorDetails.Message)" -ForegroundColor Red
        }

        # Fail pipeline
        throw
    }
}

# ======================================================
# 🗂 Helpers
# ======================================================
function Get-JsonFiles {
    param([string]$Folder)

    if (Test-Path $Folder) {
        return Get-ChildItem $Folder -Recurse -Filter *.json
    }
    return @()
}
function Convert-ToJobCluster {
    param(
        [Parameter(Mandatory)]
        [psobject]$Settings,

        [Parameter(Mandatory)]
        [string]$SpnId
    )

    $jobClusterKey = "vabtp_dedicated_job_cluster"

    
    # --------------------------------------------------
    # ✅ HANDLE JOB FORMATS SAFELY
    # --------------------------------------------------

    $hasTasks = ($Settings.PSObject.Properties.Name -contains "tasks")

    # Detect any *_task
    $taskType = $Settings.PSObject.Properties.Name | Where-Object { $_ -like "*_task" } | Select-Object -First 1

    if ($hasTasks) {
        Write-Host "Detected MULTI_TASK job with tasks[]"
    }
    elseif ($taskType) {
        Write-Host "Detected SINGLE_TASK job → converting to MULTI_TASK"

        $task = @{
            task_key = "main_task"
        }

        $task[$taskType] = $Settings.$taskType

        $Settings.PSObject.Properties.Remove($taskType)

        $Settings | Add-Member -MemberType NoteProperty -Name "tasks" -Value @($task)
    }
    else {
        # ✅ HANDLE BROKEN EXPORT
        Write-Host "WARNING: No tasks[] or *_task found. Skipping job." -ForegroundColor Yellow
    }
    # --------------------------------------------------
    # ❌ REMOVE SERVERLESS-ONLY JOB PROPERTIES
    # --------------------------------------------------
    if ($Settings.PSObject.Properties.Name -contains "environments") {
        $Settings.PSObject.Properties.Remove("environments")
    }

    if ($Settings.PSObject.Properties.Name -contains "dependent_libraries") {
        $Settings.PSObject.Properties.Remove("dependent_libraries")
    }
    # --------------------------------------------------
    # ✅ DEFINE JOB CLUSTER
    # --------------------------------------------------
    $jobCluster = @{
        job_cluster_key = $jobClusterKey
        new_cluster = @{
            spark_version = "17.3.x-scala2.13"

            data_security_mode = "SINGLE_USER"
            single_user_name   = $SpnId

            driver_node_type_id = "Standard_D16s_v3"
            node_type_id        = "Standard_D8s_v3"

            autoscale = @{
                min_workers = 8
                max_workers = 16
            }
        }
    }

    # Attach job_clusters
    if ($Settings.PSObject.Properties.Name -contains "job_clusters") {
        $Settings.job_clusters = @($jobCluster)
    }
    else {
        $Settings | Add-Member `
            -MemberType NoteProperty `
            -Name "job_clusters" `
            -Value @($jobCluster)
    }

    # --------------------------------------------------
    # ✅ CLEAN + UPDATE TASKS
    # --------------------------------------------------
    if ($Settings.PSObject.Properties.Name -contains "tasks" -and $Settings.tasks) {
        foreach ($task in $Settings.tasks) {

            $isForEach = $task.PSObject.Properties.Name -contains "for_each_task"

            # --------------------------------------------------
            # 🚨 HANDLE FOR_EACH TASK -to update job cluster_key
            # --------------------------------------------------
            if ($isForEach) {

                Write-Host "Fixing for_each_task: $($task.task_key)"
                # ✅ HANDLE INNER TASK
                if ($task.for_each_task -and $task.for_each_task.task) {

                    $innerTask = $task.for_each_task.task

                    # ✅ MUST ASSIGN cluster here
                    if ($innerTask.PSObject.Properties.Name -contains "job_cluster_key") {
                        $innerTask.job_cluster_key = $jobClusterKey
                    }
                    else {
                        $innerTask | Add-Member `
                            -MemberType NoteProperty `
                            -Name "job_cluster_key" `
                            -Value $jobClusterKey
                    }
                    Write-Host "✅ Inner task cluster assigned"
                }
                continue
            }
            # --------------------------------------------------
            # ✅ NORMAL TASK PROCESSING
            # --------------------------------------------------
            # ✅ Attach cluster ONLY for normal tasks
            if ($task.PSObject.Properties.Name -contains "job_cluster_key") {
                $task.job_cluster_key = $jobClusterKey
            }
            else {
                $task | Add-Member -MemberType NoteProperty -Name "job_cluster_key" -Value $jobClusterKey
            }
        }


    }
    else {
        Write-Host "No tasks found → skipping task processing" -ForegroundColor Yellow
    }
    return $Settings
}

function Get-AllJobs {
    $resp = Invoke-DBApi -Method GET -Endpoint "jobs/list"
    $allJobs = @()
    if ($resp.PSObject.Properties.Name -contains "jobs" -and $resp.jobs) {
        $allJobs = $resp.jobs
    }

    Write-Host "Total jobs found in Workspace: $($allJobs.Count)"
    foreach ($job in $allJobs) {
        Write-Host "JobId=$($job.job_id) | Name='$($job.settings.name)'"
    }
    return $allJobs
}


# ======================================================
# 🛠 Jobs Import
# ======================================================
if ($ImportJobs) {
    Write-Host "=== Importing Jobs from: $JobsFolder ==="

    $files = Get-JsonFiles $JobsFolder
    if (-not $files -or $files.Count -eq 0) {
        throw "No job JSON files found under: $JobsFolder"
    }

    $existingJobs = Get-AllJobs

    foreach ($file in $files) {
        Write-Host "Processing file: $($file.FullName)"

        $jobFromFile = Get-Content $file.FullName -Raw | ConvertFrom-Json
        if (-not $jobFromFile.settings) {
            throw "Invalid job JSON (missing .settings): $($file.FullName)"
        }

        $jobName = ($jobFromFile.settings.name).Trim()
        if ([string]::IsNullOrWhiteSpace($jobName)) {
            throw "Invalid job JSON (empty settings.name): $($file.FullName)"
        }

        Write-Host "Job Name: $jobName"

        # Find job by name in current workspace
        $match = @($existingJobs | Where-Object { ($_.settings.name).Trim() -eq $jobName })

        if ($match.Count -gt 1) {
            throw "Multiple jobs found with name '$jobName'. Aborting to avoid ambiguity."
        }

        # Normalize settings
        # $settings = Normalize-JobSettings $jobFromFile.settings
        $settings = Convert-ToJobCluster -Settings $jobFromFile.settings -SpnId $SpnId

        #handle jobs which use policy id to update to env parameter
        if ($settings.PSObject.Properties.Name -contains "budget_policy_id") {
            $settings.budget_policy_id = $env:DATABRICKS_POLICY_ID
        }
        if ($jobFromFile.PSObject.Properties.Name -contains "effective_budget_policy_id") {
            $jobFromFile.budget_policy_id = $env:DATABRICKS_POLICY_ID
        }
        if ($jobFromFile.PSObject.Properties.Name -contains "effective_usage_policy_id") {
            $jobFromFile.budget_policy_id = $env:DATABRICKS_POLICY_ID
        }

        if ($match.Count -eq 1) {
            $jobId = $match[0].job_id
            Write-Host "Updating existing job: $jobName (job_id=$jobId)"

            $resetBody = @{
                job_id       = $jobId
                new_settings = $settings
            }

            Invoke-DBApi -Method POST -Endpoint "jobs/reset" -Body $resetBody | Out-Null
            Write-Host "Updated: $jobName"
        }
        else {
            Write-Host "Creating new job: $jobName"

            $createResp = Invoke-DBApi -Method POST -Endpoint "jobs/create" -Body $settings
            Write-Host "Created: $jobName | job_id=$($createResp.job_id)"
        }
    }

    Write-Host "Import completed with strict validation."
}