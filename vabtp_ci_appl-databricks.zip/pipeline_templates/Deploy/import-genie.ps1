param(
    [Parameter(Mandatory = $true)]
    [string]$DatabricksHost,

    [Parameter(Mandatory = $true)]
    [string]$DatabricksToken,

    [Parameter(Mandatory = $true)]
    [string]$WarehouseId,

    [switch]$ImportGenie
)

$ArtifactRoot = Join-Path $env:SYSTEM_DEFAULTWORKINGDIRECTORY "_sox_vabtp_ci_appl-databricks"

# ======================================================
# 🔧 Databricks API Wrapper (FAIL PIPELINE ON ERROR)
# ======================================================

function Invoke-DBApi {
    param(
        [ValidateSet("GET","POST","PATCH","PUT","DELETE")]
        [string]$Method,
        [string]$Endpoint,
        $Body = $null
    )


        $Headers = @{
            Authorization = "Bearer $databricksToken"
            "Content-Type" = "application/json"
        }

    $Uri = "$DatabricksHost/api/2.0/$Endpoint"

    if ($Endpoint -notmatch "/") {
            throw "Invalid Databricks API endpoint (missing '/'): $Endpoint"
    }
    try {
        if ($Body) {
            $json = $Body | ConvertTo-Json -Depth 100
            Write-Host "$Method $Uri (payload size=$($json.Length))"
            Invoke-RestMethod -Method $Method -Uri $Uri -Headers $Headers -Body $json
        }
        else {
            Write-Host "No Payload : $Method $Uri"
            Invoke-RestMethod -Method $Method -Uri $Uri -Headers $Headers
        }
    }
    
    catch {
        $resp = $_.Exception.Response
        $status = if ($resp) { [int]$resp.StatusCode } else { "Unknown" }
        Write-Host "Message: $($_.Exception.Message)"

        # Inner exception (if any)
        if ($_.Exception.InnerException) {
            Write-Host "InnerException: $($_.Exception.InnerException.Message)"
        }
        Write-Error "Databricks API failure Method   : $Method Endpoint : $Endpoint Status   : $status Response : $resp"
    }

}

# ======================================================
# 🗂 Helpers
# ======================================================

function Get-JsonFiles {
    param([string]$Folder)
    if (Test-Path $Folder) {
        return Get-ChildItem $Folder -Recurse -Filter *.json
    }
    return @()
}

# ======================================================
# 🔮 Genie (OPTIONAL – FAILS IF MISCONFIGURED)
# ======================================================

if ($ImportGenie) {
    Write-Host "Importing Genie Spaces (PATCH Mode)"

    $files = Get-JsonFiles "$ArtifactRoot/Genie/genie_spaces_full"
    $existingGenie = Invoke-DBApi GET "genie/spaces"

    foreach ($file in $files) {

        $obj = Get-Content $file.FullName -Raw | ConvertFrom-Json
        $genieName = $obj.title

        Write-Host "Processing Genie space: $genieName"

        $matches = @(
            $existingGenie.spaces | Where-Object {
                $_.title -eq $genieName
            }
        )

        if ($matches.Count -gt 1) {
            throw "Multiple Genie spaces found with name '$genieName'"
        }

        # Always enforce warehouse
        $obj.warehouse_id = $WarehouseId

        if ($matches.Count -eq 1) {

            $spaceId = $matches[0].space_id
            Write-Host "Updating existing Genie space ($genieName) via PATCH" -ForegroundColor Yellow

            # ✅ Ensure correct ID
            $obj.space_id = $spaceId

            try {
                # ✅ Try PATCH update
                Invoke-DBApi PATCH "genie/spaces/$spaceId" $obj
                Write-Host "PATCH successful for $genieName" -ForegroundColor Green
            }
            catch {
                Write-Host "PATCH failed for $genieName → fallback to recreate" -ForegroundColor Red

                # ✅ Fallback (safe recovery)
                Invoke-DBApi DELETE "genie/spaces/$spaceId"

                # Remove ID before recreate
                $obj.PSObject.Properties.Remove("space_id")

                Invoke-DBApi POST "genie/spaces" $obj

                Write-Host "Recreated Genie space ($genieName)" -ForegroundColor Yellow
            }
        }
        else {
            # ✅ CREATE new
            Write-Host "Creating Genie space ($genieName)" -ForegroundColor Green

            # Ensure no ID conflict
            if ($obj.PSObject.Properties.Name -contains "space_id") {
                $obj.PSObject.Properties.Remove("space_id")
            }

            Invoke-DBApi POST "genie/spaces" $obj
        }
    }
}
Write-Host "Import completed with strict validation"
# -------------------------
# Printing SUmmary of visual objects
# -------------------------
$summary = @()

# -------------------------
# Genie Spaces
# -------------------------
try {
    $genies = Invoke-DBApi GET "genie/spaces"
    foreach ($g in $genies.spaces) {
        $summary += [PSCustomObject]@{
            Type = "Genie"
            Name = $g.title
            Id   = $g.space_id
            Extra = ""
        }
    }
}
catch {
    Write-Warning "Genie listing failed: $_"
}

# -------------------------
# Dashboards (Lakeview) with Queries & Filters
# -------------------------
try {
    $dashboards = Invoke-DBApi GET "lakeview/dashboards"

    foreach ($d in $dashboards.dashboards) {

        $fullDashboard = Invoke-DBApi GET "lakeview/dashboards/$($d.dashboard_id)"

        $queryNames  = @()
        $filterNames = @()

        if ($fullDashboard.serialized_dashboard) {

            $sd = $fullDashboard.serialized_dashboard | ConvertFrom-Json

            # -------------------------
            # Extract Queries
            # -------------------------
            if ($sd.datasets) {
                foreach ($ds in $sd.datasets) {
                    if ($ds.query -and $ds.query.name) {
                        $queryNames += $ds.query.name
                    }
                }
            }

            # -------------------------
            # Extract Filters / Parameters
            # -------------------------
            if ($sd.parameters) {
                foreach ($p in $sd.parameters) {
                    if ($p.name) {
                        $filterNames += $p.name
                    }
                }
            }
        }

        $summary += [PSCustomObject]@{
            Type  = "Dashboard"
            Name  = $d.display_name
            Id    = $d.dashboard_id
            Extra = @{
                Queries = ($queryNames  | Sort-Object -Unique) -join ", "
                Filters = ($filterNames | Sort-Object -Unique) -join ", "
            } | ConvertTo-Json -Compress
        }
    }
}
catch {
    Write-Warning "Dashboard listing failed: $_"
}
# -------------------------
# Jobs
# -------------------------
try {
    $jobs = Invoke-DBApi GET "jobs/list"
    foreach ($j in $jobs.jobs) {
        $summary += [PSCustomObject]@{
            Type = "Job"
            Name = $j.settings.name
            Id   = $j.job_id
            Extra = ""
        }
    }
}
catch {
    Write-Warning "Jobs listing failed: $_"
}

# -------------------------
# SQL Queries + Filters
# -------------------------
try {
    $queries = Invoke-DBApi GET "preview/sql/queries"
    foreach ($q in $queries.results) {

        $filters = ""
        if ($q.options -and $q.options.parameters) {
            $filters = ($q.options.parameters | Select-Object -ExpandProperty name) -join ", "
        }

        $summary += [PSCustomObject]@{
            Type   = "SQL Query"
            Name   = $q.name
            Id     = $q.id
            Extra  = $filters
        }
    }
}
catch {
    Write-Warning "SQL Query listing failed: $_"
}

# -------------------------
# Output
# -------------------------

# -------------------------
# GREEN TABLE OUTPUT
# -------------------------
Write-Host ""
Write-Host ("{0,-12} {1,-35} {2,-38} {3}" -f "Type", "Name", "Id", "Extra") -ForegroundColor Green
Write-Host ("{0,-12} {1,-35} {2,-38} {3}" -f "----", "----", "--", "-----") -ForegroundColor Green

foreach ($row in ($summary | Sort-Object Type, Name)) {
    Write-Host (
        "{0,-12} {1,-35} {2,-38} {3}" -f `
        $row.Type, $row.Name, $row.Id, $row.Extra
    ) -ForegroundColor Green
}