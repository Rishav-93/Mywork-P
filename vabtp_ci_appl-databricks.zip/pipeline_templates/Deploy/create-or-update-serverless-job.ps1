param(
    [Parameter(Mandatory = $true)]
    [string] $DatabricksHost,

    [Parameter(Mandatory = $true)]
    [string] $DatabricksToken,

    [Parameter(Mandatory = $true)]
    [string] $NotebookPath,

    [Parameter(Mandatory = $true)]
    [string] $JobName,

    [Parameter(Mandatory = $false)]
    [string] $ExistingJobId,

    [Parameter(Mandatory = $false)]
    [string] $BudgetPolicyId,

    [Parameter(Mandatory = $false)]
    [string] $ClusterId,        # ✅ REQUIRED
    
    [Parameter(Mandatory = $true)]
    [string] $WarehouseId,       # ✅ REQUIRED

    [Parameter(Mandatory = $true)]
    [string] $SpnId        # ✅ REQUIRED
)


function Call-DBApi {
    param(
        [string]$Method,
        [string]$Endpoint,
        $Body = $null
    )

    $Headers = @{ Authorization = "Bearer $DatabricksToken" }
    $Url = "$DatabricksHost/api/2.0/$Endpoint".TrimEnd('/')

    try {
        if ($Body) {
            $Json = $Body | ConvertTo-Json -Depth 20
            return Invoke-RestMethod -Method $Method -Uri $Url -Headers $Headers -ContentType "application/json" -Body $Json -ErrorAction Stop
        }
        else {
            return Invoke-RestMethod -Method $Method -Uri $Url -Headers $Headers -ErrorAction Stop
        }
    }
    catch {
        Write-Host "❌ API Error calling $Method $Endpoint" -ForegroundColor Red
        Write-Host $_.Exception.Message
        if ($_.ErrorDetails.Message) { Write-Host $_.ErrorDetails.Message }
        exit 1
    }
}


Write-Host "📘 Creating/Updating Databricks Serverless Job"
Write-Host "➡ Notebook: $NotebookPath"
Write-Host "➡ Job Name: $JobName"
Write-Host "➡ Existing Job ID: $ExistingJobId"
Write-Host "➡ Cluster ID: $ClusterID"
Write-Host "➡ Budget Policy ID: $BudgetPolicyId"


# ======================================================================
# ✅ STEP 1 — CHECK / START / WAIT FOR SQL WAREHOUSE
# ======================================================================

# Write-Host "🔍 Checking SQL Warehouse status..."

# $wh = Call-DBApi GET "sql/warehouses/$WarehouseId"
# $state = $wh.state
# Write-Host "➡ Current Warehouse State: $state"

# if ($state -eq "RUNNING") {
#     Write-Host "✅ Warehouse already RUNNING — continuing..."
# }
# else {
#     Write-Host "⚠ Warehouse is NOT running. Attempting to START it..."

#     # ✅ Start warehouse
#     Call-DBApi POST "sql/warehouses/$WarehouseId/start" | Out-Null

#     # ✅ Wait up to 5 minutes for RUNNING
#     $timeoutSec = 300
#     $start = Get-Date

#     while ($true) {
#         Start-Sleep -Seconds 10
#         $wh = Call-DBApi GET "sql/warehouses/$WarehouseId"
#         $state = $wh.state

#         Write-Host "⏳ Warehouse state: $state"

#         if ($state -eq "RUNNING") {
#             Write-Host "✅ Warehouse is RUNNING — continuing..."
#             break
#         }

#         if ((Get-Date) -gt $start.AddSeconds($timeoutSec)) {
#             Write-Host "❌ ERROR: Warehouse did NOT reach RUNNING state within timeout ($timeoutSec seconds)" -ForegroundColor Red
#             exit 1
#         }
#     }
# }

# ======================================================================
# ✅ STEP 2 — BUILD JOB SETTINGS
# ======================================================================
## using cluster

$jobSettings = @{
    name = $JobName

    # Single-task job compute definition
    new_cluster = @{
        spark_version = "17.3.x-scala2.13"
        
        # ✅ REQUIRED for Unity Catalog
        data_security_mode = "SINGLE_USER"
        single_user_name   = $SpnId  


        # Driver and Worker node sizes
        driver_node_type_id = "Standard_D16s_v3"
        node_type_id        = "Standard_D8s_v3"

        autoscale = @{
            min_workers = 8
            max_workers = 16
        }
    }

    # Single notebook task
    notebook_task = @{
        notebook_path = $NotebookPath
        base_parameters = @{}
    }

    timeout_seconds = 0
}
# else ## USING WAREHOUSE SERVERLESS
# {
# ####using warehouse(serverless)
# $jobSettings = @{
#         name = $JobName

#         tasks = @(
#             @{
#                 task_key = "orchestrator"
#                 timeout_seconds = 0

#                 notebook_task = @{
#                     notebook_path = $NotebookPath
#                     base_parameters = @{}
#                 }
#                 Warehouse_id = $WarehouseId
#             }
#         )
#     }
#     if ($BudgetPolicyId) {
#         $jobSettings.budget_policy_id = $BudgetPolicyId
#     }
# }
# ======================================================================
# ✅ STEP 3 — RESET EXISTING JOB (NO EXIT HERE ANYMORE)
# ======================================================================

if ($ExistingJobId) {
    Write-Host "♻ Resetting existing job ID $ExistingJobId..."

    $payload = @{
        job_id       = $ExistingJobId
        new_settings = $jobSettings
    }

    Call-DBApi POST "jobs/reset" $payload | Out-Null

    Write-Host "✅ Job reset successfully (ID = $ExistingJobId)"

    # ✅ Store ID so we can use it later to trigger
    $FinalJobId = $ExistingJobId
}
else {
    # ======================================================================
    # ✅ STEP 4 — CREATE NEW JOB ONLY IF NO EXISTING JOB
    # ======================================================================

    Write-Host "➕ Creating new Serverless Job..."

    $response = Call-DBApi POST "jobs/create" $jobSettings

    $newJobId = $response.job_id
    Write-Host "✅ Created Job ID: $newJobId"

    # ✅ Export new Job ID to pipeline vars
    Write-Host "##vso[task.setvariable variable=CREATED_JOB_ID;]$newJobId"
    Write-Host "👉 Please store this Job ID ($newJobId) into your variable group."

    $FinalJobId = $newJobId
}

# ✅ At this point:
#    $FinalJobId contains the existing or newly-created job ID.
#    This allows the next step to TRIGGER the job.
Write-Host "✅ FINAL JOB ID FOR TRIGGERING: $FinalJobId"