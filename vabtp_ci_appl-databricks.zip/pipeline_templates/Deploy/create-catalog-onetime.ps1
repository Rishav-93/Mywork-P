$DatabricksHost  = "$(DATABRICKS_HOST)"
$DatabricksToken = "$(DATABRICKS_TOKEN)"
$WarehouseId     = "$(WAREHOUSE_ID)"
$Ring            = "$(RING)"

$CatalogName = "shared_datalake_$Ring"
$JobIdentity = "DBR-SERVICE-JOB-UC-VABTP-R2"

$Headers = @{
  Authorization = "Bearer $DatabricksToken"
  "Content-Type" = "application/json"
}

$SqlStatements = @(
  "CREATE CATALOG IF NOT EXISTS $CatalogName COMMENT 'Shared datalake for $Ring';",
  "GRANT USE CATALOG ON CATALOG $CatalogName TO `$JobIdentity`;",
  "GRANT CREATE SCHEMA ON CATALOG $CatalogName TO `$JobIdentity`;"
)

foreach ($stmt in $SqlStatements) {

  $payload = @{
    warehouse_id = $WarehouseId
    statement    = $stmt
  } | ConvertTo-Json -Depth 5

  $response = Invoke-RestMethod `
    -Uri "$DatabricksHost/api/2.0/sql/statements" `
    -Headers $Headers `
    -Method POST `
    -Body $payload

  Write-Host "Executed: $stmt"
}