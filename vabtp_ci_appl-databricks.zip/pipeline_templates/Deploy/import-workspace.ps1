param(
    [Parameter(Mandatory=$true)]
    [string]$DatabricksHost,    

    [Parameter(Mandatory=$true)]
    [string]$DatabricksToken,

    [Parameter(Mandatory=$false)]
    [string[]]$FoldersToImport,

    [Parameter(Mandatory=$false)]
    [switch]$ImportWorkspace
)

$ArtifactRoot = Join-Path $env:SYSTEM_DEFAULTWORKINGDIRECTORY "_sox_vabtp_ci_appl-databricks"

# --------------------------------------------------------
# ✅ Destination mapping only for WORKSPACE folders
# --------------------------------------------------------

# Read env variable
$destEnv = $env:DATABRICKS_WORKSPACE_DESTINATION_PATH

if (-not $destEnv) {
    Write-Host "❌ ERROR: Environment variable DATABRICKS_WORKSPACE_DESTINATION_PATH is empty."
    exit 1
}

# Split into an array
$destPaths = $destEnv.Split("#") | ForEach-Object { $_.Trim() }
# ✅ Build destination map dynamically
$DestinationMap = @{}

# --------------------------------------------------------
# ✅ Databricks API Wrapper
# --------------------------------------------------------
function Invoke-DBApi {
    param(
        [string]$Method,
        [string]$Endpoint,
        $Body = $null
    )

    $Headers = @{ Authorization = "Bearer $DatabricksToken" }
    $Uri = "$DatabricksHost/api/2.0/$Endpoint"

    try {
        if ($Body) {
            Write-Host "Calling Databricks api $Uri with body $Body"
            $JsonBody = $Body | ConvertTo-Json -Depth 50
            return Invoke-RestMethod -Method $Method -Uri $Uri -Headers $Headers -Body $JsonBody -ContentType "application/json"
        }
        else {
            Write-Host "Calling Databricks api $Uri"
            return Invoke-RestMethod -Method $Method -Uri $Uri -Headers $Headers
        }
    }
    catch {
            Write-Host "❌ Error calling $Method $Endpoint"
            # Basic error message
        Write-Host "Message: $($_.Exception.Message)" -ForegroundColor Yellow

            # Inner exception (if any)
        if ($_.Exception.InnerException) {
            Write-Host "InnerException: $($_.Exception.InnerException.Message)" -ForegroundColor Yellow
        }
    }
}

# --------------------------------------------------------
# ✅ Ensure Workspace Folder Exists
# --------------------------------------------------------
function Ensure-WorkspaceFolder {
    param([string]$Path)

    $cleanPath = $Path -replace "\\", "/" -replace "//+", "/"
    $parts = $cleanPath.Split("/") | Where-Object { $_ -ne "" }

    $current = ""

    foreach ($p in $parts) {
        $current += "/$p"

        $status = Invoke-DBApi GET "workspace/get-status?path=$current"
        if (-not $status) {
            Write-Host "📁 Creating folder: $current"
            try
            {
            Invoke-DBApi POST "workspace/mkdirs" @{ path = $current } | Out-Null
            }
            catch {
                Write-Host "Error Creating folder: $current" -ForegroundColor Red
                Write-Host "Message: $($_.Exception.Message)" -ForegroundColor Yellow
            }
        }
    }
}
# --------------------------------------------------------
# ✅ 6. Import Workspace — Dynamic Folder Uploading 
# --------------------------------------------------------
function Get-AllFiles {
    param([string]$Folder)
    if (Test-Path $Folder) {
        return Get-ChildItem $Folder -Recurse -File
    }
    return @()
}

# --------------------------------------------------------
# ✅ Import Workspace
# --------------------------------------------------------
if ($ImportWorkspace) {

    if (-not $FoldersToImport) {
        Write-Host "⚠ No folders provided in -FoldersToImport"
        exit 0
    }

    if ($FoldersToImport.Count -eq 1 -and $FoldersToImport[0] -like "*#*") {
        Write-Host "🔧 Splitting folders using '#' delimiter..."
        $FoldersToImport = $FoldersToImport[0].Split("#") |
            ForEach-Object { $_.Trim() } |
            Where-Object { $_ -ne "" }
    }

    for ($i = 0; $i -lt $FoldersToImport.Count; $i++) {
        $DestinationMap[$FoldersToImport[$i]] = $destPaths[$i]
        Write-Host "🔗 Mapping: $($FoldersToImport[$i]) → $($destPaths[$i])"
    }

    Write-Host "`n📁 Importing workspace folders..."

    foreach ($folder in $FoldersToImport) {

        $localFolder = Join-Path $ArtifactRoot $folder

        if (!(Test-Path $localFolder)) {
            Write-Host "⚠ Folder not found: $localFolder"
            continue
        }

        Write-Host "`n📂 Processing folder: $folder"

        $destinationBase = $DestinationMap[$folder]
        $files = Get-AllFiles $localFolder -Recurse -File
        

        foreach ($file in $files) {

            # Normalized paths
            $full = (Resolve-Path $file.FullName).Path
            $base = (Resolve-Path $localFolder).Path

            $relative = $full.Substring($base.Length) -replace "\\", "/"
            if ($relative.StartsWith("/")) { $relative = $relative.Substring(1) }

            # ✅ Fix filenames with spaces
            $relative = $relative -replace " ", "_"

            $remotePath = "$destinationBase/$relative" -replace "//+", "/"

            # Ensure folder structure exists
            Ensure-WorkspaceFolder (Split-Path $remotePath -Parent)

            # ✅ Read file content (BUG FIX)
            $content = Get-Content $file.FullName -Raw -Encoding UTF8

            if ([string]::IsNullOrWhiteSpace($content)) {
                $encoded = ""
            }
            else {
                $encoded = [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($content))
            }

            # Detect file type
            $ext = [System.IO.Path]::GetExtension($file.FullName).ToLower()
            $format   = $null
            $language = $null

            switch ($ext) {
                ".py"     { $format = "SOURCE";  $language = "PYTHON" }
                ".sql"    { $format = "SOURCE";  $language = "SQL" }
                ".scala"  { $format = "SOURCE";  $language = "SCALA" }
                ".r"      { $format = "SOURCE";  $language = "R" }
                ".ipynb"  { $format = "JUPYTER" }

                default   { $format = "AUTO" }
            }

            # ✅ Build API Body (SAFE)
            $body = @{
                path      = $remotePath
                format    = $format
                overwrite = $true
                content   = $encoded
            }

            if ($format -eq "SOURCE" -and $language) {
                $body.language = $language
            }

            Write-Host "➡ Uploading ($format): $remotePath"
            Invoke-DBApi POST "workspace/import" $body | Out-Null
        }
    }
    Write-Host "##vso[task.setvariable variable=IMPORT_WORKSPACE;]true"
}
Write-Host "`n✅ Import Completed Successfully!"