
param(
    [Parameter(Mandatory=$true)]
    [string]$ArtifactFolders,
     [Parameter(Mandatory=$true)]
    [string]$BaseCatalog,
     [Parameter(Mandatory=$true)]
    [string]$Catalog
)
Write-Host "Starting multi-folder text replacement..."

# Variables from Azure DevOps
$foldersRaw = "$ArtifactFolders"    # e.g.: Dashboards#Genie#Recon#VolAccountB2P
$basePath = Join-Path $env:SYSTEM_DEFAULTWORKINGDIRECTORY "_sox_vabtp_ci_appl-databricks"
$find       = "$BaseCatalog"
$replace    = "$Catalog"

Write-Host "Base Path: $basePath"
Write-Host "Folders to process: $foldersRaw"

function Update-FilesRecursively {
    param (
        [Parameter(Mandatory = $true)]
        [string]$FullPath,

        [Parameter(Mandatory = $true)]
        [string]$Find,

        [Parameter(Mandatory = $true)]
        [string]$Replace
    )

    if (-not (Test-Path $FullPath)) {
        Write-Error "❌ Path does not exist: $FullPath"
        return
    }

    Write-Host "🔍 Scanning path: $FullPath"

    Get-ChildItem -Path $FullPath -Recurse -File | ForEach-Object {

        $file = $_.FullName
        Write-Host "Updating file: $file"

        try {
            $content = Get-Content -Path $file -Raw

            # Replace catalog
            $newContent = $content -replace $Find, $Replace

            Set-Content -Path $file -Value $newContent -Encoding UTF8
            Write-Host "Updating file complete: $file"
        }
        catch {
            Write-Error "❌ Failed to update file: $file"
            Write-Error $_
        }
    }

    Write-Host "🎉 All files processed successfully."
}

Write-Host "✅ Replacement Starting for $basePath"
Update-FilesRecursively -FullPath $basePath -Find "shared_datalake_ring3" -Replace $Catalog #replace references to old ring 3 catalog
Update-FilesRecursively -FullPath $basePath -Find "shared_datalake_ring2" -Replace $Catalog #replace references to old ring 2 catalog
Update-FilesRecursively -FullPath $basePath -Find $BaseCatalog -Replace $Catalog #replace catalog current like vabtp_dev to vabtp_test etc
Update-FilesRecursively -FullPath $basePath -Find "/Workspace/shared" -Replace "/Workspace/vabtp" #replace old path
Update-FilesRecursively -FullPath $basePath -Find "/Workspace/Shared" -Replace "/Workspace/vabtp" #replace old path

Write-Host "✅ Replacement completed for all folders."
