param(
    [Parameter(Mandatory = $true)]
    [string]$DatabricksHost,

    [Parameter(Mandatory = $true)]
    [string]$DatabricksToken,

    [switch]$ImportDashboards
)

$ArtifactRoot = Join-Path $env:SYSTEM_DEFAULTWORKINGDIRECTORY "_sox_vabtp_ci_appl-databricks"

# ======================================================
# 🔧 Databricks API Wrapper (FAIL PIPELINE ON ERROR)
# ======================================================

function Invoke-DBApi {
    param(
        [ValidateSet("GET","POST","PATCH","PUT","DELETE")]
        [string]$Method,
        [string]$Endpoint,
        $Body = $null
    )


    $Headers = @{
        Authorization = "Bearer $DatabricksToken"
        "Content-Type" = "application/json"
    }

    $Uri = "$DatabricksHost/api/2.0/$Endpoint"

    if ($Endpoint -notmatch "/") {
        throw "Invalid Databricks API endpoint (missing '/'): $Endpoint"
    }

    try {
        if ($Body) {

            if ($Body -is [hashtable] -and $Body.ContainsKey("serialized_dashboard")) {

                # Build payload dynamically (avoid display_name:null on PATCH)
                $payload = @{}

                if ($Body.ContainsKey("display_name") -and $Body.display_name) {
                    $payload.display_name = $Body.display_name
                }
                if ($Body.ContainsKey("warehouse_id") -and $Body.warehouse_id) {
                    $payload.warehouse_id = $Body.warehouse_id
                }
                if ($Body.ContainsKey("parent_path") -and $Body.parent_path) {
                    $payload.parent_path = $Body.parent_path
                }

                # Enforce serialized_dashboard as STRING (Lakeview expects string JSON blob) [1](https://docs.databricks.com/aws/en/dashboards/tutorials/dashboard-crud-api)[2](https://docs.azure.cn/en-us/databricks/ai-bi/admin/use-apis)
                $sd = $Body.serialized_dashboard
                if ($sd -isnot [string]) {
                    $sd = $sd | ConvertTo-Json -Depth 100
                }
                $payload.serialized_dashboard = $sd

                $json = $payload | ConvertTo-Json -Depth 100 -Compress
            }
            else {
                $json = $Body | ConvertTo-Json -Depth 100
            }

            Write-Host "$Method $Uri (payload size=$($json.Length))"
            Invoke-RestMethod -Method $Method -Uri $Uri -Headers $Headers -Body $json
        }
        else {
            Write-Host "No Payload : $Method $Uri"
            Invoke-RestMethod -Method $Method -Uri $Uri -Headers $Headers
        }
    }
    catch {
        $resp = $_.Exception.Response
        if ($resp -is [System.Net.Http.HttpResponseMessage]) {
            try {
                if ($resp.Content) {
                    $body = $resp.Content.ReadAsStringAsync().GetAwaiter().GetResult()
                    Write-Host "Databricks error body:" -ForegroundColor Red
                    Write-Host $body -ForegroundColor Red
                }
            } catch { }
        }
        throw
    }
}
# ======================================================
# 🗂 Helpers
# ======================================================

function Get-JsonFiles {
    param([string]$Folder)
    if (Test-Path $Folder) {
        return Get-ChildItem $Folder -Recurse -Filter *.json
    }
    return @()
}
function Normalize-SerializedDashboardString {
    param(
        [Parameter(Mandatory)]
        [string]$SerializedDashboard
    )

    $inner = $SerializedDashboard | ConvertFrom-Json

    foreach ($page in $inner.pages) {

        # -------- Fix legacy layout: must be an ARRAY of items --------
        if ($page.layout -and ($page.layout -isnot [array]) -and $page.layout.widget) {
            $page.layout = @($page.layout)
        }

        # If legacy layout is an array, ensure queries is an array
        if ($page.layout -is [array]) {
            foreach ($item in $page.layout) {

                if ($item.widget -and $item.widget.queries -and ($item.widget.queries -isnot [array])) {
                    $item.widget.queries = @($item.widget.queries)
                }

                foreach ($q in @($item.widget.queries)) {
                    if ($q.query -and $q.query.fields -and ($q.query.fields -isnot [array])) {
                        $q.query.fields = @($q.query.fields)
                    }
                    if ($q.query -and $q.query.filters -and ($q.query.filters -isnot [array])) {
                        $q.query.filters = @($q.query.filters)
                    }
                }
            }
        }

        # -------- Fix modern layout.widgets: must be ARRAY --------
        if ($page.layout -and $page.layout.widgets) {
            if ($page.layout.widgets -isnot [array]) {
                $page.layout.widgets = @($page.layout.widgets)
            }

            foreach ($w in $page.layout.widgets) {
                if ($w.queries -and ($w.queries -isnot [array])) {
                    $w.queries = @($w.queries)
                }
                foreach ($q in @($w.queries)) {
                    if ($q.query -and $q.query.fields -and ($q.query.fields -isnot [array])) {
                        $q.query.fields = @($q.query.fields)
                    }
                    if ($q.query -and $q.query.filters -and ($q.query.filters -isnot [array])) {
                        $q.query.filters = @($q.query.filters)
                    }
                }
            }
        }
    }

    return ($inner | ConvertTo-Json -Depth 100)
}

# ======================================================
# 📊 Dashboards (QUERIES + FILTERS MERGED)
# ======================================================


if ($ImportDashboards) {
    Write-Host "Importing Lakeview Dashboards (with Queries & Filters)"

    $files = Get-JsonFiles "$ArtifactRoot/Dashboards/lakeview_full"

    # Get ALL dashboards once
    $existingDashboards = Invoke-DBApi GET "lakeview/dashboards"

    foreach ($file in $files) {
        Write-Host "Processing dashboard: $displayName"
        $dashboardExport = Get-Content $file.FullName -Raw | ConvertFrom-Json

        $displayName = $dashboardExport.display_name
        $serializedDashboard = $dashboardExport.serialized_dashboard
        
        # Always normalize after any potential dev->test rewrite step
        $serializedDashboard = Normalize-SerializedDashboardString -SerializedDashboard $serializedDashboard

        $check = ($serializedDashboard | ConvertFrom-Json)
        foreach ($p in $check.pages) {
            Write-Host "AFTER FIX: Page '$($p.displayName)' layout type: $($p.layout.GetType().Name)"
            if ($p.layout -and $p.layout.widgets -and ($p.layout.widgets -isnot [array])) {
                throw "❌ BAD ARTIFACT: page '$($p.displayName)' has layout.widgets as OBJECT, must be ARRAY."
            }
        }
        # ❌ No server‑side filtering — filter locally
        $matches = @(
            $existingDashboards.dashboards |
            Where-Object { $_.display_name -eq $displayName }
        )

        if ($matches.Count -gt 1) {
            throw "Multiple dashboards found with name '$displayName'"
        }
        elseif ($matches.Count -eq 1) {

            $dashboardId = $matches[0].dashboard_id
            Write-Host "Updating dashboard ($displayName) [$dashboardId]" -ForegroundColor Yellow
            
            # ✅ PATCH must ONLY include serialized_dashboard
            $patchPayload = @{
                serialized_dashboard = $serializedDashboard
            }
            $patchPayload
            Invoke-DBApi PATCH "lakeview/dashboards/$dashboardId" $patchPayload
            #publish dashboard post update
            Invoke-DBApi POST "lakeview/dashboards/$dashboardId/published"
        }
        else {
            Write-Host "Creating new dashboard ($displayName)" -ForegroundColor Green
            $serializedDashboard
            # ✅ POST expects full create payload
            $response = Invoke-DBApi POST "lakeview/dashboards" @{
                display_name        = $displayName
                serialized_dashboard = $serializedDashboard
            }
            # ✅ Extract dashboard ID
            $dashboardId = $response.dashboard_id

            #publish dashboard post update
            Invoke-DBApi POST "lakeview/dashboards/$dashboardId/published"
        }
    }
}

Write-Host "Dashboard import completed successfully"
