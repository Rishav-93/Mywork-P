param(
    [Parameter(Mandatory=$true)]
    [string]$SourceHost,

    [Parameter(Mandatory=$true)]
    [string]$SourceToken,

    [Parameter(Mandatory=$true)]
    [string]$ExportDir
)

# Ensure output exists
New-Item -ItemType Directory -Force -Path $ExportDir | Out-Null

function Invoke-MLflowApi {
    param([string]$Endpoint)

    $uri = "$SourceHost/api/2.0/$Endpoint"
    return Invoke-RestMethod -Method GET -Uri $uri -Headers @{ Authorization="Bearer $SourceToken" }
}

Write-Host "🔍 Fetching experiments..."
$experiments = Invoke-MLflowApi "mlflow/experiments/list"
$experiments.items | ConvertTo-Json -Depth 50 | Out-File "$ExportDir/experiments.json"

foreach ($exp in $experiments.items) {

    $expId = $exp.experiment_id
    $expDir = Join-Path $ExportDir "experiment_$expId"
    New-Item -ItemType Directory -Force -Path $expDir | Out-Null

    Write-Host "📦 Exporting Experiment $expId - $($exp.name)"

    # Export experiment details
    Invoke-MLflowApi "mlflow/experiments/get?experiment_id=$expId" |
        ConvertTo-Json -Depth 50 | Out-File "$expDir/experiment.json"

    # Export runs
    $runs = Invoke-RestMethod `
        -Method POST `
        -Uri "$SourceHost/api/2.0/mlflow/runs/search" `
        -Headers @{ Authorization="Bearer $SourceToken" } `
        -Body (@{ experiment_ids = @($expId) } | ConvertTo-Json)

    $runs.runs | ConvertTo-Json -Depth 50 | Out-File "$expDir/runs.json"

    foreach ($run in $runs.runs) {
        $runId = $run.run_id
        $runDir = Join-Path $expDir "run_$runId"
        New-Item -ItemType Directory -Force -Path $runDir | Out-Null

        Write-Host "   ➤ Exporting run $runId..."

        # Export run metadata
        Invoke-MLflowApi "mlflow/runs/get?run_id=$runId" |
            ConvertTo-Json -Depth 50 | Out-File "$runDir/run.json"

        # Export artifacts from DBFS
        $artifactPath = "dbfs:/databricks/mlflow-tracking/$expId/$runId/artifacts"

        $exportArtifactDir = Join-Path $runDir "artifacts"
        New-Item -ItemType Directory -Force -Path $exportArtifactDir | Out-Null

        Write-Host "     📁 Copying artifact files..."

        # Recursive export from DBFS
        $items = Invoke-RestMethod `
            -Uri "$SourceHost/api/2.0/dbfs/list?path=$artifactPath" `
            -Headers @{ Authorization="Bearer $SourceToken" }

        foreach ($item in $items.files) {
            $dest = Join-Path $exportArtifactDir (Split-Path $item.path -Leaf)
            Invoke-RestMethod `
                -Uri "$SourceHost/api/2.0/dbfs/get?path=$($item.path)" `
                -Headers @{ Authorization="Bearer $SourceToken" } `
                -OutFile $dest
        }
    }
}

Write-Host "`n✅ MLflow Export Completed!"