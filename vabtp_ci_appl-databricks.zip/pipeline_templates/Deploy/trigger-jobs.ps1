param(
    [Parameter(Mandatory=$true)]
    [string] $DatabricksHost,

    [Parameter(Mandatory=$true)]
    [string] $DatabricksToken,

    [Parameter(Mandatory=$false)]
    [string] $JobId,     # From variable group (VOL_B2P_JOB_ID_QA)

    [Parameter(Mandatory=$true)]
    [string] $RingName,
    
    [Parameter(Mandatory=$true)]
    [string] $JobName
)

# =====================================================================================
# ✅ API HELPER
# =====================================================================================
function Call-DBApi {
    param(
        [string]$Method,
        [string]$Endpoint,
        $Body = $null
    )

    $Headers = @{ Authorization = "Bearer $DatabricksToken" }
    $Url = "$DatabricksHost/api/2.1/$Endpoint".TrimEnd('/')

    try {
        if ($Body) {
            $Json = $Body | ConvertTo-Json -Depth 20
            return Invoke-RestMethod -Method $Method -Uri $Url -Headers $Headers -ContentType "application/json" -Body $Json -ErrorAction Stop
        }
        else {
            return Invoke-RestMethod -Method $Method -Uri $Url -Headers $Headers -ErrorAction Stop
        }
    }
    catch {
        Write-Host "❌ API Error calling $Method $Endpoint" -ForegroundColor Red
        Write-Host $_.Exception.Message
        if ($_.ErrorDetails.Message) { Write-Host $_.ErrorDetails.Message }
        exit 1
    }
}

# =====================================================================================
# ✅ VALIDATE & CLEAN JOB ID (remove invisible Unicode chars)
# =====================================================================================
$JobId = ($JobId -replace '[^\d]', '')  # CRUCIAL

if (-not $JobId) {
    Write-Host "❌ ERROR: Invalid or empty job ID" -ForegroundColor Red
    exit 1
}

Write-Host "🚀 Triggering Databricks Job Run"
Write-Host "Job ID: $JobId"
Write-Host "Host: $DatabricksHost"

# =====================================================================================
# ✅ TRIGGER THE RUN
# =====================================================================================
$payload = @{ job_id = $JobId }

if ($RingName) {
    $payload.notebook_params = @{ anlc_ringname = $RingName }
}

$runResponse = Call-DBApi -Method POST -Endpoint "jobs/run-now" -Body $payload
$runId = $runResponse.run_id

Write-Host "✅ Run ID = $runId"
Write-Host "⏳ Waiting for completion..."

# =====================================================================================
# ✅ POLL UNTIL JOB FINISHES
# =====================================================================================
$timeoutSec = 3600
$start = Get-Date

while ($true) {

    $status = Call-DBApi GET "jobs/runs/get?run_id=$runId"

    $life   = $status.state.life_cycle_state
    $result = $status.state.result_state

    Write-Host "▶ lifecycle=$life result=$result"

    if ($life -in @("TERMINATED","SKIPPED","INTERNAL_ERROR")) { break }

    if ((Get-Date) -gt $start.AddSeconds($timeoutSec)) {
        Write-Host "❌ ERROR: Timeout after $timeoutSec seconds" -ForegroundColor Red
        exit 1
    }

    Start-Sleep -Seconds 10
}

# =====================================================================================
# ✅ ERROR DETAILS EXTRACTOR (Shared function)
# =====================================================================================
function Print-TaskErrors {
    param($OutputObj)

    if ($OutputObj.error) {
        Write-Host "❌ ERROR:" -ForegroundColor Red
        Write-Host $OutputObj.error
    }

    if ($OutputObj.error_trace) {
        Write-Host "🔍 ERROR TRACE:" -ForegroundColor Red
        Write-Host $OutputObj.error_trace
    }

    if ($OutputObj.notebook_output.result) {
        Write-Host "📄 NOTEBOOK OUTPUT:"
        Write-Host $OutputObj.notebook_output.result
    }
}

# =====================================================================================
# ✅ HANDLE MULTI‑TASK vs SINGLE‑TASK
# =====================================================================================
$isMulti = $false
if ($status.tasks -and $status.tasks.Count -gt 0) { $isMulti = $true }

# ------------------------------------------------------------------------------
# ✅ SINGLE-TASK JOB
# ------------------------------------------------------------------------------
if (-not $isMulti) {

    Write-Host "📄 Fetching output (single-task run)..."

    $output = Call-DBApi GET "jobs/runs/get-output?run_id=$runId"

    $final = $output.metadata.state.result_state

    # Extract error details
    Print-TaskErrors $output

}
else {

    Write-Host "📄 Multi-task run detected — collecting each task output…"

    $overallFailed = $false

    foreach ($task in $status.tasks) {

        $taskKey   = $task.task_key
        $taskRunId = $task.run_id

        Write-Host "---- Output for task: $taskKey (run_id=$taskRunId) ----"

        $taskOut = Call-DBApi GET "jobs/runs/get-output?run_id=$taskRunId"

        $tResult = $taskOut.metadata.state.result_state
        Write-Host "Task result: $tResult"

        if ($tResult -ne "SUCCESS") { 
            $overallFailed = $true 
        }

        # ✅ Print detailed errors
        Print-TaskErrors $taskOut
    }

    $final = if ($overallFailed) { "FAILED" } else { "SUCCESS" }
}

# =====================================================================================
# ✅ FINAL RESULT
# =====================================================================================
Write-Host "✅ FINAL RESULT: $final"

if ($final -ne "SUCCESS") {
    Write-Host "❌ ERROR: Job run failed" -ForegroundColor Red
    exit 1
}

Write-Host "✅ Job run succeeded"
exit 0