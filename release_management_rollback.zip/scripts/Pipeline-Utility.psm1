function Invoke-AdoPipelineRun {
    param (
        [Parameter(Mandatory = $true)]
        [string]$Organization,

        [Parameter(Mandatory = $true)]
        [string]$Project,

        [Parameter(Mandatory = $true)]
        [string]$PipelineId,

        [Parameter(Mandatory = $true)]
        [string]$PAT,

        [Parameter(Mandatory = $false)]
        [string]$BranchName,

        [Parameter(Mandatory = $false)]
        [string]$Tag
    )

    $tagflag = $false
    if($BranchName)
    {
        $refName = "refs/heads/$($BranchName)"
    }
    else
    {
        $refName = "refs/tags/$($Tag)"
        $tagflag =$true
    }

    $base64AuthInfo = [Convert]::ToBase64String(
        [Text.Encoding]::ASCII.GetBytes(":$PAT")
    )

    $body = @{
        resources = @{
            repositories = @{
                self = @{
                    refName = "$($refName)"
                }
            }
        }
    } | ConvertTo-Json -Depth 10

    $url = "$($Organization)/$($Project)/_apis/pipelines/$($PipelineId)/runs?api-version=7.1"

    Write-Host "======================================="
    Write-Host "Organization : $Organization"
    Write-Host "Project      : $Project"
    Write-Host "Pipeline ID  : $PipelineId"
    Write-Host "Branch       : $BranchName"
    Write-Host "Tag          : $Tag"
    Write-Host "Ref Name     : $refName"
    Write-Host "URL          : $url"
    Write-Host "Body         : $body"
    Write-Host "======================================="

    $trigger = Invoke-RestMethod `
        -Uri $url `
        -Method Post `
        -Headers @{ Authorization = "Basic $base64AuthInfo" } `
        -ContentType "application/json" `
        -Body $body
    
    $trigger

    if($tagflag){
    $runId = $trigger.id
    Write-host "Run ID: $($runId)"
    $tagUrl = "$($Organization)/$($Project)/_apis/build/builds/$($runId)/tags/$($Tag)?api-version=7.1"
    Write-host "Tagging Build pipeline"
    Invoke-RestMethod `
        -Uri $tagUrl `
        -Method Put `
        -Headers @{ Authorization = "Basic $base64AuthInfo" }
    }
}

Export-ModuleMember -Function `
    Invoke-AdoPipelineRun