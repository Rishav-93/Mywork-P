function New-AdoHotfixBranch {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$OrganizationUrl,

        [Parameter(Mandatory = $true)]
        [string]$ProjectName,

        [Parameter(Mandatory = $true)]
        [string]$RepositoryName,

        [Parameter(Mandatory = $true)]
        [string]$PatToken,

        [Parameter(Mandatory = $true)]
        [string]$ReleaseId,

        [Parameter(Mandatory = $false)]
        [string]$SourceBranch = "Release",

        [Parameter(Mandatory = $false)]
        [string]$HotfixPrefix = "Hotfix"
    )

    $ErrorActionPreference = "Stop"

    try {

        # ---------------------------------------
        # Branch Names
        # ---------------------------------------
        $newBranch = "$HotfixPrefix/Hotfix-$ReleaseId"

        Write-Host "Source Branch : refs/heads/$SourceBranch"
        Write-Host "New Branch    : refs/heads/$newBranch"

        # ---------------------------------------
        # Authentication
        # ---------------------------------------
        $base64AuthInfo = [Convert]::ToBase64String(
            [Text.Encoding]::ASCII.GetBytes(":$PatToken")
        )

        $headers = @{
            Authorization = "Basic $base64AuthInfo"
        }

        # ---------------------------------------
        # Get Latest Commit ID
        # ---------------------------------------
        $refsUrl = "$OrganizationUrl/$ProjectName/_apis/git/repositories/$RepositoryName/refs?filter=heads/$SourceBranch&api-version=7.1"

        Write-Host "Fetching latest commit from source branch..."
        Write-Host $refsUrl

        $refsResponse = Invoke-RestMethod `
            -Uri $refsUrl `
            -Method Get `
            -Headers $headers

        if (-not $refsResponse.value) {
            throw "Source branch '$SourceBranch' not found."
        }

        $commitId = $refsResponse.value[0].objectId

        Write-Host "Latest Commit ID : $commitId"

        # ---------------------------------------
        # Create Branch
        # ---------------------------------------
        $createBranchUrl = "$OrganizationUrl/$ProjectName/_apis/git/repositories/$RepositoryName/refs?api-version=7.1"

        $body = @"
[
  {
    "name": "refs/heads/$newBranch",
    "oldObjectId": "0000000000000000000000000000000000000000",
    "newObjectId": "$commitId"
  }
]
"@

        Write-Host "Creating branch: refs/heads/$newBranch"

        $response = Invoke-RestMethod `
            -Uri $createBranchUrl `
            -Method Post `
            -Headers $headers `
            -Body $body `
            -ContentType "application/json"

        Write-Host "Branch created successfully."
        Write-Host "Branch Name: refs/heads/$newBranch"

        return $response
    }
    catch {
        Write-Error $_.Exception.Message
        throw
    }
}

#Example usage
# New-AdoHotfixBranch `
#     -OrganizationUrl "https://p66-corporate.visualstudio.com" `
#     -ProjectName "VolumetricAccountingBooktoPhysicalautomation" `
#     -RepositoryName "vabtp_release_management" `
#     -PatToken "YOUR_PAT_TOKEN" `
#     -ReleaseId "V1.1"

function Remove-AdoHotfixBranch {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$OrganizationUrl,

        [Parameter(Mandatory = $true)]
        [string]$ProjectName,

        [Parameter(Mandatory = $true)]
        [string]$RepositoryName,

        [Parameter(Mandatory = $true)]
        [string]$PatToken,

        [Parameter(Mandatory = $false)]
        [string]$ReleaseId,

        [Parameter(Mandatory = $false)]
        [string]$HotfixPrefix = "Hotfix"
    )

    $ErrorActionPreference = "Stop"

    try {

        # ---------------------------------------
        # Authentication
        # ---------------------------------------
        $base64AuthInfo = [Convert]::ToBase64String(
            [Text.Encoding]::ASCII.GetBytes(":$PatToken")
        )

        $headers = @{
            Authorization = "Basic $base64AuthInfo"
        }

        # ---------------------------------------
        # Get Hotfix Branches
        # ---------------------------------------
        $refsUrl = "$OrganizationUrl/$ProjectName/_apis/git/repositories/$RepositoryName/refs?filter=heads/$HotfixPrefix/&api-version=7.1"

        Write-Host "Fetching Hotfix branches..."

        $refsResponse = Invoke-RestMethod `
            -Uri $refsUrl `
            -Method Get `
            -Headers $headers

        if (-not $refsResponse.value) {
            Write-Host "No Hotfix branches found."
            return
        }

        # ---------------------------------------
        # Filter Branches
        # ---------------------------------------
        if ($ReleaseId) {
            $branchToDelete = "refs/heads/$HotfixPrefix/Hotfix-$ReleaseId"

            $branches = $refsResponse.value | Where-Object {
                $_.name -eq $branchToDelete
            }
        }
        else {
            $branches = $refsResponse.value
        }

        if (-not $branches) {
            Write-Host "No matching branches found."
            return
        }

        # ---------------------------------------
        # Display Branches
        # ---------------------------------------
        Write-Host ""
        Write-Host "Branches to be deleted:"
        Write-Host "----------------------------------"

        $branches | ForEach-Object {
            Write-Host $_.name
        }

        Write-Host "----------------------------------"
        Write-Host ""

        # ---------------------------------------
        # Confirmation
        # ---------------------------------------
        $confirmation = "Y"

        if ($confirmation -ne "Y") {
            Write-Host "Operation cancelled."
            return
        }

        # ---------------------------------------
        # Delete Branches
        # ---------------------------------------
        foreach ($branch in $branches) {

            Write-Host "Deleting branch: $($branch.name)"

            $body = @"
[
  {
    "name": "$($branch.name)",
    "oldObjectId": "$($branch.objectId)",
    "newObjectId": "0000000000000000000000000000000000000000"
  }
]
"@

            $deleteUrl = "$OrganizationUrl/$ProjectName/_apis/git/repositories/$RepositoryName/refs?api-version=7.1"

            Invoke-RestMethod `
                -Uri $deleteUrl `
                -Method Post `
                -Headers $headers `
                -Body $body `
                -ContentType "application/json"

            Write-Host "Deleted: $($branch.name)"
        }

        Write-Host ""
        Write-Host "Branch deletion completed successfully."
    }
    catch {
        Write-Error $_.Exception.Message
        throw
    }
}

function New-AdoPullRequest {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$OrganizationUrl,

        [Parameter(Mandatory = $true)]
        [string]$ProjectName,

        [Parameter(Mandatory = $true)]
        [string]$RepositoryName,

        [Parameter(Mandatory = $true)]
        [string]$PatToken,

        [Parameter(Mandatory = $true)]
        [string]$SourceBranch,

        [Parameter(Mandatory = $false)]
        [string]$TargetBranch = "Release",

        [Parameter(Mandatory = $true)]
        [string]$Title,

        [Parameter(Mandatory = $false)]
        [string]$Description = "",

        [Parameter(Mandatory = $false)]
        [switch]$RemoveSourceBranch
    )

    $ErrorActionPreference = "Stop"

    try {

        Write-Host "Creating Pull Request..."
        Write-Host "Source Branch : refs/heads/$SourceBranch"
        Write-Host "Target Branch : refs/heads/$TargetBranch"

        # ---------------------------------------
        # Authentication
        # ---------------------------------------
        $base64AuthInfo = [Convert]::ToBase64String(
            [Text.Encoding]::ASCII.GetBytes(":$PatToken")
        )

        $headers = @{
            Authorization = "Basic $base64AuthInfo"
        }

        # ---------------------------------------
        # PR API URL
        # ---------------------------------------
        $pullRequestUrl = "$OrganizationUrl/$ProjectName/_apis/git/repositories/$RepositoryName/pullrequests?api-version=7.1"

        # ---------------------------------------
        # Request Body
        # ---------------------------------------
        $bodyObject = @{
            sourceRefName = "refs/heads/$SourceBranch"
            targetRefName = "refs/heads/$TargetBranch"
            title         = $Title
            description   = $Description
        }

        # ---------------------------------------
        # Delete source branch after merge
        # ---------------------------------------
        if ($RemoveSourceBranch) {

            $bodyObject.completionOptions = @{
                deleteSourceBranch = $true
            }

            Write-Host "RemoveSourceBranch enabled."
        }

        $body = $bodyObject | ConvertTo-Json -Depth 10

        # ---------------------------------------
        # Create PR
        # ---------------------------------------
        $response = Invoke-RestMethod `
            -Uri $pullRequestUrl `
            -Method Post `
            -Headers $headers `
            -Body $body `
            -ContentType "application/json"

        Write-Host ""
        Write-Host "Pull Request created successfully."
        Write-Host "PR ID    : $($response.pullRequestId)"
        Write-Host "PR Title : $($response.title)"
        Write-Host "PR URL   : $($response.url)"

        if ($RemoveSourceBranch) {
            Write-Host "Source branch will be deleted after PR completion."
        }

        return $response
    }
    catch {
        Write-Error $_.Exception.Message
        throw
    }
}

function Set-AdoPullRequestAutoComplete {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$OrganizationUrl,

        [Parameter(Mandatory = $true)]
        [string]$ProjectName,

        [Parameter(Mandatory = $true)]
        [string]$RepositoryName,

        [Parameter(Mandatory = $true)]
        [string]$PatToken,

        [Parameter(Mandatory = $true)]
        [int]$PullRequestId,

        [Parameter(Mandatory = $true)]
        [string]$UserId,

        [Parameter(Mandatory = $false)]
        [switch]$DeleteSourceBranch
    )

    $ErrorActionPreference = "Stop"

    try {

        Write-Host "Configuring Pull Request Auto Complete..."
        Write-Host "Pull Request ID : $PullRequestId"

        # ---------------------------------------
        # Authentication
        # ---------------------------------------
        $base64AuthInfo = [Convert]::ToBase64String(
            [Text.Encoding]::ASCII.GetBytes(":$PatToken")
        )

        $headers = @{
            Authorization = "Basic $base64AuthInfo"
        }

        # ---------------------------------------
        # PR Update URL
        # ---------------------------------------
        $pullRequestUrl = "$OrganizationUrl/$ProjectName/_apis/git/repositories/$RepositoryName/pullrequests/$PullRequestId?api-version=7.1"

        # ---------------------------------------
        # Request Body
        # ---------------------------------------
        $bodyObject = @{
            autoCompleteSetBy = @{
                id = $UserId
            }

            completionOptions = @{
                deleteSourceBranch = $DeleteSourceBranch.IsPresent
                mergeStrategy      = "noFastForward"
            }
        }

        if ($DeleteSourceBranch) {
            Write-Host "DeleteSourceBranch enabled."
        }

        $body = $bodyObject | ConvertTo-Json -Depth 10

        Write-Host "Request Body:"
        Write-Host $body

        # ---------------------------------------
        # Update PR
        # ---------------------------------------
        $response = Invoke-RestMethod `
            -Uri $pullRequestUrl `
            -Method Patch `
            -Headers $headers `
            -Body $body `
            -ContentType "application/json"

        Write-Host ""
        Write-Host "Pull Request Auto Complete configured successfully."
        Write-Host "PR ID : $($response.pullRequestId)"

        return $response
    }
    catch {
        Write-Error $_.Exception.Message
        throw
    }
}

function New-AdoReleaseTag {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$OrganizationUrl,

        [Parameter(Mandatory = $true)]
        [string]$ProjectName,

        [Parameter(Mandatory = $true)]
        [string]$RepositoryName,

        [Parameter(Mandatory = $true)]
        [string]$PatToken,

        [Parameter(Mandatory = $true)]
        [string]$ReleaseId,

        [Parameter(Mandatory = $false)]
        [string]$SourceBranch = "Release",

        [Parameter(Mandatory = $false)]
        [string]$TagPrefix = "Release"
    )

    $ErrorActionPreference = "Stop"

    try {

        # ---------------------------------------
        # Tag Name
        # ---------------------------------------
        $tagName = "$TagPrefix-$ReleaseId"

        Write-Host "Source Branch : refs/heads/$SourceBranch"
        Write-Host "Tag Name      : refs/tags/$tagName"

        # ---------------------------------------
        # Authentication
        # ---------------------------------------
        $base64AuthInfo = [Convert]::ToBase64String(
            [Text.Encoding]::ASCII.GetBytes(":$PatToken")
        )

        $headers = @{
            Authorization = "Basic $base64AuthInfo"
        }

        # ---------------------------------------
        # Get Latest Commit ID from Source Branch
        # ---------------------------------------
        $refsUrl = "$OrganizationUrl/$ProjectName/_apis/git/repositories/$RepositoryName/refs?filter=heads/$SourceBranch&api-version=7.1"

        Write-Host "Fetching latest commit from source branch..."
        Write-Host $refsUrl

        $refsResponse = Invoke-RestMethod `
            -Uri $refsUrl `
            -Method Get `
            -Headers $headers

        if (-not $refsResponse.value) {
            throw "Source branch '$SourceBranch' not found."
        }

        $commitId = $refsResponse.value[0].objectId

        Write-Host "Latest Commit ID : $commitId"

        # ---------------------------------------
        # Create Tag
        # ---------------------------------------
        $createTagUrl = "$OrganizationUrl/$ProjectName/_apis/git/repositories/$RepositoryName/refs?api-version=7.1"

        $body = @"
[
  {
    "name": "refs/tags/$tagName",
    "oldObjectId": "0000000000000000000000000000000000000000",
    "newObjectId": "$commitId"
  }
]
"@

        Write-Host "Creating tag: refs/tags/$tagName"

        $response = Invoke-RestMethod `
            -Uri $createTagUrl `
            -Method Post `
            -Headers $headers `
            -Body $body `
            -ContentType "application/json"

        Write-Host ""
        Write-Host "Tag created successfully."
        Write-Host "Tag Name : refs/tags/$tagName"

        return $response
    }
    catch {
        Write-Error $_.Exception.Message
        throw
    }
}

Export-ModuleMember -Function `
    New-AdoHotfixBranch, `
    Remove-AdoHotfixBranch, `
    New-AdoPullRequest, `
    Set-AdoPullRequestAutoComplete, `
    New-AdoReleaseTag