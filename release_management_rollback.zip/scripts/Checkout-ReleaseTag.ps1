param(
    [Parameter(Mandatory = $true)]
    [string]$RepositoryPath,

    [Parameter(Mandatory = $true)]
    [string]$ReleaseTag,

    [Parameter(Mandatory = $true)]
    [string]$LayerName
)

$ErrorActionPreference = "Stop"

Write-Host ""
Write-Host "====================================="
Write-Host "$LayerName Repository"
Write-Host "====================================="

Write-Host ""
Write-Host "Repository Path:"
Write-Host $RepositoryPath

Write-Host ""
Write-Host "Release Tag:"
Write-Host $ReleaseTag

# =========================================================
# Validate Repository Path
# =========================================================

if (!(Test-Path $RepositoryPath)) {
    throw "Repository path does not exist: $RepositoryPath"
}

# =========================================================
# Navigate to Repository
# =========================================================

Set-Location $RepositoryPath

Write-Host ""
Write-Host "Current Working Directory:"
Get-Location

# =========================================================
# Fetch Tags
# =========================================================

Write-Host ""
Write-Host "Fetching tags..."

git fetch --tags

if ($LASTEXITCODE -ne 0) {
    throw "Failed to fetch tags."
}

# =========================================================
# Validate Tag Exists
# =========================================================

Write-Host ""
Write-Host "Validating release tag..."

$tagExists = git tag -l $ReleaseTag

if (-not $tagExists) {
    throw "Release tag [$ReleaseTag] does not exist."
}

Write-Host "Tag exists: $ReleaseTag"

# =========================================================
# Checkout Tag
# =========================================================

Write-Host ""
Write-Host "Checking out tag: $ReleaseTag"

git checkout "tags/$ReleaseTag"

if ($LASTEXITCODE -ne 0) {
    throw "Failed to checkout tag [$ReleaseTag]"
}

# =========================================================
# Repository Details
# =========================================================

$currentTag = git describe --tags --exact-match

$commitHash = git rev-parse HEAD

$shortHash = git rev-parse --short HEAD

$commitMessage = git log -1 --pretty=%B

$commitAuthor = git log -1 --pretty=%an

$commitDate = git log -1 --pretty=%cd

$currentBranch = git branch --show-current

# =========================================================
# Display Repository Information
# =========================================================

Write-Host ""
Write-Host "====================================="
Write-Host "Repository Details"
Write-Host "====================================="

Write-Host "Layer Name      : $LayerName"
Write-Host "Release Tag     : $currentTag"
Write-Host "Commit Hash     : $commitHash"
Write-Host "Short Hash      : $shortHash"
Write-Host "Commit Author   : $commitAuthor"
Write-Host "Commit Date     : $commitDate"
Write-Host "Commit Message  : $commitMessage"
Write-Host "Current Branch  : $currentBranch"

Write-Host "====================================="

# =========================================================
# Repository Status
# =========================================================

Write-Host ""
Write-Host "Git Status"
Write-Host "-------------------------------------"

git status

Write-Host "-------------------------------------"

# =========================================================
# Completed
# =========================================================

Write-Host ""
Write-Host "====================================="
Write-Host "$LayerName repository processed successfully."
Write-Host "====================================="