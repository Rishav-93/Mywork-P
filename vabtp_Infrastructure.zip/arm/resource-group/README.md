# Resource Group Template

This template deploys:
- LAW + workspace-based App Insights
- Storage accounts (general + ADLS with private endpoints and VNet integration)
- ACR
- App Service plan (Linux Premium)
- Web App (container) + Function App (container) with private endpoints, VNet integration, and public access disabled
- Key Vault private endpoint
- Private DNS Zones for all private endpoints
- Diagnostics to LAW
- AcrPull RBAC for both app identities

## Network Security Configuration
- **Private Endpoints**: Created in App-Subnet for Web App, Function App, ADLS (blob & DFS), and Key Vault
- **VNet Integration**: Web App and Function App integrated with Transient-Subnet for secure outbound connectivity
- **Public Network Access**: Disabled for Web App, Function App, and ADLS storage account
- **Network ACLs**: ADLS storage restricted to private endpoints and VNet-integrated subnets
- **Private DNS**: Centrally managed DNS zones for all private endpoints

## Role Assignment Validation
All RBAC role assignments include automatic validation to prevent duplicate role assignments:
- **Validation Logic**: Each role assignment checks if the role is already present before assigning
- **Idempotent Deployments**: Template can be deployed multiple times without creating duplicate role assignments
- **Tracked Roles**: Validates presence of roles for:
  - App Service Contributor (Web App & Function App)
  - Application Insights Component Contributor
  - Monitoring Contributor (Web App & Function App)
  - Log Analytics Contributor
  - Storage Queue Data Contributor
  - Key Vault Secrets User
  - Storage Blob Data Reader/Contributor (ADLS groups)

## Parameters
- Image names/tags and SKUs configurable
- Private endpoint and DNS zone deployment toggleable
- Subnet IDs for private endpoints and VNet integration customizable
