param(
  [Parameter(Mandatory=$true)][string]$KeyVaultName
)
$clientId = az account show --query user.name -o tsv
az ad sp show --id $clientId -o json
$ErrorActionPreference = 'Stop'

$secretNamesTsv = az keyvault secret list --vault-name $KeyVaultName --query "[].name" -o tsv
if ([string]::IsNullOrWhiteSpace($secretNamesTsv)) { Write-Host "No secrets found."; exit 0 }

$secretNames = $secretNamesTsv -split "\r?\n" | Where-Object { $_ } | ForEach-Object { $_.Trim() }
$newExpiry = (Get-Date).ToUniversalTime().AddYears(1).ToString("yyyy-MM-ddTHH:mm:ssZ")



foreach ($name in $secretNames) {
  if ([string]::IsNullOrWhiteSpace($name)) { continue }
  $value = az keyvault secret show --vault-name $KeyVaultName --name $name --query "value" -o tsv
  if (-not $value) { continue }
  az keyvault secret set --vault-name $KeyVaultName --name $name --value $value --expires $newExpiry | Out-Null
  Write-Host "Updated $name"
}
