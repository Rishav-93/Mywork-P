# ARM Infra (RG-scope, containers via ACR + Managed Identity))

This repo deploys the resources listed in `Azureresources.csv` to the existing resource group **azr-vabtp-rg-01-r3**, using your existing Azure DevOps ARM service connection **AZR-ring3-WIFServiceConnection-VolumetricAccountingBooktoPhysicalautomation**.

## What it creates
- Log Analytics Workspace (`azr-vabtp-law-01-r3`) and two workspace-based Application Insights components (`azr-vabtp-apin-01-r3`, `azr-vabtp-apin-02-r3`).
- Two Storage Accounts (general + ADLS Gen2) hardened for TLS1.2+, no anonymous access, with private endpoints and VNet integration.
- Azure Container Registry (`azrvabtpacr01r3`), admin user disabled.
- Linux Premium App Service Plan (`azr-vabtp-asp-01-r3`).
- Web App **and** Function App as **container apps** pulling from ACR with **managed identity**, VNet integrated, with private endpoints and public access disabled, plus diagnostics to LAW.
- Private Endpoints for:
  - Web App (`azrvabtpwebapppve01r3`)
  - Function App (`azrvabtpfnappve01r3`)
  - ADLS Storage Account (blob and DFS subresources)
  - Key Vault
- Centralized Private DNS Zones for all private endpoints
- **RBAC Role Assignments with Validation**: All role assignments include automatic validation to prevent duplicate assignments on re-deployment

## How to run
1. Edit container images in `environments/r3/rg.parameters.json`:
   - `webAppImageName`, `webAppImageTag`
   - `funcAppImageName`, `funcAppImageTag`
2. Push to `main` and run the pipeline.
3. Pipeline performs **What-If** then **Deploy** at Resource Group scope.

## Why these settings
- Container images are configured via `siteConfig.linuxFxVersion` with the `DOCKER|<loginServer>/<image>:<tag>` format (App Service/Functions). 
- `siteConfig.acrUseManagedIdentityCreds: true` + **AcrPull** RBAC on ACR lets the apps pull images using their managed identities (no DOCKER_* secrets).
- Security baselines: App Service `httpsOnly`, `minTlsVersion: '1.2'`, `ftpsState: 'Disabled'`, `publicNetworkAccess: 'Disabled'`; Storage `allowBlobPublicAccess: false`, `publicNetworkAccess: 'Disabled'`.
- **Network Security**: 
  - Private endpoints created in App-Subnet for secure private connectivity
  - Web App and Function App VNet integrated with Transient-Subnet for secure outbound connectivity
  - ADLS storage account network ACLs restrict access to private endpoints and VNet-integrated subnets
  - All public endpoints disabled by default
- **RBAC Validation**: All role assignments validate role presence before assignment, making template deployments idempotent and preventing duplicate role assignments

## Files
- `arm/resource-group/main.json` – ARM template (includes role validation for RBAC assignments)
- `environments/r3/rg.parameters.json` – Parameters (names prefilled)
- `environments/r3/variables.yml` – Pipeline vars (existing RG + service connection)
- `pipelines/azure-pipelines.yml` – CI pipeline (RG What-If + Deploy)
- `pipelines/templates/deploy.yml` – Reusable RG deployment template
