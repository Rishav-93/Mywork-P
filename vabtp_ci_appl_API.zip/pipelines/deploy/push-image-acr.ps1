
$ErrorActionPreference = "Stop"

# ---------------------------
# Fetch from Variable Group
# ---------------------------
$AcrName    = $env:ACR_NAME
$ImageName = $env:DOCKER_IMAGE_NAME_API


# Use ReleaseId or BuildId as tag
$ImageTag = if ($env:RELEASE_RELEASEID) {
    $env:RELEASE_RELEASEID
} else {
    $env:BUILD_BUILDID
}

$ArtifactRoot = "$env:SYSTEM_ARTIFACTSDIRECTORY/_sox_vabtp_ci_appl_api/drop"

Write-Host "Artifact root: $ArtifactRoot"
Write-Host "Listing files:"
Get-ChildItem -Path $ArtifactRoot -Recurse

# Find the TAR file dynamically
$TarFile = Get-ChildItem `
  -Path $ArtifactRoot `
  -Filter "*.tar" `
  -Recurse |
  Select-Object -First 1

if (-not $TarFile) {
  throw "❌ No TAR file found in artifact drop"
}

$TarImagePath = $TarFile.FullName


# ACR details
$AcrLoginServer = "$AcrName.azurecr.io"
$AcrImage = "${AcrLoginServer}/${ImageName}:${ImageTag}"

Write-Host "Using TAR file: $TarImagePath"
Write-Host "Target ACR image: $AcrImage"

# ---------------------------
# Login to Azure & ACR
# ---------------------------
Write-Host "Logging into Azure..."
az account show 1>$null

Write-Host "Logging into ACR..."
az acr login --name $AcrName

# ---------------------------
# Load Docker Image from TAR
# ---------------------------
Write-Host "Loading Docker image from tar..."
$loadOutput = docker load -i $TarImagePath
Write-Host $loadOutput

if ($loadOutput -match "Loaded image:\s(.+)") {
    $LocalImage = $matches[1]
} else {
    throw "❌ Failed to extract image name from docker load output."
}

Write-Host "Loaded local image: $LocalImage"

# ---------------------------
# Tag Image for ACR
# ---------------------------
Write-Host "Tagging image..."
docker tag $LocalImage $AcrImage

# ---------------------------
# Push Image to ACR
# ---------------------------
Write-Host "Pushing image to ACR..."
docker push $AcrImage




Write-Host "✅ Image successfully pushed to ACR"
