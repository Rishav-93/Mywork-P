$ErrorActionPreference = "Stop"

# ---------------------------
# Variables (from Variable Group)
# ---------------------------
$ResourceGroup = $env:DEPLOYMENT_RG
$FuncAppName    = $env:FUNCAPP_NAME
$AcrName       = $env:ACR_NAME
$ImageName     = $env:DOCKER_IMAGE_NAME_API

# Tag logic (Release or Build)
$ImageTag = $env:RELEASE_RELEASEID
if ([string]::IsNullOrWhiteSpace($ImageTag)) {
    $ImageTag = $env:BUILD_BUILDID
}

# ---------------------------
# Validation
# ---------------------------
if ([string]::IsNullOrWhiteSpace($ResourceGroup)) { throw "RESOURCE_GROUP is empty" }
if ([string]::IsNullOrWhiteSpace($FuncAppName))    { throw "FUNCAPP_NAME is empty" }
if ([string]::IsNullOrWhiteSpace($AcrName))       { throw "ACR_NAME is empty" }
if ([string]::IsNullOrWhiteSpace($ImageName))     { throw "DOCKER_IMAGE_NAME_API is empty" }
if ([string]::IsNullOrWhiteSpace($ImageTag))      { throw "ImageTag is empty" }

$AcrLoginServer = "$AcrName.azurecr.io"
$ImageFullName  = "${AcrLoginServer}/${ImageName}:${ImageTag}"

Write-Host "Deploying image:"
Write-Host "  $ImageFullName"

# ---------------------------
# Azure Login (already done in AzureCLI task)
# ---------------------------
az account show 1>$null

# ---------------------------
# Configure Function App Container
# ---------------------------
az functionapp config container set `
  --resource-group $ResourceGroup `
  --name $FuncAppName `
  --docker-custom-image-name $ImageFullName `
  --docker-registry-server-url "https://$AcrLoginServer"

# ---------------------------
# Restart Function App (important)
# ---------------------------
az functionapp restart `
  --resource-group $ResourceGroup `
  --name $FuncAppName

Write-Host "✅ Deployment to Azure Function App completed successfully"

# ---------------------------
# Verify deployed image
# ---------------------------
az functionapp show `
  --name $FuncAppName `
  --resource-group $ResourceGroup `
  --query "siteConfig.linuxFxVersion"
