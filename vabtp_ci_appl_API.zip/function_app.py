import azure.functions as func
import logging

app = func.FunctionApp()

@app.route(route="{*route}", auth_level=func.AuthLevel.ANONYMOUS)
async def main(req: func.HttpRequest) -> func.HttpResponse:
    """
    Route all incoming HTTP requests to the FastAPI application
    using the standard AsgiMiddleware.
    """
    try:
        from azure.functions import AsgiMiddleware
        from main import app as fastapi_app

        logging.info(f"Routing request to FastAPI: {req.method} {req.url}")
        return await AsgiMiddleware(fastapi_app).handle_async(req)
    except Exception as e:
        logging.error(f"Error processing request: {str(e)}")
        import traceback
        traceback.print_exc()
        return func.HttpResponse(f"Error: {str(e)}", status_code=500)
