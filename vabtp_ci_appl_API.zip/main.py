from datetime import date
from typing import Optional, Literal 
from fastapi import FastAPI, HTTPException, Query
from pydantic import BaseModel, Field, EmailStr
from p66_backend.dbx_job import read_unity_catalog_table, trigger_pipeline_reconciliation,  trigger_rerun_reconciliation, export_unity_catalog_table_as_csv, trigger_approve_job, get_approve_result_by_run_id, schedule_reconciliation_runs, read_rules_registry, trigger_convert_to_nlp, get_nlp_result_by_run_id, trigger_run_prompt, trigger_manual_job, read_bronze_source_and_mot, read_current_status
from fastapi.responses import StreamingResponse

app = FastAPI(
    title="P66 API",
    description="API management for P66",
    version="1.0.0",
    root_path="/api",
    # The Azure Function host handles the "/api" prefix.
    # The paths here should be relative to the application root.
    # This makes the docs available at /api/docs and the schema at /api/openapi.json
    openapi_url="/openapi.json",
    docs_url="/docs",
    redoc_url=None
)

# class PipelineTriggerRequest(BaseModel):
#     user_name: str
#     ad_group: str

class ReconciliationTriggerRequest(BaseModel):
    recon_type: str
    trigger_type: str
    requested_by: str
    request_type: str
    trigger_id: int
    run_date: Optional[str] = None
    
class ReconRerunRequest(BaseModel):
    plant_id: str
    month_of_recon: str
    requested_by: str
    request_type: str
    trigger_id: int
    recon_type: str


class ReconScheduleRequest(BaseModel):
    start_date: str = Field(..., description="Start date for scheduled runs (YYYY-MM-DD)")
    end_date: str = Field(..., description="End date for scheduled runs (YYYY-MM-DD)")
    frequency: Literal["5_mins", "daily", "weekly", "monthly"] = Field(..., description="Frequency of scheduled runs (10_mins, daily, weekly, monthly)")
    recon_type: str = Field(..., description="Type of reconciliation (e.g., inventory_reconciliation)")
    trigger_type: str = Field(..., description="How the pipeline was triggered (e.g., MANUAL, SCHEDULED)")
    requested_by: str = Field(..., description="Email of user requesting the schedule")
    request_type: str = Field(..., description="Type of request")
    trigger_id: int = Field(..., description="Unique identifier for this trigger event")
    run_date: Optional[str] = Field(None, description="Optional date to run")

@app.get("/")
def root():
    return {"message": "Welcome to the P66 API!"}


@app.get("/health")
def health_check():
    return {"status": "ok"}

# @app.post("/trigger-pipeline")
# def trigger():
#     return trigger_pipeline()

# @app.post("/trigger-pipeline-param")
# def trigger_param(run_date: str,
#                   multiplier: int,
#                   source_path: Optional[str] = None):
#     return trigger_pipeline_param(run_date, multiplier, source_path)

# @app.post("/pipeline-trigger-final")
# def pipeline_trigger_final(request: PipelineTriggerRequest):
#     """
#     Trigger the Databricks pipeline with user and AD group from Entra ID.
    
#     Returns:
#         - job_id: The Databricks job ID
#         - run_id: The Databricks run ID from the triggered pipeline
#     """
#     return trigger_pipeline_final(request.user_name, request.ad_group)

# @app.get("/recon/pipeline-status")
# def pipeline_status(run_id: Optional[int] = None, input_batch_id: Optional[str] = None):
#     """
#     Get the status of a Databricks pipeline run.
    
#     Query Parameters:
#         - run_id: The Databricks run ID (optional if input_batch_id provided)
#         - input_batch_id: The batch ID (optional if run_id)
    
#     Returns:
#         The pipeline run status from Databricks
#     """
#     try:
#         return get_pipeline_status(run_id=run_id, input_batch_id=input_batch_id)
#     except ValueError as e:
#         raise HTTPException(status_code=400, detail=str(e))
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=str(e))

# @app.get("/recon/runs/artifacts")
# def pipeline_results(run_id: Optional[int] = None, input_batch_id: Optional[str] = None):
#     """
#     Get the results/output from a completed Databricks job run.
    
#     Query Parameters:
#         - run_id: The Databricks run ID (optional if  input_batch_id provided)
#         - input_batch_id: The batch ID (optional if run_id  provided)
    
#     Returns:
#         - run_id: The Databricks run ID
#         - state: The current state of the run (SUCCESS, FAILED, RUNNING, etc.)
#         - tasks_outputs: Output/results from your notebook tasks
#     """
#     try:
#         return get_job_results(run_id=run_id, input_batch_id=input_batch_id)
#     except ValueError as e:
#         raise HTTPException(status_code=400, detail=str(e))
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=str(e))


@app.post("/recon/runs")
def trigger_reconciliation(request: ReconciliationTriggerRequest):
    """
    Trigger a reconciliation pipeline run.
    
    This endpoint triggers a Databricks job for inventory/data reconciliation
    with audit trail parameters and consistent batch ID generation.
    
    Request Body:
        - recon_type: Type of reconciliation (e.g., "inventory_reconciliation")
        - trigger_type: How the pipeline was triggered (e.g., "MANUAL", "SCHEDULED")
        - requested_by: Email of user requesting the reconciliation
    
    Returns:
        - message: Status message
        - job_id: The Databricks job ID
        - run_id: The Databricks run ID from the triggered pipeline
        - input_batch_id: Generated batch ID (format: BATCH_{recon_type}_{YYYY_MM_DD})
        - recon_type: Reconciliation type
        - trigger_type: Trigger type
        - requested_by: Requester email
    
    Example:
        POST /recon/runs
        {
            "recon_type": "inventory_reconciliation",
            "trigger_type": "MANUAL",
            "requested_by": "user@company.com"
        }
        
    Response:
        {
            "message": "Reconciliation pipeline triggered successfully",
            "job_id": 12345,
            "run_id": 98765,
            "input_batch_id": "BATCH_inventory_reconciliation_2026_01_29",
            "recon_type": "inventory_reconciliation",
            "trigger_type": "MANUAL",
            "requested_by": "user@company.com"
        }
    """
    try:
        return trigger_pipeline_reconciliation(
            recon_type=request.recon_type,
            trigger_type=request.trigger_type,
            requested_by=request.requested_by,
            request_type=request.request_type,
            trigger_id=request.trigger_id,
            run_date=request.run_date
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/recon/rerun")
def rerun_reconciliation(request: ReconRerunRequest):
    """
    Trigger a reconciliation rerun for a specific plant and month.
    
    This endpoint reruns a reconciliation pipeline for a specific plant
    and month with audit trail parameters.
    
    Request Body:
        - plant_id: Plant identifier
        - month_of_recon: Month of reconciliation to rerun
        - requested_by: Email of user requesting the rerun
        - request_type: Type of request (e.g., "batch", "rerun")
        - trigger_id: Unique identifier for this trigger event
    
    Returns:
        - message: Status message
        - job_id: The Databricks job ID
        - run_id: The Databricks run ID from the triggered pipeline
        - input_batch_id: Generated batch ID
        - plant_id: Plant identifier
        - month_of_recon: Month of reconciliation
        - requested_by: Requester email
        - trigger_id: Trigger ID
    
    Example:
        POST /recon/rerun
        {
            "plant_id": "PLANT_001",
            "month_of_recon": "2026-01",
            "requested_by": "user@company.com",
            "request_type": "batch/rerun",
            "trigger_id": 1234
        }
    """
    try:
        return trigger_rerun_reconciliation(
            plant_id=request.plant_id,
            month_of_recon=request.month_of_recon,
            requested_by=request.requested_by,
            request_type=request.request_type,
            trigger_id=request.trigger_id,
            recon_type=request.recon_type
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.post("/recon/schedule/runs")
def schedule_reconciliation(request: ReconScheduleRequest):
    """
    Schedule reconciliation runs between start and end dates with specified frequency.
    
    This endpoint creates a schedule for recurring reconciliation pipeline runs
    with audit trail parameters.
    
    Request Body:
        - start_date: Start date for scheduled runs (YYYY-MM-DD format)
        - end_date: End date for scheduled runs (YYYY-MM-DD format)
        - frequency: Frequency of runs ("daily", "weekly", or "monthly")
        - recon_type: Type of reconciliation (e.g., "inventory_reconciliation")
        - trigger_type: How the pipeline was triggered (e.g., "MANUAL", "SCHEDULED")
        - requested_by: Email of user requesting the schedule
        - request_type: Type of request
        - trigger_id: Unique identifier for this trigger event
        - run_date: Optional date to run
    
    Returns:
        - message: Status message
        - schedule_id: Unique ID for this schedule
        - job_id: The Databricks job ID
        - start_date: Start date of the schedule
        - end_date: End date of the schedule
        - frequency: Frequency of scheduled runs
        - recon_type: Reconciliation type
        - trigger_type: Trigger type
        - requested_by: Requester email
        - request_type: Request type
        - trigger_id: Trigger ID
        - next_run_date: Date of the next scheduled run
    
    Example:
        POST /recon/schedule/runs
        {
            "start_date": "2026-02-10",
            "end_date": "2026-12-31",
            "frequency": "monthly",
            "recon_type": "inventory_reconciliation",
            "trigger_type": "SCHEDULED",
            "requested_by": "user@company.com",
            "request_type": "scheduled",
            "trigger_id": 5678
        }
    """
    try:
        return schedule_reconciliation_runs(
            start_date=request.start_date,
            end_date=request.end_date,
            frequency=request.frequency,
            recon_type=request.recon_type,
            trigger_type=request.trigger_type,
            requested_by=request.requested_by,
            request_type=request.request_type,
            trigger_id=request.trigger_id,
            run_date=request.run_date
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/recon/status")
def read_uc_table(table_path: str, trigger_id: str, role: Optional[str] = None, limit: Optional[int] = None):
    """
    Get the results/output from a completed Databricks job run.
    
    Query Parameters:
        - run_id: The Databricks run ID (optional if  input_batch_id provided)
        - input_batch_id: The batch ID (optional if run_id  provided)
    
    Returns:
        - run_id: The Databricks run ID
        - state: The current state of the run (SUCCESS, FAILED, RUNNING, etc.)
        - tasks_outputs: Output/results from your notebook tasks
    """
    try:
        return read_unity_catalog_table(table_path=table_path,trigger_id=trigger_id, role=role, limit=limit)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Export API code
@app.get("/recon/export")
def export_uc_table(table_path: str, trigger_id: int, limit: Optional[int] = None, format: str = "csv"):
    """
    Export the same table returned by /recon/status as a downloadable CSV.
    """
    try:
        if format.lower() != "csv":
            raise HTTPException(status_code=400, detail="Only CSV format is supported currently.")
        return export_unity_catalog_table_as_csv(table_path=table_path, trigger_id=trigger_id, limit=limit)
    except HTTPException:
        raise
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    

#Approve API code
class ApproveRequest(BaseModel):
    plant_id: str = Field(..., description="Plant identifier")
    month_of_recon: str = Field(..., description="Month of reconciliation e.g. DEC25")
    requested_by: EmailStr = Field(..., description="Requester email")
    trigger_id: int = Field(..., description="Trigger ID")
    status: str = Field(..., description="Must be approved")
    request_type: str = Field(..., description="Type of request e.g. approval")
    approver: str = Field(..., description="Approver name")

    def normalized(self):
        return {
            "plant_id": self.plant_id,
            "month_of_recon": self.month_of_recon,
            "requested_by": self.requested_by,
            "trigger_id": self.trigger_id,
            "status": self.status.lower(),
            "request_type": self.request_type,
            "approver": self.approver
        }
    
@app.post("/recon/approve")
def approve_start(request: ApproveRequest):
    try:
        payload = request.normalized()
        if payload["status"] != "approved":
            raise HTTPException(status_code=400, detail="Status must be approved")

        return trigger_approve_job(
            plant_id=payload["plant_id"],
            month_of_recon=payload["month_of_recon"],
            requested_by=payload["requested_by"],
            trigger_id=payload["trigger_id"],
            status=payload["status"],
            request_type=payload["request_type"],
            approver=payload["approver"]
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    
@app.get("/recon/approve/result")
def approve_result(run_id: int = Query(...)):
    try:
        return get_approve_result_by_run_id(run_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    

# === NEW: Rules API for UI ===
@app.get("/recon/rules")
def list_rules(
    table_path: str = Query(
        "shared_datalake_ring2.vol_account_b2p_silver.rule_registry",
        description="Full path to the rules registry table"
    ),
    limit: Optional[int] = Query(
        None,
        ge=1,
        le=10000,
        description="Optional max records to return"
    )
):
    """
    List rules for UI consumption (front-end grid).
    Example:
      GET /api/recon/rules
      GET /api/recon/rules?limit=100
      GET /api/recon/rules?table_path=shared_datalake_ring2.vol_account_b2p_silver.rule_registry&limit=500
    """
    try:
        return read_rules_registry(table_path=table_path, limit=limit)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    

# @app.get("/recon/resume")
# def resume_uc_table(table_path: str, trigger_id: str, limit: Optional[int] = None):
#     """
#     Resume API — returns same output as /recon/status.
#     Used when UI session times out and Resume button is clicked.
    
#     Query Parameters:
#     - table_path: Databricks UC table path
#     - trigger_id: Filter value
#     - limit: Optional row limit

#     Returns:
#     - Same output as /recon/status API
#     """
#     try:
#         return read_unity_catalog_table(
#             table_path=table_path,
#             trigger_id=trigger_id,
#             limit=limit
#         )
#     except ValueError as e:
#         raise HTTPException(status_code=400, detail=str(e))
#     except Exception as e:
#         raise HTTPException(status_code=500, detail=str(e))


#Convert to NLP code 
class FieldItem(BaseModel):
    source: str
    sap: str
    toggle: Optional[bool] = None
    threshold_limit: Optional[float] = None

class ConvertToNLPRequest(BaseModel):
    request_type: str
    portal: str
    rule_level: str
    data_source: str
    rule_id: int
    rules_priority: int
    rules_severity: str
    rules_order: int
    fields: dict[str, FieldItem]
    classify: str

@app.post("/recon/converttonlp")
def convert_to_nlp(request: ConvertToNLPRequest):
    """
    Trigger Convert-to-NLP Databricks job.
    """
    try:
        return trigger_convert_to_nlp(request.model_dump())
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    


# NLP Result Endpoint API
@app.get("/recon/converttonlp/result")
def convert_to_nlp_result(run_id: int = Query(..., description="Databricks run_id to fetch notebook output for")):
    """
    Get NLP conversion result (paragraph) from a completed Databricks run.
    """
    try:
        return get_nlp_result_by_run_id(run_id)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


#Run Prompt API

class FieldItem(BaseModel):
    source: str
    sap: str
    toggle: Optional[bool] = None
    threshold_limit: Optional[float] = None


class RunPromptRequest(BaseModel):
    request_type: str
    portal: str
    rule_level: str
    data_source: str
    rule_id: int
    rules_priority: int
    rules_severity: str
    rules_order: int
    fields: dict[str, FieldItem]
    classify: str
    plant_id: Optional[str] = None
    month_of_recon: Optional[str] = None
    requested_by: str

@app.post("/recon/runprompt")
def run_prompt_api(request: RunPromptRequest):
    """
    Run Prompt API — forwards full payload to Databricks Run-Prompt job.
    """
    try:
        return trigger_run_prompt(request.model_dump())
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Code for Manual API

class ManualRequest(BaseModel):
    plant_id: str = Field(..., description="Plant identifier")
    month_of_recon: str = Field(..., description="Month of reconciliation e.g. DEC25")
    requested_by: EmailStr = Field(..., description="Requester email")
    trigger_id: int = Field(..., description="Trigger ID")
    status: str = Field(..., description="Must be manual")
    request_type: str = Field(..., description="Type of request e.g. manual")

    def normalized(self):
        return {
            "plant_id": self.plant_id,
            "month_of_recon": self.month_of_recon,
            "requested_by": self.requested_by,
            "trigger_id": self.trigger_id,
            "status": self.status.lower(),
            "request_type": self.request_type
        }
    
@app.post("/recon/manual")
def manual_start(request: ManualRequest):
    try:
        payload = request.normalized()
        if payload["status"] != "approved":
            raise HTTPException(status_code=400, detail="Status must be manual")

        return trigger_manual_job(
            plant_id=payload["plant_id"],
            month_of_recon=payload["month_of_recon"],
            requested_by=payload["requested_by"],
            trigger_id=payload["trigger_id"],
            status=payload["status"],
            request_type=payload["request_type"]
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    

@app.get("/recon/manual/result")
def manual_result(run_id: int = Query(...)):
    try:
        return get_approve_result_by_run_id(run_id)   # SAME FUNCTION
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))

# Code for source- MOT 

@app.get("/recon/rules/modifyprompt")
def fetch_source_and_mot(
    source_schema_path: str = Query(..., description="UC path to bronze source_schema table"),
    index_mot_path: str = Query(..., description="UC path to bronze index_mot table"),
    limit: Optional[int] = None
):
    """
    Returns:
    - Filtered column names from source_schema
    - Records from source_schema
    - Distinct MovementType list
    """
    try:
        return read_bronze_source_and_mot(
            table_source_schema=source_schema_path,
            table_index_mot=index_mot_path,
            limit=limit
        )
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
    

# Current Status API code
@app.get("/recon/currentstatus")
def current_status(month_of_recon: Optional[str] = None):
    """
    Returns the latest reconciliation status based on trigger_id.
    If month_of_recon is provided, returns latest record for that month only.
    """
    try:
        return read_current_status(month_of_recon=month_of_recon)
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
