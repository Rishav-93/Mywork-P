import os
from typing import Optional, Dict, Any
import uuid
import json
from datetime import date, datetime
from dotenv import load_dotenv
import requests
from fastapi.responses import StreamingResponse
import io
import csv

load_dotenv()   

DATABRICKS_INSTANCE = os.getenv("DBX_INSTANCE")
DATABRICKS_ACCESS_TOKEN = os.getenv("DBX_ACCESS_TOKEN")
DATABRICKS_JOB_ID = os.getenv("DBX_JOB_ID")
RERUN_DATABRICKS_JOB_ID = os.getenv("RERUN_DBX_JOB_ID")
DATABRICKS_WAREHOUSE_ID = os.getenv("DBX_WAREHOUSE_ID")
DATABRICKS_APPROVE_JOB_ID = os.getenv("DBX_APPROVE_JOB_ID")
DATABRICKS_CLUSTER_ID = os.getenv("DBX_CLUSTER_ID")
DATABRICKS_NOTEBOOK_PATH = os.getenv("DBX_NOTEBOOK_PATH")
DATABRICKS_NLP_JOB_ID = os.getenv("DBX_NLP_JOB_ID")
DATABRICKS_NLP_NOTEBOOK_PATH = os.getenv("DBX_NLP_NOTEBOOK_PATH")

# In-memory store to map input_batch_id to run_id
# In production, consider using a database
batch_run_mapping = {}

HEADERS = {
    "Authorization": f"Bearer {DATABRICKS_ACCESS_TOKEN}",
    "Content-Type": "application/json"
}

def generate_batch_id(recon_type: str) -> str:
    """
    Generate a consistent batch ID based on current date and reconciliation type.
    
    Format: BATCH_{recon_type}_{YYYY_MM_DD}
    Example: BATCH_inventory_reconciliation_2026_01_29
    
    Args:
        recon_type: Type of reconciliation (e.g., "inventory_reconciliation")
    
    Returns:
        A consistent batch ID string
    """

    rt = "".join(recon_type[0] for recon_type in recon_type.split("_"))
    current_date = datetime.now().strftime("%Y%m%d%H%M%S")
    return f"BATCH_{rt}_{current_date}"


def trigger_pipeline_reconciliation(
    recon_type: str,
    trigger_type: str,
    requested_by: str,
    request_type: str,
    trigger_id: int,
    run_date: Optional[str] = None

) -> dict:
    """
    Trigger a reconciliation pipeline with audit parameters.
    
    This function triggers a Databricks job for inventory/data reconciliation
    with consistent batch ID generation and audit trail parameters.
    
    Args:
        recon_type: Type of reconciliation (e.g., "inventory_reconciliation")
                   Passed from frontend
        trigger_type: How the pipeline was triggered (e.g., "MANUAL", "SCHEDULED")
                     Passed from frontend
        requested_by: Email of user requesting the reconciliation
                     Passed from frontend
        request_type: Type of request (e.g., "Batch", "Exception" or "Rule Update)
        trigger_id: ID associated with the trigger event (passed from frontend)
    
    Returns:
        Dictionary containing:
            - message: Status message
            - job_id: Databricks job ID
            - run_id: Databricks run ID
            - input_batch_id: Generated batch ID for this run
            - recon_type: Reconciliation type
            - trigger_type: Trigger type
            - requested_by: Requester email
            - trigger_id: Trigger ID
    
    Raises:
        RequestException: If the Databricks API call fails
    """
    # Generate batch ID
    input_batch_id = generate_batch_id(recon_type)
    
    # Prepare Databricks API call
    url = f"{DATABRICKS_INSTANCE}/api/2.1/jobs/run-now"
    payload = {
        "job_id": int(DATABRICKS_JOB_ID),
        "notebook_params": {
            "recon_type": recon_type,
            "trigger_type": trigger_type,
            "requested_by": requested_by,
            "input_batch_id": input_batch_id,
            "request_type": request_type,
            "trigger_id": trigger_id,
            "run_date": run_date or datetime.now().isoformat()
        }
    }
    
    # Execute the job
    response = requests.post(url, headers=HEADERS, json=payload)
    if response.status_code != 200:
        raise requests.exceptions.RequestException(
            f"Failed to trigger reconciliation pipeline: {response.text}"
        )
    
    # Store mapping: batch_id -> run_id for tracking
    response_data = response.json()
    run_id = response_data.get('run_id')
    batch_run_mapping[input_batch_id] = run_id
    
    return {
        "message": "Reconciliation pipeline triggered",
        "job_id": int(DATABRICKS_JOB_ID),
        "run_id": run_id,
        "input_batch_id": input_batch_id,
        "recon_type": recon_type,
        "trigger_type": trigger_type,
        "requested_by": requested_by,
        "request_type": request_type,
        "trigger_id": trigger_id,
        "run_date": run_date
    }


def trigger_rerun_reconciliation(
    plant_id: str,
    month_of_recon: str,
    requested_by: str,
    request_type: str,
    trigger_id: int,
    recon_type: str
) -> dict:
    """
    Trigger a rerun of reconciliation for a specific plant and month.
    
    This function triggers a Databricks job to rerun reconciliation
    for a specific plant and reconciliation month with audit trail parameters.
    
    Args:
        plant_id: Plant identifier to rerun reconciliation for
        month_of_recon: Month of reconciliation to rerun (e.g., "2026-01")
        requested_by: Email of user requesting the rerun
        request_type: Type of request (e.g., "batch/rerun")
        trigger_id: Unique identifier for this trigger event
    
    Returns:
        Dictionary containing:
            - message: Status message
            - job_id: Databricks job ID
            - run_id: Databricks run ID
            - input_batch_id: Generated batch ID for this run
            - plant_id: Plant identifier
            - month_of_recon: Month of reconciliation
            - requested_by: Requester email
            - request_type: Request type
            - trigger_id: Trigger ID
    
    Raises:
        RequestException: If the Databricks API call fails
    """
    # Generate batch ID
    # input_batch_id = generate_batch_id("reconciliation_rerun")
    
    # Prepare Databricks API call
    url = f"{DATABRICKS_INSTANCE}/api/2.1/jobs/run-now"
    payload = {
        "job_id": int(RERUN_DATABRICKS_JOB_ID),
        "notebook_params": {
            "plant_id": plant_id,
            "month_of_recon": month_of_recon,
            "requested_by": requested_by,
            # "input_batch_id": input_batch_id,
            "request_type": request_type,
            "trigger_id": trigger_id,
            "recon_type": recon_type
        }
    }
    
    # Execute the job
    response = requests.post(url, headers=HEADERS, json=payload)
    if response.status_code != 200:
        raise requests.exceptions.RequestException(
            f"Failed to trigger rerun reconciliation pipeline: {response.text}"
        )
    
    # Store mapping: batch_id -> run_id for tracking
    response_data = response.json()
    run_id = response_data.get('run_id')
    # batch_run_mapping[input_batch_id] = run_id
    
    return {
        "message": "Rerun reconciliation pipeline triggered",
        "job_id": int(DATABRICKS_JOB_ID),
        "run_id": run_id,
        # "input_batch_id": input_batch_id,
        "plant_id": plant_id,
        "month_of_recon": month_of_recon,
        "requested_by": requested_by,
        "request_type": request_type,
        "trigger_id": trigger_id,
        "recon_type": recon_type
    }


def schedule_reconciliation_runs(
    start_date: str,
    end_date: str,
    frequency: str,
    recon_type: str,
    trigger_type: str,
    requested_by: str,
    request_type: str,
    trigger_id: int,
    run_date: Optional[str] = None
) -> dict:
    """
    Schedule reconciliation runs between start and end dates with specified frequency.
    
    This function creates a scheduled trigger for Databricks job runs at regular intervals
    based on the specified frequency (daily, weekly, or monthly).
    
    Args:
        start_date: Start date for scheduled runs (YYYY-MM-DD format)
        end_date: End date for scheduled runs (YYYY-MM-DD format)
        frequency: Frequency of runs ("daily", "weekly", or "monthly")
        recon_type: Type of reconciliation (e.g., "inventory_reconciliation")
        trigger_type: How the pipeline was triggered (e.g., "MANUAL", "SCHEDULED")
        requested_by: Email of user requesting the schedule
        request_type: Type of request (e.g., "scheduled")
        trigger_id: Unique identifier for this trigger event
        run_date: Optional date to run (if not provided, uses current date)
    
    Returns:
        Dictionary containing:
            - message: Status message
            - schedule_id: Unique ID for this schedule
            - job_id: Databricks job ID
            - start_date: Start date of the schedule
            - end_date: End date of the schedule
            - frequency: Frequency of scheduled runs
            - recon_type: Reconciliation type
            - trigger_type: Trigger type
            - requested_by: Requester email
            - request_type: Request type
            - trigger_id: Trigger ID
            - next_run_date: Date of the next scheduled run
    
    Raises:
        ValueError: If date format is invalid or end_date is before start_date
        RequestException: If the Databricks API call fails
    """
    from datetime import datetime, timedelta
    
    # Validate and parse dates
    try:
        start = datetime.strptime(start_date, "%Y-%m-%d")
        end = datetime.strptime(end_date, "%Y-%m-%d")
    except ValueError as e:
        raise ValueError(f"Invalid date format. Use YYYY-MM-DD format: {str(e)}")
    
    if end < start:
        raise ValueError("end_date must be on or after start_date")
    
    # Generate schedule ID
    schedule_id = f"SCHEDULE_{trigger_id}_{datetime.now().strftime('%Y%m%d%H%M%S')}"
    
    # Calculate next run date based on frequency
    today = datetime.now().date()
    next_run = None
    
    if frequency == "daily":
        next_run = start if start.date() >= today else today + timedelta(days=1)
    elif frequency == "weekly":
        next_run = start if start.date() >= today else today + timedelta(weeks=1)
    elif frequency == "monthly":
        next_run = start if start.date() >= today else today + timedelta(days=30)
    
    # Prepare Databricks API call to create a new scheduled job
    url = f"{DATABRICKS_INSTANCE}/api/2.1/jobs/create"
    
    # Build cron schedule based on frequency (Quartz format: Seconds Minutes Hours Day Month DayOfWeek Year)
    cron_expression = None
    if frequency == "5_mins":
        cron_expression = "0 */5 * * * ? *"  # Every 5 minutes
    elif frequency == "daily":
        cron_expression = "0 0 0 * * ? *"  # Daily at midnight
    elif frequency == "weekly":
        cron_expression = "0 0 0 ? * MON *"  # Weekly on Monday at midnight
    elif frequency == "monthly":
        cron_expression = "0 0 0 1 * ? *"  # Monthly on 1st at midnight
    
    payload = {
        "name": f"Scheduled Reconciliation - {recon_type} - {frequency}",
        "tasks": [
            {
                "task_key": "reconciliation_task",
                "serverless_compute": {},
                "notebook_task": {
                    "notebook_path": DATABRICKS_NOTEBOOK_PATH,
                    "base_parameters": {
                        "recon_type": recon_type,
                        "trigger_type": trigger_type,
                        "requested_by": requested_by,
                        "input_batch_id": schedule_id,
                        "request_type": request_type,
                        "trigger_id": str(trigger_id),
                        "run_date": run_date or datetime.now().isoformat()
                    }
                }
            }
        ],
        "schedule": {
            "quartz_cron_expression": cron_expression,
            "timezone_id": "UTC",
            "pause_status": "UNPAUSED"
        },
        "timeout_seconds": 3600
    }
    
    # Execute the schedule creation
    response = requests.post(url, headers=HEADERS, json=payload)
    if response.status_code not in [200, 201]:
        raise requests.exceptions.RequestException(
            f"Failed to schedule reconciliation runs: {response.text}"
        )
    
    response_data = response.json()
    job_id = response_data.get('job_id')
    
    return {
        "message": "Reconciliation schedule created successfully",
        "schedule_id": schedule_id,
        "job_id": job_id,
        "start_date": start_date,
        "end_date": end_date,
        "frequency": frequency,
        "recon_type": recon_type,
        "trigger_type": trigger_type,
        "requested_by": requested_by,
        "request_type": request_type,
        "trigger_id": trigger_id,
        "next_run_date": next_run.strftime("%Y-%m-%d") if next_run else start_date
    }


def read_unity_catalog_table(table_path: str, trigger_id: str, role: Optional[str] = None, limit: Optional[int] = None) -> dict:
    """
    Read data from a Databricks Unity Catalog table using SQL API.
    
    Args:
        table_path: Full table path (e.g., "shared_datalake_ring2.vol_account_b2p_silver.recon_run_status")
        limit: Optional limit on number of rows to return
        trigger_id: ID to filter the column
    
    Returns:
        Dictionary containing:
            - table: Full table path
            - columns: List of column names
            - rows: List of rows from the table
            - row_count: Number of rows returned
    
    Raises:
        ValueError: If table_path is missing
        RequestException: If the Databricks API call fails
    """
    if not table_path:
        raise ValueError("table_path parameter is required")
    
    # Build SQL query
    sql_query = f"SELECT * FROM {table_path} WHERE trigger_id = '{trigger_id}' "
    if limit:
        sql_query += f" LIMIT {limit}"
    
    # Use Databricks SQL API endpoint
    url = f"{DATABRICKS_INSTANCE}/api/2.0/sql/statements"
    
    payload = {
        "statement": sql_query,
        "warehouse_id": DATABRICKS_WAREHOUSE_ID,  # Required for SQL API
        "wait_timeout": "10s"
    }
    
    response = requests.post(url, headers=HEADERS, json=payload)
    if response.status_code not in [200, 201]:
        raise requests.exceptions.RequestException(
            f"Failed to read Unity Catalog table {table_path}: {response.text}"
        )
    
    response_data = response.json()
    
    # Parse results from Databricks SQL API response
    result = response_data.get("result", {})
    manifest = response_data.get("manifest", {})
    
    # Extract columns from manifest - they have 'name' and 'type_text' fields
    # columns = []
    # if "columns" in manifest:
    #     columns = [col.get("name") for col in manifest.get("columns", []) if col.get("name")]
    
    # # Extract data rows
    # rows = result.get("data_array", [])

    columns_meta = manifest.get("schema", {}).get("columns", [])
    columns = [c["name"] for c in columns_meta]
    rows = result.get("data_array", [])

    records = [dict(zip(columns, row)) for row in rows]
    
    
    return {
        "table": table_path,
        # "columns": columns,
        # "rows": rows,
        "row_count": len(rows),
        "records": records
    }
# Export API Code
def export_unity_catalog_table_as_csv(table_path: str, trigger_id: int, limit: Optional[int] = None) -> StreamingResponse:
    """
    Fetch the same data as /recon/status and stream it as a CSV download.
    """
    try:
        payload = read_unity_catalog_table(table_path=table_path, trigger_id=trigger_id, limit=limit)
    except Exception as e:
        raise ValueError(f"Unable to read table '{table_path}' for trigger_id={trigger_id}: {str(e)}")

    records = payload.get("records", [])
    if not isinstance(records, list):
        raise ValueError("Backend returned an unexpected payload. 'records' must be a list.")
    if not records:
        raise ValueError("No data found to export for the given parameters.")

    headers = []
    seen = set()
    for row in records:
        if isinstance(row, dict):
            for k in row.keys():
                if k not in seen:
                    headers.append(k)
                    seen.add(k)

    if not headers:
        raise ValueError("No columns detected to export.")

    buf = io.StringIO()
    writer = csv.DictWriter(buf, fieldnames=headers, extrasaction="ignore")
    writer.writeheader()
    for row in records:
        safe_row = {}
        if isinstance(row, dict):
            for k, v in row.items():
                if isinstance(v, (str, int, float, bool)) or v is None:
                    safe_row[k] = v
                else:
                    safe_row[k] = str(v)
        writer.writerow(safe_row)

    buf.seek(0)
    filename = f"export_{trigger_id}.csv"

    return StreamingResponse(
        io.BytesIO(buf.getvalue().encode("utf-8")),
        media_type="text/csv",
        headers={"Content-Disposition": f"attachment; filename={filename}"}
    )
# Code for approve API
approve_run_mapping: Dict[int, Dict[str, Any]] = {}
def _get_approve_job_id() -> int:
    if not DATABRICKS_APPROVE_JOB_ID:
        raise ValueError("DBX_APPROVE_JOB_ID is not set")

    value = DATABRICKS_APPROVE_JOB_ID.strip().replace('"', '').replace("'", "")

    return int(value)

def trigger_approve_job(plant_id, month_of_recon, requested_by, trigger_id, status, request_type, approver, job_id=None):
    resolved_job_id = job_id or _get_approve_job_id()

    url = f"{DATABRICKS_INSTANCE}/api/2.1/jobs/run-now"
    payload = {
        "job_id": resolved_job_id,
        "notebook_params": {
            "plant_id": plant_id,
            "month_of_recon": month_of_recon,
            "requested_by": requested_by,
            "trigger_id": str(trigger_id),
            "status": status,
            "request_type": request_type,
            "approver": approver
        }
    }
    resp = requests.post(url, headers=HEADERS, json=payload)
    if resp.status_code != 200:
        raise requests.exceptions.RequestException(
            f"Failed to trigger approve job: {resp.text}"
        )
    data = resp.json()
    job_run_id = data.get("run_id")

    if not job_run_id:
        raise ValueError("Databricks did not return run_id")
    
    url_get = f"{DATABRICKS_INSTANCE}/api/2.1/jobs/runs/get?run_id={job_run_id}"
    details = requests.get(url_get, headers=HEADERS).json()

    tasks = details.get("tasks", [])
    if not tasks:
        raise ValueError("No tasks found in Databricks run response")

    task_run_id = tasks[0].get("run_id")

    approve_run_mapping[task_run_id] = {
        "plant_id": plant_id,
        "month_of_recon": month_of_recon,
        "requested_by": requested_by,
        "trigger_id": trigger_id,
        "status": status,
        "request_type": request_type,
        "job_id": resolved_job_id,
        "run_id": task_run_id,
        "submitted_at": datetime.utcnow().isoformat(),
    }

    return {
        "message": "Approve job triggered",
        "job_id": resolved_job_id,
        "run_id": task_run_id,
        "plant_id": plant_id,
        "month_of_recon": month_of_recon,
        "requested_by": requested_by,
        "trigger_id": trigger_id,
        "status": status,
    }


def get_approve_result_by_run_id(run_id: int) -> dict:
    url_state = f"{DATABRICKS_INSTANCE}/api/2.1/jobs/runs/get?run_id={run_id}"
    state_resp = requests.get(url_state, headers=HEADERS).json()
    state = state_resp.get("state", {})
    lifecycle = state.get("life_cycle_state")
    result = state.get("result_state")

    if lifecycle not in ("TERMINATED", "SKIPPED", "INTERNAL_ERROR"):
        out = {"run_id": run_id, "in_progress": True, "job_state": state}
        if run_id in approve_run_mapping:
            out["request"] = approve_run_mapping[run_id]
        return out

    url_output = f"{DATABRICKS_INSTANCE}/api/2.1/jobs/runs/get-output?run_id={run_id}"
    out_resp = requests.get(url_output, headers=HEADERS).json()
    nb = (out_resp.get("notebook_output") or {}).get("result")

    url_value = None
    status_value = None

    if nb:
        try:
            parsed = json.loads(nb)
            url_value = parsed.get("URL")
            status_value = parsed.get("status")
            if isinstance(status_value, str):
                status_value = status_value.lower()
        except:
            pass

    if not status_value:
        status_value = "success" if result == "SUCCESS" else "fail"

    out = {
        "run_id": run_id,
        "in_progress": False,
        "job_state": state,
        "status": status_value,
        "url": url_value,
    }

    if run_id in approve_run_mapping:
        out["request"] = approve_run_mapping[run_id]

    return out


# === NEW: read rules from Unity Catalog (rules registry) ===
def read_rules_registry(table_path: str, limit: Optional[int] = None) -> dict:
    """
    Read rules from a Databricks Unity Catalog table (rules registry) using the SQL API.

    Args:
        table_path: Full table path, e.g.
            "shared_datalake_ring2.vol_account_b2p_silver.rule_registry"
        limit: Optional limit on number of rows to return

    Returns:
        {
            "table": <table_path>,
            "row_count": <int>,
            "records": [ {<col>: <val>, ...}, ... ]
        }
    """
    if not table_path:
        raise ValueError("table_path parameter is required")

    # Build SQL query. Keep simple and UI-friendly; LIMIT optional.
    sql_query = f"SELECT * FROM {table_path}"
    if limit:
        sql_query += f" LIMIT {int(limit)}"

    url = f"{DATABRICKS_INSTANCE}/api/2.0/sql/statements"
    payload = {
        "statement": sql_query,
        "warehouse_id": DATABRICKS_WAREHOUSE_ID,
        "wait_timeout": "10s"
    }

    response = requests.post(url, headers=HEADERS, json=payload)
    if response.status_code not in [200, 201]:
        raise requests.exceptions.RequestException(
            f"Failed to read Unity Catalog table {table_path}: {response.text}"
        )

    response_data = response.json()
    result = response_data.get("result", {})
    manifest = response_data.get("manifest", {})

    # Columns metadata + rows array (same parsing pattern used elsewhere)
    columns_meta = manifest.get("schema", {}).get("columns", [])
    columns = [c["name"] for c in columns_meta]
    rows = result.get("data_array", []) or []

    records = [dict(zip(columns, row)) for row in rows]

    return {
        "table": table_path,
        "row_count": len(rows),
        "records": records
    }

# Code for Convert to NLP
def trigger_convert_to_nlp(payload: dict) -> dict:
    """
    Trigger Databricks NLP Conversion Job.
    Sends full UI JSON payload to Databricks notebook.
    """

    if not DATABRICKS_NLP_JOB_ID:
        raise ValueError("DBX_NLP_JOB_ID is not set in environment variable")

    url = f"{DATABRICKS_INSTANCE}/api/2.1/jobs/run-now"

    # Notebook receives a single JSON payload string
    notebook_params = {
        "json_payload": json.dumps(payload)
    }

    dbx_payload = {
        "job_id": int(DATABRICKS_NLP_JOB_ID),
        "notebook_params": notebook_params
    }

    response = requests.post(url, headers=HEADERS, json=dbx_payload)

    if response.status_code != 200:
        raise requests.exceptions.RequestException(
            f"Failed to trigger NLP conversion job: {response.text}"
        )

    data = response.json()
    parent_run_id = data.get("run_id")
    if not parent_run_id:
        raise ValueError("Databricks did not return run_id")
    url_get = f"{DATABRICKS_INSTANCE}/api/2.1/jobs/runs/get?run_id={parent_run_id}"
    details = requests.get(url_get, headers=HEADERS).json()
    tasks = details.get("tasks", [])
    task_run_id = tasks[0].get("run_id")

    return {
        "message": "NLP Conversion Job Triggered",
        "job_id": int(DATABRICKS_NLP_JOB_ID),
        "run_id": task_run_id,
        "payload_sent": payload
    }


# NLP Result Fetcher API

def get_nlp_result_by_run_id(run_id: int) -> dict:
    """
    Polls Databricks run state and returns the notebook's NLP paragraph (or any payload).
    """

    # 1) Check current run state
    url_state = f"{DATABRICKS_INSTANCE}/api/2.1/jobs/runs/get?run_id={run_id}"
    state_resp = requests.get(url_state, headers=HEADERS).json()
    state = state_resp.get("state", {})
    lifecycle = state.get("life_cycle_state")
    result_state = state.get("result_state")

    # If still running, surface minimal info so UI can keep polling
    if lifecycle not in ("TERMINATED", "SKIPPED", "INTERNAL_ERROR"):
        return {
            "run_id": run_id,
            "in_progress": True,
            "job_state": state
        }

    # 2) Fetch notebook output once it has finished
    url_out = f"{DATABRICKS_INSTANCE}/api/2.1/jobs/runs/get-output?run_id={run_id}"
    out_resp = requests.get(url_out, headers=HEADERS).json()
    nb_raw = (out_resp.get("notebook_output") or {}).get("result")

    # Try to parse JSON contract; if not JSON, pass through raw text
    nlp_output = None
    if nb_raw:
        try:
            parsed = json.loads(nb_raw)
            nlp_output = parsed.get("nlp_output", nb_raw)
        except Exception:
            nlp_output = nb_raw

    return {
        "run_id": run_id,
        "in_progress": False,
        "job_state": state,
        "status": "success" if result_state == "SUCCESS" else "fail",
        "nlp_output": nlp_output
    }


# Run Prompt Notebook Trigger Job


def trigger_run_prompt(payload: dict) -> dict:
    """
    Trigger Databricks job for Run-Prompt processing.
    Sends full JSON payload to notebook as a single parameter.
    """
    job_id = os.getenv("DBX_RUN_PROMPT_JOB_ID")

    if not job_id:
        raise ValueError("DBX_RUN_PROMPT_JOB_ID is not set in environment variables")

    url = f"{DATABRICKS_INSTANCE}/api/2.1/jobs/run-now"

    notebook_params = {
        "json_payload": json.dumps(payload)
    }

    dbx_payload = {
        "job_id": int(job_id),
        "notebook_params": notebook_params
    }

    response = requests.post(url, headers=HEADERS, json=dbx_payload)

    if response.status_code != 200:
        raise requests.exceptions.RequestException(
            f"Failed to trigger Run Prompt job: {response.text}"
        )

    data = response.json()
    parent_run_id = data.get("run_id")

    if not parent_run_id:
        raise ValueError("Databricks did not return a parent run_id")

    # Fetch actual notebook run_id 
    url_get = f"{DATABRICKS_INSTANCE}/api/2.1/jobs/runs/get?run_id={parent_run_id}"
    details = requests.get(url_get, headers=HEADERS).json()
    tasks = details.get("tasks", [])

    if not tasks:
        raise ValueError("No tasks found in the Databricks run execution")

    task_run_id = tasks[0].get("run_id")

    return {
        "message": "Run Prompt Job Triggered Successfully",
        "job_id": int(job_id),
        "parent_run_id": parent_run_id,
        "run_id": task_run_id,                     
        "payload_sent": payload
    }


# Code for manual api

def trigger_manual_job(plant_id, month_of_recon, requested_by, trigger_id, status, request_type, job_id=None):
    resolved_job_id = job_id or _get_approve_job_id()
    url = f"{DATABRICKS_INSTANCE}/api/2.1/jobs/run-now"

    payload = {
        "job_id": resolved_job_id,
        "notebook_params": {
            "plant_id": plant_id,
            "month_of_recon": month_of_recon,
            "requested_by": requested_by,
            "trigger_id": str(trigger_id),
            "status": status,
            "request_type": request_type
        }
    }

    resp = requests.post(url, headers=HEADERS, json=payload)
    if resp.status_code != 200:
        raise requests.exceptions.RequestException(
            f"Failed to trigger manual job: {resp.text}"
        )

    data = resp.json()
    job_run_id = data.get("run_id")

    url_get = f"{DATABRICKS_INSTANCE}/api/2.1/jobs/runs/get?run_id={job_run_id}"
    details = requests.get(url_get, headers=HEADERS).json()
    task_run_id = details.get("tasks", [])[0].get("run_id")

    approve_run_mapping[task_run_id] = {  # reusing same mapping is OK
        "plant_id": plant_id,
        "month_of_recon": month_of_recon,
        "requested_by": requested_by,
        "trigger_id": trigger_id,
        "status": status,
        "request_type": request_type,
        "job_id": resolved_job_id,
        "run_id": task_run_id,
        "submitted_at": datetime.utcnow().isoformat(),
    }

    return {
        "message": "Manual job triggered",
        "job_id": resolved_job_id,
        "run_id": task_run_id,
    }

# Code for source- MOT 
def read_bronze_source_and_mot(table_source_schema: str,
                               table_index_mot: str,
                               limit: Optional[int] = None) -> dict:
    """
    Reads data from:
        1. Bronze source_schema table
        2. Bronze index_mot table (distinct MovementType)
    and returns them together for UI consumption.
    """

    # -----------------------------
    # 1. READ SOURCE_SCHEMA TABLE
    # -----------------------------
    sql_src = f"SELECT * FROM {table_source_schema}"
    if limit:
        sql_src += f" LIMIT {limit}"

    url = f"{DATABRICKS_INSTANCE}/api/2.0/sql/statements"
    payload_src = {
        "statement": sql_src,
        "warehouse_id": DATABRICKS_WAREHOUSE_ID,
        "wait_timeout": "10s"
    }

    resp_src = requests.post(url, headers=HEADERS, json=payload_src)
    if resp_src.status_code not in [200, 201]:
        raise requests.exceptions.RequestException(
            f"Failed reading {table_source_schema}: {resp_src.text}"
        )

    data_src = resp_src.json()
    manifest_src = data_src.get("manifest", {})
    result_src = data_src.get("result", {})

    # Parse columns + rows
    cols_meta = manifest_src.get("schema", {}).get("columns", [])
    src_columns = [c["name"] for c in cols_meta]

    # Filter out unwanted columns (like in your notebook)
    ignore_cols = ['Source', 'file_type', 'date_added', 'Date_removed', 'plant', 'MovementType','Inventory_Qty']
    filtered_columns = [c for c in src_columns if c not in ignore_cols]

    # -----------------------------
    # 2. READ DISTINCT MovementType
    # -----------------------------
    sql_mot = f"""
        SELECT DISTINCT MovementType
        FROM {table_index_mot}
        WHERE MovementType IS NOT NULL
    """

    payload_mot = {
        "statement": sql_mot,
        "warehouse_id": DATABRICKS_WAREHOUSE_ID,
        "wait_timeout": "10s"
    }

    resp_mot = requests.post(url, headers=HEADERS, json=payload_mot)
    if resp_mot.status_code not in [200, 201]:
        raise requests.exceptions.RequestException(
            f"Failed reading {table_index_mot}: {resp_mot.text}"
        )

    data_mot = resp_mot.json()
    result_mot = data_mot.get("result", {})
    mot_rows = result_mot.get("data_array", []) or []

    MOT_LIST = [row[0] for row in mot_rows]

    # ----------------------------------
    # ✅ FINAL RETURN TO UI
    # ----------------------------------
    return {
        "source_schema_table": table_source_schema,
        "index_mot_table": table_index_mot,
        "columns": filtered_columns,
        "mot_list": MOT_LIST

    }


# Current status API code
def read_current_status(month_of_recon: Optional[str] = None) -> dict:
    """
    Fetch the latest record from recon_run_status table,
    optionally filtered by month_of_recon.
    """

    table_path = "shared_datalake_ring2.vol_account_b2p_silver.recon_run_status"

    # Build SQL dynamically
    if month_of_recon:
        sql_query = f"""
            SELECT *
            FROM {table_path}
            WHERE month_of_recon = '{month_of_recon}'
            ORDER BY created_at DESC
            LIMIT 1
        """
    else:
        sql_query = f"""
        SELECT *
        FROM {table_path}
        ORDER BY created_at DESC
        LIMIT 1
        """


    # Databricks SQL execution endpoint
    url = f"{DATABRICKS_INSTANCE}/api/2.0/sql/statements"
    payload = {
        "statement": sql_query,
        "warehouse_id": DATABRICKS_WAREHOUSE_ID,
        "wait_timeout": "10s"
    }

    response = requests.post(url, headers=HEADERS, json=payload)
    if response.status_code not in [200, 201]:
        raise requests.exceptions.RequestException(
            f"Failed to read current status: {response.text}"
        )

    response_data = response.json()

    # Parse result
    result = response_data.get("result", {})
    manifest = response_data.get("manifest", {})

    columns_meta = manifest.get("schema", {}).get("columns", [])
    columns = [col["name"] for col in columns_meta]

    rows = result.get("data_array", []) or []

    # No rows found
    if not rows:
        return {
            "message": "No records found",
            "row_count": 0,
            "records": []
        }

    # Convert to dictionary format
    records = [dict(zip(columns, row)) for row in rows]

    return {
        "table": table_path,
        "row_count": len(records),
        "records": records
    }