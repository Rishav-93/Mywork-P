
from setuptools import setup, find_packages

setup(
    name="P66",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        "fastapi",
        "uvicorn",
        "requests",
        "dotenv"
    ],
)
